import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@shared/shared.module';

import { OrchestrationListComponent } from './orchestration-list/orchestration-list.component';
import { OrchestrationDetailComponent } from './orchestration-detail/orchestration-detail.component';

@NgModule({
  declarations: [OrchestrationListComponent, OrchestrationDetailComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', component: OrchestrationListComponent },
      { path: ':id', component: OrchestrationDetailComponent }
    ])
  ]
})
export class OrchestrationModule { }
