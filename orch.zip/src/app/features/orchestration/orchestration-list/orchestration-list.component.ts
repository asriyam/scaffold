import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';

@Component({
  selector: 'app-orchestration-list',
  templateUrl: './orchestration-list.component.html',
  styleUrls: ['./orchestration-list.component.scss']
})
export class OrchestrationListComponent implements OnInit, OnDestroy {
  orchestrations: any[] = [];
  searchQuery = '';
  confirmDeleteId: string | null = null;
  openMenuId: string | null = null;
  private destroy$ = new Subject<void>();

  constructor(
    private stateService: StateService,
    private flyoutService: FlyoutService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.stateService.orchestrations$
      .pipe(takeUntil(this.destroy$))
      .subscribe(orcs => { this.orchestrations = orcs; });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  get filtered(): any[] {
    const q = this.searchQuery.toLowerCase();
    return this.orchestrations.filter(orc =>
      !q || orc.name.toLowerCase().includes(q) || (orc.description || '').toLowerCase().includes(q)
    );
  }

  getApiCount(orc: any): number {
    return (orc.apis || []).length;
  }

  getFieldCount(orc: any): number {
    if (!orc.fields) return 0;
    return Object.values(orc.fields)
      .reduce((sum: number, arr: any) => sum + (arr as string[]).length, 0);
  }

  getApiNames(orc: any): string {
    return (orc.apis || [])
      .map((id: string) => {
        const api = this.stateService.getApiById(id);
        return api ? `${api.icon} ${api.name}` : id;
      })
      .join(', ');
  }

  newOrchestration(): void {
    this.flyoutService.open('new-orchestration', {});
  }

  openDetail(orc: any): void {
    this.flyoutService.open('orchestration-detail', { id: orc.id });
  }

  openBuilder(orc: any): void {
    this.router.navigate(['/builder', orc.id, 'edit']);
  }

  cloneOrc(orc: any, event: Event): void {
    event.stopPropagation();
    this.stateService.cloneOrchestration(orc.id);
    this.showToast('Orchestration cloned');
  }

  requestDelete(orc: any, event: Event): void {
    event.stopPropagation();
    this.confirmDeleteId = orc.id;
  }

  confirmDelete(): void {
    if (this.confirmDeleteId) {
      this.stateService.deleteOrchestration(this.confirmDeleteId);
      this.confirmDeleteId = null;
    }
  }

  cancelDelete(): void {
    this.confirmDeleteId = null;
  }

  toggleMenu(id: string, event: Event): void {
    event.stopPropagation();
    this.openMenuId = this.openMenuId === id ? null : id;
  }

  @HostListener('document:click')
  closeMenu(): void { this.openMenuId = null; }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  trackById(_: number, orc: any): string { return orc.id; }
}
