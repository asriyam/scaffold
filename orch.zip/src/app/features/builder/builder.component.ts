import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';

@Component({
  selector: 'app-builder',
  templateUrl: './builder.component.html',
  styleUrls: ['./builder.component.scss']
})
export class BuilderComponent implements OnInit, OnDestroy {
  orc: any = null;
  activeTab: 'visual' | 'flow' | 'json' = 'visual';
  isSaving = false;
  jsonDraft = '';
  jsonError = '';
  isJsonDirty = false;
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService,
    private flyoutService: FlyoutService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const id = params.get('id');
      if (id && id !== 'new') {
        const existing = this.stateService.getOrchestrationById(id);
        if (existing) {
          this.orc = JSON.parse(JSON.stringify(existing));
          this.stateService.setBuilderDraft(this.orc);
        } else {
          this.router.navigate(['/orchestrations']);
        }
      } else {
        const draft = this.stateService.getBuilderDraft();
        if (draft) {
          this.orc = { ...draft };
        } else {
          this.orc = this.stateService.createBlankOrchestration();
          this.stateService.setBuilderDraft(this.orc);
        }
      }
    });

    // Auto-sync when flyout closes (step was added/modified)
    this.flyoutService.isOpen$.pipe(
      takeUntil(this.destroy$),
      pairwise(),
      filter(([prev, curr]) => prev === true && curr === false)
    ).subscribe(() => this.syncFromDraft());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      this.save(false);
    }
  }

  // ---- Header data ----

  get orcName(): string { return this.orc?.name || 'Untitled Orchestration'; }
  get orcVersion(): string { return this.orc?.version ? 'v' + this.orc.version : 'v1.0.0'; }
  onNameBlur(event: Event): void {
    const text = (event.target as HTMLElement).textContent?.trim() || 'Untitled Orchestration';
    const draft = this.stateService.getBuilderDraft();
    if (draft) { draft.name = text; this.stateService.setBuilderDraft(draft); }
    if (this.orc) this.orc.name = text;
  }

  // ---- Steps / canvas data ----

  getSteps(): any[] {
    const draft = this.stateService.getBuilderDraft();
    return draft?.steps || this.orc?.steps || [];
  }

  get hasSteps(): boolean { return this.getSteps().length > 0; }

  get jsonView(): string {
    const draft = this.stateService.getBuilderDraft();
    return JSON.stringify(draft || this.orc || {}, null, 2);
  }

  setTab(tab: 'visual' | 'flow' | 'json'): void {
    this.activeTab = tab;
    if (tab === 'json') {
      this.jsonDraft = this.jsonView;
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  onJsonInput(value: string): void {
    this.jsonDraft = value;
    this.isJsonDirty = true;
    try {
      JSON.parse(value);
      this.jsonError = '';
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  applyJson(): void {
    if (this.jsonError) return;
    try {
      const parsed = JSON.parse(this.jsonDraft);
      this.stateService.setBuilderDraft(parsed);
      this.orc = JSON.parse(JSON.stringify(parsed));
      this.isJsonDirty = false;
      this.showToast('JSON applied — Visual and Flow tabs updated');
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  resetJson(): void {
    this.jsonDraft = this.jsonView;
    this.jsonError = '';
    this.isJsonDirty = false;
  }

  syncFromDraft(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.orc = JSON.parse(JSON.stringify(draft));
    if (this.activeTab === 'json') {
      this.jsonDraft = JSON.stringify(draft, null, 2);
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  // ---- Header actions (matching orcstudio builder.js) ----

  addRootApi(): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'root' });
  }

  openSettings(): void {
    this.flyoutService.open('orc-settings', {});
  }

  openOutput(): void {
    this.flyoutService.open('orc-output', {});
  }

  openInputMapping(callId: string): void {
    this.flyoutService.open('step-input-mapping', { callId });
  }

  openResponseMapping(callId: string): void {
    this.flyoutService.open('step-response-mapping', { callId });
  }

  addDependentStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'dependent', parentCallId });
  }

  addChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'direct-child', parentCallId });
  }

  setIterateStep(callId: string): void {
    this.flyoutService.open('iteration-configure', { callId });
  }

  addIterationChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'iteration-child', parentCallId });
  }

  save(goBack = false): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    if (!draft.name?.trim()) { alert('Please enter an orchestration name'); return; }
    draft.version = this.stateService.bumpVersion(draft.version || '1.0.0');
    draft.updatedAt = new Date().toISOString();
    this.stateService.saveOrchestration(draft);
    this.stateService.setBuilderDraft(draft);
    this.orc = JSON.parse(JSON.stringify(draft));
    this.isSaving = true;
    setTimeout(() => { this.isSaving = false; }, 600);
    this.showToast('Orchestration saved');
    if (goBack) this.router.navigate(['/orchestrations']);
  }

  exportJson(): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;
    const json = JSON.stringify(draft, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = (draft.name || 'orchestration').replace(/[^a-z0-9\-_]+/gi, '-');
    a.href = url; a.download = safeName + '.json';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }

  goBack(): void { this.router.navigate(['/orchestrations']); }

  // ---- Step card actions (matching builder-visual.js) ----

  editStepFields(callId: string): void {
    this.flyoutService.open('step-fields', { callId });
  }

  configureStep(callId: string): void {
    this.flyoutService.open('step-configure', { callId });
  }

  removeStep(callId: string): void {
    if (!confirm(`Remove step "${callId}"? Any steps that depend on it will lose this dependency.`)) return;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.stateService.removeStep(draft, callId);
    this.stateService.setBuilderDraft(draft);
    this.orc = JSON.parse(JSON.stringify(draft));
  }

  getStepDependencies(step: any): string[] {
    return Array.isArray(step?.dependencies) ? step.dependencies : [];
  }

  getInputMappingCount(step: any): number {
    return Object.keys(step?.inputMapping || {}).length;
  }

  getResponseMappingCount(step: any): number {
    return Object.keys(step?.responseMapping || {}).length;
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  trackByCallId(_: number, step: any): string { return step.callId; }
}
