/** @type {import('tailwindcss').Config} */
export default {
    darkMode: 'class',
    content: ['./index.html', './src/**/*.{svelte,js,ts,jsx,tsx}'],
    theme: {
        extend: {
            // Every colour resolves to a CSS custom property, so plugins
            // loaded in an iframe inherit the theme by injecting tokens.css
            // alone (architecture spec §10.4).
            colors: {
                bg: 'var(--app-bg)',
                surface: {
                    DEFAULT: 'var(--app-surface)',
                    sunk: 'var(--app-surface-sunk)',
                    alt: 'var(--app-surface-alt)',
                },
                content: {
                    DEFAULT: 'var(--app-text)',
                    soft: 'var(--app-text-soft)',
                    muted: 'var(--app-muted)',
                },
                line: {
                    DEFAULT: 'var(--app-border)',
                    strong: 'var(--app-border-strong)',
                },
                brand: {
                    DEFAULT: 'var(--app-brand)',
                    hover: 'var(--app-brand-hover)',
                    fg: 'var(--app-brand-text)',
                },
                accent: {
                    DEFAULT: 'var(--app-accent)',
                    hover: 'var(--app-accent-hover)',
                    soft: 'var(--app-accent-soft)',
                    fg: 'var(--app-accent-text)',
                },
                brass: {
                    DEFAULT: 'var(--app-focus)',
                    rule: 'var(--app-rule)',
                    text: 'var(--app-rule-text)',
                },
                danger: {
                    DEFAULT: 'var(--app-danger)',
                    soft: 'var(--app-danger-soft)',
                },
                warning: {
                    DEFAULT: 'var(--app-warning)',
                    soft: 'var(--app-warning-soft)',
                },
                success: {
                    DEFAULT: 'var(--app-success)',
                    soft: 'var(--app-success-soft)',
                },
                info: {
                    DEFAULT: 'var(--app-info)',
                    soft: 'var(--app-info-soft)',
                },
                doc: {
                    draft: 'var(--doc-draft)',
                    posted: 'var(--doc-posted)',
                    cancelled: 'var(--doc-cancelled)',
                },
                tank: {
                    fill: 'var(--tank-fill)',
                    vapour: 'var(--tank-vapour)',
                    shell: 'var(--tank-shell)',
                    safe: 'var(--tank-safe-line)',
                },
                override: 'var(--rate-override)',
            },
            fontFamily: {
                sans: 'var(--app-font-sans)',
                mono: 'var(--app-font-mono)',
                num: 'var(--app-font-num)',
                urdu: 'var(--app-font-urdu)',
                'urdu-print': 'var(--app-font-urdu-print)',
            },
            fontSize: {
                label: ['var(--label-font)', { lineHeight: '1.3' }],
                field: ['var(--field-font)', { lineHeight: '1.4' }],
            },
            spacing: {
                field: 'var(--field-gap)',
                section: 'var(--section-gap)',
                panel: 'var(--panel-pad)',
            },
            height: {
                field: 'var(--field-height)',
                row: 'var(--grid-row-height)',
                chrome: 'var(--chrome-height)',
            },
            borderRadius: {
                DEFAULT: 'var(--app-radius)',
                lg: 'var(--app-radius-lg)',
            },
            boxShadow: {
                DEFAULT: 'var(--app-shadow)',
                lg: 'var(--app-shadow-lg)',
                focus: 'var(--app-focus-ring)',
            },
        },
    },
    plugins: [],
};
