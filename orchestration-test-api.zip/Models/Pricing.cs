namespace OrchestrationTestApi.Models;

public record Pricing(int ProductId, decimal BasePrice, decimal DiscountedPrice,
                      string Currency, DateOnly ValidUntil);
