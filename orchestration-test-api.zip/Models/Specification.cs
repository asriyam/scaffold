namespace OrchestrationTestApi.Models;

public record SpecEntry(string Key, string Value);
public record Specification(int ProductId, SpecEntry[] Specs);
