namespace OrchestrationTestApi.Models;

public record Inventory(int ProductId, int Quantity, string WarehouseId,
                        bool Available, DateTime LastUpdated);
