namespace OrchestrationTestApi.Models;

public record OrderItem(int ProductId, int Quantity, decimal UnitPrice);
public record Order(int Id, int UserId, string Status,
                    OrderItem[] Items, decimal Total, DateTime CreatedAt);
