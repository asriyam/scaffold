namespace OrchestrationTestApi.Models;

public record Category(int Id, string Name, string Description, int ProductCount);

public record CategoryListResponse(Category[] Items, int Total);
