namespace OrchestrationTestApi.Models;

public record RecommendationItem(int ProductId, double Score, string Reason);
public record RecommendationsResponse(int UserId, RecommendationItem[] Items);
