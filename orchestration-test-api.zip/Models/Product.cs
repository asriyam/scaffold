namespace OrchestrationTestApi.Models;

public record Product(int Id, string Name, string Description, int CategoryId,
                      decimal Price, double Rating, string[] Tags);

public record ProductListResponse(Product[] Items, int Total);

public record FeaturedProductsResponse(int[] ProductIds, string Label);
