namespace OrchestrationTestApi.Models;

public record UserPreferences(string Theme, string[] Interests);
public record User(int Id, string Name, string Email, string Tier, UserPreferences Preferences);

public record OrderSummary(int Id, string Status, decimal Total, DateTime CreatedAt);
public record UserOrdersResponse(OrderSummary[] Items, int Total);
