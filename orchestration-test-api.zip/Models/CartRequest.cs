namespace OrchestrationTestApi.Models;

public record CartLineItem(int ProductId, int Quantity);
public record CartRequest(CartLineItem[] Items);
public record CartBreakdown(int ProductId, string Name, int Quantity,
                            decimal UnitPrice, decimal LineTotal);
public record CartResponse(decimal Subtotal, decimal Tax, decimal Total,
                           CartBreakdown[] Breakdown);
