using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/inventory")]
public class InventoryController : ControllerBase
{
    [HttpGet("{productId:int}")]
    [ProducesResponseType(typeof(Inventory), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetByProductId(int productId)
    {
        var inv = SeedData.Inventories.FirstOrDefault(i => i.ProductId == productId);
        if (inv is null) return NotFound();
        return Ok(inv);
    }
}
