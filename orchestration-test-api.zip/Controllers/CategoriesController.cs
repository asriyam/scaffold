using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/categories")]
public class CategoriesController : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(CategoryListResponse), 200)]
    public IActionResult GetAll()
    {
        var items = SeedData.Categories;
        return Ok(new CategoryListResponse(items, items.Length));
    }

    [HttpGet("{categoryId:int}")]
    [ProducesResponseType(typeof(Category), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int categoryId)
    {
        var category = SeedData.Categories.FirstOrDefault(c => c.Id == categoryId);
        if (category is null) return NotFound();
        return Ok(category);
    }
}
