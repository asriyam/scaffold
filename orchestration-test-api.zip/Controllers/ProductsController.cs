using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/products")]
public class ProductsController : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(ProductListResponse), 200)]
    public IActionResult GetAll([FromQuery] int? categoryId, [FromQuery] int? limit)
    {
        var items = SeedData.Products.AsEnumerable();
        if (categoryId.HasValue)
            items = items.Where(p => p.CategoryId == categoryId.Value);
        if (limit.HasValue)
            items = items.Take(limit.Value);
        var arr = items.ToArray();
        return Ok(new ProductListResponse(arr, arr.Length));
    }

    [HttpGet("featured")]
    [ProducesResponseType(typeof(FeaturedProductsResponse), 200)]
    public IActionResult GetFeatured()
    {
        return Ok(new FeaturedProductsResponse([101, 104, 107], "Staff Picks"));
    }

    [HttpGet("{productId:int}")]
    [ProducesResponseType(typeof(Product), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int productId)
    {
        var product = SeedData.Products.FirstOrDefault(p => p.Id == productId);
        if (product is null) return NotFound();
        return Ok(product);
    }

    [HttpGet("{productId:int}/pricing")]
    [ProducesResponseType(typeof(Pricing), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetPricing(int productId)
    {
        var pricing = SeedData.Pricings.FirstOrDefault(p => p.ProductId == productId);
        if (pricing is null) return NotFound();
        return Ok(pricing);
    }

    [HttpGet("{productId:int}/specifications")]
    [ProducesResponseType(typeof(Specification), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetSpecifications(int productId)
    {
        var spec = SeedData.Specifications.FirstOrDefault(s => s.ProductId == productId);
        if (spec is null) return NotFound();
        return Ok(spec);
    }
}
