using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/recommendations")]
public class RecommendationsController : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(RecommendationsResponse), 200)]
    [ProducesResponseType(404)]
    public IActionResult Get([FromQuery] int userId, [FromQuery] int limit = 5)
    {
        if (!SeedData.Users.Any(u => u.Id == userId)) return NotFound();

        var user = SeedData.Users.First(u => u.Id == userId);

        var reasons = new[] { "Based on past purchases", "Popular in your category", "Trending now", "Highly rated" };

        var recommended = SeedData.Products
            .Where(p => user.Preferences.Interests.Any(i =>
                p.Tags.Any(t => t.Contains(i, StringComparison.OrdinalIgnoreCase))))
            .Take(limit)
            .Select((p, idx) => new RecommendationItem(p.Id, Math.Round(0.95 - idx * 0.05, 2), reasons[idx % reasons.Length]))
            .ToArray();

        if (recommended.Length == 0)
        {
            recommended = SeedData.Products
                .OrderByDescending(p => p.Rating)
                .Take(limit)
                .Select((p, idx) => new RecommendationItem(p.Id, Math.Round(0.80 - idx * 0.05, 2), "Highly rated"))
                .ToArray();
        }

        return Ok(new RecommendationsResponse(userId, recommended));
    }
}
