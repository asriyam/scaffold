using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/cart")]
public class CartController : ControllerBase
{
    [HttpPost("calculate")]
    [ProducesResponseType(typeof(CartResponse), 200)]
    [ProducesResponseType(400)]
    public IActionResult Calculate([FromBody] CartRequest request)
    {
        var breakdown = new List<CartBreakdown>();

        foreach (var line in request.Items)
        {
            var product = SeedData.Products.FirstOrDefault(p => p.Id == line.ProductId);
            if (product is null) continue;
            var lineTotal = product.Price * line.Quantity;
            breakdown.Add(new CartBreakdown(product.Id, product.Name, line.Quantity, product.Price, lineTotal));
        }

        var subtotal = breakdown.Sum(b => b.LineTotal);
        var tax = Math.Round(subtotal * 0.09m, 2);
        var total = subtotal + tax;

        return Ok(new CartResponse(subtotal, tax, total, [.. breakdown]));
    }
}
