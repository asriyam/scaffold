using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    [HttpGet("{userId:int}")]
    [ProducesResponseType(typeof(User), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int userId)
    {
        var user = SeedData.Users.FirstOrDefault(u => u.Id == userId);
        if (user is null) return NotFound();
        return Ok(user);
    }

    [HttpGet("{userId:int}/orders")]
    [ProducesResponseType(typeof(UserOrdersResponse), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetOrders(int userId)
    {
        if (!SeedData.Users.Any(u => u.Id == userId)) return NotFound();

        var summaries = SeedData.Orders
            .Where(o => o.UserId == userId)
            .Select(o => new OrderSummary(o.Id, o.Status, o.Total, o.CreatedAt))
            .ToArray();

        return Ok(new UserOrdersResponse(summaries, summaries.Length));
    }
}
