using Microsoft.AspNetCore.Mvc;
using OrchestrationTestApi.Data;
using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Controllers;

[ApiController]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    [HttpGet("{orderId:int}")]
    [ProducesResponseType(typeof(Order), 200)]
    [ProducesResponseType(404)]
    public IActionResult GetById(int orderId)
    {
        var order = SeedData.Orders.FirstOrDefault(o => o.Id == orderId);
        if (order is null) return NotFound();
        return Ok(order);
    }
}
