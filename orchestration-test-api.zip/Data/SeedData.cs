using OrchestrationTestApi.Models;

namespace OrchestrationTestApi.Data;

public static class SeedData
{
    public static readonly Category[] Categories =
    [
        new(1, "Electronics", "Electronic devices and accessories", 3),
        new(2, "Apparel", "Clothing and fashion accessories", 3),
        new(3, "Home & Garden", "Home decor and garden supplies", 3),
    ];

    public static readonly Product[] Products =
    [
        new(101, "Laptop Pro", "High-performance laptop for professionals", 1, 1299.99m, 4.7, ["laptop", "premium", "work"]),
        new(102, "Wireless Headphones", "Noise-cancelling over-ear headphones", 1, 249.99m, 4.5, ["audio", "wireless", "noise-cancelling"]),
        new(103, "4K Monitor", "32-inch 4K UHD display", 1, 549.99m, 4.6, ["monitor", "4k", "display"]),
        new(104, "Running Shoes", "Lightweight performance running shoes", 2, 99.99m, 4.3, ["shoes", "running", "sport"]),
        new(105, "Yoga Pants", "Flexible high-waist yoga pants", 2, 49.99m, 4.4, ["yoga", "fitness", "apparel"]),
        new(106, "Winter Jacket", "Waterproof insulated winter jacket", 2, 199.99m, 4.2, ["jacket", "winter", "outdoor"]),
        new(107, "Garden Hose", "50ft expandable garden hose", 3, 39.99m, 4.1, ["garden", "outdoor", "hose"]),
        new(108, "Desk Lamp", "LED adjustable desk lamp with USB charging", 3, 59.99m, 4.5, ["lamp", "lighting", "desk"]),
        new(109, "Throw Pillow Set", "Decorative throw pillow set of 4", 3, 34.99m, 4.3, ["pillow", "decor", "home"]),
    ];

    public static readonly Inventory[] Inventories =
    [
        new(101, 42, "WH-EAST-01", true,  new DateTime(2026, 5, 25, 10, 0, 0, DateTimeKind.Utc)),
        new(102, 15, "WH-EAST-01", true,  new DateTime(2026, 5, 25, 10, 0, 0, DateTimeKind.Utc)),
        new(103,  0, "WH-WEST-02", false, new DateTime(2026, 5, 24, 8, 0, 0, DateTimeKind.Utc)),
        new(104, 88, "WH-EAST-01", true,  new DateTime(2026, 5, 25, 10, 0, 0, DateTimeKind.Utc)),
        new(105, 34, "WH-WEST-02", true,  new DateTime(2026, 5, 25, 9, 0, 0, DateTimeKind.Utc)),
        new(106,  7, "WH-EAST-01", true,  new DateTime(2026, 5, 25, 10, 0, 0, DateTimeKind.Utc)),
        new(107, 120, "WH-CENTRAL-03", true, new DateTime(2026, 5, 25, 10, 0, 0, DateTimeKind.Utc)),
        new(108, 23, "WH-CENTRAL-03", true, new DateTime(2026, 5, 25, 10, 0, 0, DateTimeKind.Utc)),
        new(109,  0, "WH-WEST-02", false, new DateTime(2026, 5, 23, 12, 0, 0, DateTimeKind.Utc)),
    ];

    public static readonly User[] Users =
    [
        new(1, "Alice Chen",   "alice@example.com",   "gold",   new UserPreferences("dark",  ["electronics", "home"])),
        new(2, "Bob Martinez", "bob@example.com",     "silver", new UserPreferences("light", ["apparel", "sports"])),
        new(3, "Carol Davis",  "carol@example.com",   "bronze", new UserPreferences("dark",  ["home", "garden"])),
    ];

    public static readonly Order[] Orders =
    [
        new(10, 1, "delivered",
            [new(101, 1, 1299.99m), new(104, 2, 99.99m)],
            1499.97m, new DateTime(2026, 4, 10, 14, 22, 0, DateTimeKind.Utc)),
        new(11, 1, "shipped",
            [new(102, 1, 249.99m), new(108, 1, 59.99m), new(109, 2, 34.99m)],
            379.96m, new DateTime(2026, 5, 1, 9, 15, 0, DateTimeKind.Utc)),
        new(12, 2, "processing",
            [new(105, 2, 49.99m), new(106, 1, 199.99m)],
            299.97m, new DateTime(2026, 5, 20, 16, 45, 0, DateTimeKind.Utc)),
        new(13, 3, "delivered",
            [new(107, 1, 39.99m), new(108, 1, 59.99m)],
            99.98m, new DateTime(2026, 4, 28, 11, 30, 0, DateTimeKind.Utc)),
    ];

    public static readonly Pricing[] Pricings =
    [
        new(101, 1399.99m, 1299.99m, "USD", new DateOnly(2026, 12, 31)),
        new(102, 279.99m,  249.99m,  "USD", new DateOnly(2026, 12, 31)),
        new(103, 599.99m,  549.99m,  "USD", new DateOnly(2026, 9, 30)),
        new(104, 119.99m,   99.99m,  "USD", new DateOnly(2026, 12, 31)),
        new(105,  59.99m,   49.99m,  "USD", new DateOnly(2026, 12, 31)),
        new(106, 229.99m,  199.99m,  "USD", new DateOnly(2026, 11, 30)),
        new(107,  44.99m,   39.99m,  "USD", new DateOnly(2026, 12, 31)),
        new(108,  69.99m,   59.99m,  "USD", new DateOnly(2026, 12, 31)),
        new(109,  39.99m,   34.99m,  "USD", new DateOnly(2026, 12, 31)),
    ];

    public static readonly Specification[] Specifications =
    [
        new(101, [new("CPU", "Intel Core i7-13700H"), new("RAM", "16GB DDR5"), new("Storage", "512GB NVMe SSD"), new("Display", "15.6\" FHD 144Hz")]),
        new(102, [new("Driver Size", "40mm"), new("Frequency Response", "20Hz-20kHz"), new("Battery Life", "30 hours"), new("Connectivity", "Bluetooth 5.2")]),
        new(103, [new("Resolution", "3840x2160"), new("Panel", "IPS"), new("Refresh Rate", "60Hz"), new("Ports", "HDMI 2.1, DP 1.4, USB-C")]),
        new(104, [new("Material", "Mesh upper, rubber sole"), new("Drop", "8mm"), new("Weight", "220g"), new("Sizes", "US 6-14")]),
        new(105, [new("Material", "87% Polyester, 13% Spandex"), new("Waist", "High-rise"), new("Pockets", "2 side pockets"), new("Care", "Machine wash cold")]),
        new(106, [new("Shell", "100% Polyester"), new("Fill", "600-fill goose down"), new("Waterproof Rating", "10,000mm"), new("Pockets", "5 total")]),
        new(107, [new("Length", "50ft expanded"), new("Material", "TPS rubber"), new("Connectors", "Brass"), new("Pressure", "Up to 87 PSI")]),
        new(108, [new("Bulb Type", "LED"), new("Color Temperature", "2700K-6500K"), new("USB Ports", "2x USB-A"), new("Arm Reach", "20 inches")]),
        new(109, [new("Includes", "4 pillows"), new("Fill", "Polyester fiberfill"), new("Cover", "100% Cotton"), new("Size", "18x18 inches")]),
    ];
}
