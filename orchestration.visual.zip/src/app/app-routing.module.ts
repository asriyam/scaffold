import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/orchestrations', pathMatch: 'full' },
  {
    path: 'orchestrations',
    loadChildren: () => import('./features/orchestration/orchestration.module')
      .then(m => m.OrchestrationModule)
  },
  {
    path: 'marketplace',
    loadChildren: () => import('./features/api-marketplace/api-marketplace.module')
      .then(m => m.ApiMarketplaceModule)
  },
  {
    path: 'page-builder',
    loadChildren: () => import('./features/page-builder/page-builder.module')
      .then(m => m.PageBuilderModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
