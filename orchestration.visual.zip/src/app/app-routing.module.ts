import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/orchestrations', pathMatch: 'full' },
  {
    path: 'orchestrations',
    loadChildren: () => import('./features/orchestration/orchestration.module')
      .then(m => m.OrchestrationModule)
  },
  {
    path: 'builder',
    loadChildren: () => import('./features/builder/builder.module')
      .then(m => m.BuilderModule)
  },
  {
    path: 'marketplace',
    loadChildren: () => import('./features/api-marketplace/api-marketplace.module')
      .then(m => m.ApiMarketplaceModule)
  },
  {
    path: 'page-builder',
    loadChildren: () => import('./features/page-builder/page-builder.module')
      .then(m => m.PageBuilderModule)
  },
  {
    path: 'swagger-import',
    loadChildren: () => import('./features/swagger-import/swagger-import.module')
      .then(m => m.SwaggerImportModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
