import { Orchestration } from '../../models/orchestration.model';

export const MOCK_ORCHESTRATIONS: Orchestration[] = [
  {
    id: 'orc-001',
    name: 'Laptop Catalog Page',
    description: 'Full product listing for Dell laptops with ratings and inventory',
    version: '1.0.0',
    createdAt: new Date('2025-05-01T10:00:00Z'),
    updatedAt: new Date('2025-05-05T14:30:00Z'),
    steps: [
      {
        callId: 'category-api',
        apiId: 'category',
        endpoint: '/api/v1/categories/{categoryId}/products',
        fields: ['id', 'name', 'products'],
        inputs: { categoryId: 'cat-laptops-001' },
        iteration: {
          arrayField: 'products',
          steps: [
            {
              callId: 'product-details',
              apiId: 'products',
              endpoint: '/api/v1/products/{productId}',
              fields: ['id', 'name', 'description', 'images', 'specifications', 'availability'],
              parallelWith: ['product-ratings']
            },
            {
              callId: 'product-ratings',
              apiId: 'ratings',
              endpoint: '/api/v1/products/{productId}/ratings',
              fields: ['averageRating', 'reviewCount', 'topReviews'],
              parallelWith: ['product-details']
            }
          ]
        }
      }
    ],
    outputMapping: {
      category: '$category-api',
      products: {
        transform: [
          { field: 'details', source: '$product-details' },
          { field: 'ratings', source: '$product-ratings' }
        ]
      }
    }
  },
  {
    id: 'orc-002',
    name: 'Home Deals Rotator',
    description: 'Featured deals carousel for homepage',
    version: '1.0.0',
    createdAt: new Date('2025-05-03T09:00:00Z'),
    updatedAt: new Date('2025-05-03T09:00:00Z'),
    apiCalls: [
      {
        callId: 'products-api',
        apiId: 'products',
        endpoint: '/api/v1/products/{productId}',
        fields: ['id', 'name', 'price', 'salePrice', 'badge', 'images'],
        inputs: { productId: 'xps15-001' }
      },
      {
        callId: 'pricing-api',
        apiId: 'shipping',
        endpoint: '/api/v1/shipping/calculate',
        fields: ['cost', 'days'],
        inputs: { productId: 'xps15-001', country: 'US' }
      }
    ],
    outputMapping: {
      deals: {
        id: '$products-api.id',
        name: '$products-api.name',
        price: '$products-api.price',
        salePrice: '$products-api.salePrice',
        badge: '$products-api.badge',
        shippingCost: '$pricing-api.cost'
      }
    }
  },
  {
    id: 'orc-003',
    name: 'Gaming Category Page',
    description: 'Gaming products with detailed specs and inventory',
    version: '1.0.0',
    createdAt: new Date('2025-04-28T16:00:00Z'),
    updatedAt: new Date('2025-04-28T16:00:00Z'),
    apiCalls: [
      {
        callId: 'category-api',
        apiId: 'category',
        endpoint: '/api/v1/categories/{categoryId}/products',
        fields: ['id', 'name', 'description', 'imageUrl'],
        inputs: { categoryId: 'cat-gaming-001' }
      },
      {
        callId: 'products-api',
        apiId: 'products',
        endpoint: '/api/v1/products/{productId}',
        fields: ['id', 'name', 'price', 'badge', 'features', 'specifications'],
        dependsOn: ['category-api']
      },
      {
        callId: 'inventory-api',
        apiId: 'inventory',
        endpoint: '/api/v1/inventory/{productId}',
        fields: ['stock', 'available'],
        dependsOn: ['products-api']
      }
    ],
    outputMapping: {
      category: {
        id: '$category-api.id',
        name: '$category-api.name',
        description: '$category-api.description',
        imageUrl: '$category-api.imageUrl'
      },
      products: {
        id: '$products-api.id',
        name: '$products-api.name',
        price: '$products-api.price',
        badge: '$products-api.badge',
        stock: '$inventory-api.stock',
        available: '$inventory-api.available'
      }
    }
  }
];
