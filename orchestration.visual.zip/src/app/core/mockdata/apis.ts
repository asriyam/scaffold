import { Api, ApiInput, ApiField } from '../../models/api.model';

export const MOCK_APIS: Api[] = [
  {
    id: 'category',
    name: 'Category API',
    method: 'GET',
    endpoint: '/api/v1/categories/{categoryId}/products',
    description: 'Browse product categories and retrieve their product listings',
    category: 'Products',
    inputs: [
      {
        name: 'categoryId',
        type: 'string',
        required: true,
        description: 'The unique identifier for the category',
        example: 'cat-laptops-001'
      }
    ],
    outputs: [
      { name: 'id', type: 'string', description: 'Category identifier', path: 'id' },
      { name: 'name', type: 'string', description: 'Category display name', path: 'name' },
      { name: 'slug', type: 'string', description: 'URL-friendly slug', path: 'slug' },
      { name: 'description', type: 'string', description: 'Category description', path: 'description' },
      { name: 'parentId', type: 'string', description: 'Parent category ID', path: 'parentId' },
      { name: 'imageUrl', type: 'string', description: 'Category banner image URL', path: 'imageUrl' },
      { name: 'products', type: 'array', description: 'List of product references', path: 'products' },
      { name: 'totalCount', type: 'number', description: 'Total product count', path: 'totalCount' },
      { name: 'metadata', type: 'object', description: 'SEO and misc metadata', path: 'metadata' }
    ],
    examples: [
      {
        name: 'Laptops Category',
        inputs: { categoryId: 'cat-laptops-001' },
        output: {
          id: 'cat-laptops-001',
          name: 'Laptops',
          slug: 'laptops',
          description: 'Premium and performance laptops for work and gaming',
          parentId: 'cat-computers',
          imageUrl: 'https://example.com/laptops-banner.jpg',
          products: ['xps15-001', 'xps13-001', 'xps16-001'],
          totalCount: 8,
          metadata: { seoTitle: 'Laptops', keywords: 'laptop, computer' }
        }
      }
    ]
  },
  {
    id: 'products',
    name: 'Products API',
    method: 'GET',
    endpoint: '/api/v1/products/{productId}',
    description: 'Fetch full product details including price, specs, images and availability',
    category: 'Products',
    inputs: [
      {
        name: 'productId',
        type: 'string',
        required: true,
        description: 'The unique product identifier',
        example: 'xps15-001'
      }
    ],
    outputs: [
      { name: 'id', type: 'string', description: 'Product identifier', path: 'id' },
      { name: 'name', type: 'string', description: 'Product display name', path: 'name' },
      { name: 'productLine', type: 'string', description: 'Product line (XPS, Dell, Dell Pro, Alienware)', path: 'productLine' },
      { name: 'badge', type: 'string', description: 'Display badge label (Best Seller, New, Sale, Gaming)', path: 'badge' },
      { name: 'sku', type: 'string', description: 'Stock keeping unit', path: 'sku' },
      { name: 'description', type: 'string', description: 'Long product description', path: 'description' },
      { name: 'shortDescription', type: 'string', description: 'Short summary', path: 'shortDescription' },
      { name: 'features', type: 'array', description: 'Bullet-point highlights for listing pages', path: 'features' },
      { name: 'price', type: 'number', description: 'Base price', path: 'price' },
      { name: 'salePrice', type: 'number', description: 'Discounted price', path: 'salePrice' },
      { name: 'currency', type: 'string', description: 'Currency code', path: 'currency' },
      { name: 'images', type: 'array', description: 'Product image URLs', path: 'images' },
      { name: 'specifications', type: 'object', description: 'Technical spec key-values', path: 'specifications' },
      { name: 'availability', type: 'string', description: 'In Stock / Out of Stock', path: 'availability' },
      { name: 'categoryIds', type: 'array', description: 'Associated categories', path: 'categoryIds' }
    ],
    examples: [
      {
        name: 'Dell XPS 15 Product',
        inputs: { productId: 'xps15-001' },
        output: {
          id: 'xps15-001',
          name: 'Dell XPS 15 Laptop',
          productLine: 'XPS',
          badge: 'Best Seller',
          sku: 'XPS15-9530-7891',
          description: 'The ultimate 15-inch laptop for creators and professionals',
          shortDescription: 'Power meets portability',
          features: ['Intel® Core™ Ultra 7', '15.6" OLED 3.5K', 'Up to 13 hrs battery'],
          price: 1299.99,
          salePrice: null,
          currency: 'USD',
          images: ['xps15-front.jpg', 'xps15-side.jpg'],
          specifications: { Processor: 'Intel Core Ultra 7', RAM: '16GB' },
          availability: 'In Stock',
          categoryIds: ['cat-laptops']
        }
      }
    ]
  },
  {
    id: 'ratings',
    name: 'Ratings API',
    method: 'GET',
    endpoint: '/api/v1/products/{productId}/ratings',
    description: 'Get customer rating scores, review counts and top reviews for a product',
    category: 'Products',
    inputs: [
      {
        name: 'productId',
        type: 'string',
        required: true,
        description: 'Product identifier',
        example: 'xps15-001'
      }
    ],
    outputs: [
      { name: 'productId', type: 'string', description: 'Product reference', path: 'productId' },
      { name: 'ratingNumber', type: 'number', description: 'Rounded rating (1–5)', path: 'ratingNumber' },
      { name: 'averageRating', type: 'number', description: 'Precise rating average', path: 'averageRating' },
      { name: 'reviewCount', type: 'number', description: 'Total number of reviews', path: 'reviewCount' },
      { name: 'ratingDistribution', type: 'object', description: 'Breakdown by star', path: 'ratingDistribution' },
      { name: 'topReviews', type: 'array', description: 'Top 3 customer reviews', path: 'topReviews' },
      { name: 'lastUpdated', type: 'string', description: 'Last update timestamp', path: 'lastUpdated' }
    ],
    examples: [
      {
        name: 'XPS 15 Ratings',
        inputs: { productId: 'xps15-001' },
        output: {
          productId: 'xps15-001',
          ratingNumber: 5,
          averageRating: 4.7,
          reviewCount: 2841,
          ratingDistribution: { 5: 1820, 4: 710, 3: 210, 2: 70, 1: 31 },
          topReviews: [
            { author: 'J. Smith', rating: 5, text: 'Incredible display and performance' },
            { author: 'M. Johnson', rating: 5, text: 'Best laptop I have ever owned' }
          ],
          lastUpdated: '2025-04-28'
        }
      }
    ]
  },
  {
    id: 'inventory',
    name: 'Inventory API',
    method: 'GET',
    endpoint: '/api/v1/inventory/{productId}',
    description: 'Real-time stock counts, warehouse location and availability',
    category: 'Inventory',
    inputs: [
      {
        name: 'productId',
        type: 'string',
        required: true,
        description: 'Product identifier',
        example: 'xps15-001'
      }
    ],
    outputs: [
      { name: 'stock', type: 'number', description: 'Total stock', path: 'stock' },
      { name: 'available', type: 'boolean', description: 'Whether item is available', path: 'available' },
      { name: 'warehouseId', type: 'string', description: 'Primary warehouse identifier', path: 'warehouseId' }
    ],
    examples: [
      {
        name: 'XPS 15 Inventory',
        inputs: { productId: 'xps15-001' },
        output: {
          stock: 1250,
          available: true,
          warehouseId: 'wh-austin'
        }
      }
    ]
  },
  {
    id: 'shipping',
    name: 'Shipping API',
    method: 'POST',
    endpoint: '/api/v1/shipping/calculate',
    description: 'Shipping cost and delivery estimates',
    category: 'Shipping',
    inputs: [
      {
        name: 'productId',
        type: 'string',
        required: true,
        description: 'Product identifier',
        example: 'xps15-001'
      },
      {
        name: 'country',
        type: 'string',
        required: true,
        description: 'Destination country',
        example: 'US'
      }
    ],
    outputs: [
      { name: 'cost', type: 'number', description: 'Shipping cost', path: 'cost' },
      { name: 'days', type: 'number', description: 'Estimated delivery days', path: 'days' },
      { name: 'express', type: 'boolean', description: 'Express shipping flag', path: 'express' },
      { name: 'shippingType', type: 'string', description: 'Shipping type', path: 'shippingType' }
    ],
    examples: [
      {
        name: 'Shipping to US',
        inputs: { productId: 'xps15-001', country: 'US' },
        output: {
          cost: 29.99,
          days: 3,
          express: false,
          shippingType: 'STANDARD'
        }
      }
    ]
  },
  {
    id: 'users',
    name: 'Users API',
    method: 'GET',
    endpoint: '/api/v1/users/{userId}',
    description: 'User profile, loyalty tier, order history and saved addresses',
    category: 'Users',
    inputs: [
      {
        name: 'userId',
        type: 'string',
        required: true,
        description: 'User identifier',
        example: 'user-12345'
      }
    ],
    outputs: [
      { name: 'userId', type: 'string', description: 'User identifier', path: 'userId' },
      { name: 'email', type: 'string', description: 'User email', path: 'email' },
      { name: 'firstName', type: 'string', description: 'First name', path: 'firstName' },
      { name: 'lastName', type: 'string', description: 'Last name', path: 'lastName' },
      { name: 'tier', type: 'string', description: 'Loyalty tier', path: 'tier' },
      { name: 'orders', type: 'array', description: 'Order history references', path: 'orders' },
      { name: 'savedAddresses', type: 'array', description: 'Shipping addresses', path: 'savedAddresses' },
      { name: 'preferences', type: 'object', description: 'User preferences', path: 'preferences' }
    ],
    examples: [
      {
        name: 'John Doe User',
        inputs: { userId: 'user-12345' },
        output: {
          userId: 'user-12345',
          email: 'john.doe@example.com',
          firstName: 'John',
          lastName: 'Doe',
          tier: 'Gold',
          orders: ['order-001', 'order-002'],
          savedAddresses: [{ street: '123 Main St', city: 'Austin', state: 'TX' }],
          preferences: { newsletter: true, notifications: true }
        }
      }
    ]
  }
];
