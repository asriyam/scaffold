export const MOCKDATA = {
  apis: [
    {
      id: 'category-api',
      key: 'category',
      name: 'Category API',
      method: 'GET',
      icon: '📂',
      description: 'Browse product categories and retrieve their product listings.',
      category: 'Products',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/categories/{categoryId}/products',
      inputs: [
        { name: 'categoryId', type: 'string', required: true, description: 'Category identifier' }
      ],
      sampleRequest: { categoryId: 'cat-laptops-001' },
      fields: [
        { name: 'id', type: 'string', description: 'Category identifier', exampleValue: 'cat-laptops-001' },
        { name: 'name', type: 'string', description: 'Category display name', exampleValue: 'Laptops' },
        { name: 'slug', type: 'string', description: 'URL-friendly slug', exampleValue: 'laptops' },
        { name: 'description', type: 'string', description: 'Category description', exampleValue: 'Premium laptops for work and gaming' },
        { name: 'parentId', type: 'string', description: 'Parent category ID', exampleValue: 'cat-computers' },
        { name: 'imageUrl', type: 'string', description: 'Category banner image URL', exampleValue: 'https://example.com/laptops-banner.jpg' },
        { name: 'products', type: 'array', description: 'List of product references', exampleValue: ['xps15-001', 'xps13-001', 'xps16-001'] },
        { name: 'totalCount', type: 'number', description: 'Total product count', exampleValue: 8 },
        { name: 'metadata', type: 'object', description: 'SEO and misc metadata', exampleValue: { seoTitle: 'Laptops', keywords: 'laptop, computer' } }
      ]
    },
    {
      id: 'products-api',
      key: 'product',
      name: 'Products API',
      method: 'GET',
      icon: '🛍️',
      description: 'Fetch full product details including price, specs, images and availability.',
      category: 'Products',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/products/{productId}',
      inputs: [
        { name: 'productId', type: 'string', required: true, description: 'Product identifier' }
      ],
      sampleRequest: { productId: 'xps15-001' },
      fields: [
        { name: 'id', type: 'string', description: 'Product identifier', exampleValue: 'xps15-001' },
        { name: 'name', type: 'string', description: 'Product display name', exampleValue: 'Dell XPS 15 Laptop' },
        { name: 'productLine', type: 'string', description: 'Product line', exampleValue: 'XPS' },
        { name: 'badge', type: 'string', description: 'Display badge', exampleValue: 'Best Seller' },
        { name: 'sku', type: 'string', description: 'Stock keeping unit', exampleValue: 'XPS15-9530-7891' },
        { name: 'description', type: 'string', description: 'Long product description', exampleValue: 'The ultimate 15-inch laptop for creators and professionals' },
        { name: 'shortDescription', type: 'string', description: 'Short summary', exampleValue: 'Power meets portability' },
        { name: 'features', type: 'array', description: 'Bullet-point highlights', exampleValue: ['Intel® Core™ Ultra 7', '15.6" OLED 3.5K', 'Up to 13 hrs battery'] },
        { name: 'price', type: 'number', description: 'Base price', exampleValue: 1299.99 },
        { name: 'salePrice', type: 'number', description: 'Discounted price', exampleValue: null },
        { name: 'currency', type: 'string', description: 'Currency code', exampleValue: 'USD' },
        { name: 'images', type: 'array', description: 'Product image URLs', exampleValue: ['xps15-front.jpg', 'xps15-side.jpg'] },
        { name: 'specifications', type: 'object', description: 'Technical spec key-values', exampleValue: { Processor: 'Intel Core Ultra 7', RAM: '16GB' } },
        { name: 'availability', type: 'string', description: 'In Stock / Out of Stock', exampleValue: 'In Stock' },
        { name: 'categoryIds', type: 'array', description: 'Associated categories', exampleValue: ['cat-laptops'] }
      ]
    },
    {
      id: 'ratings-api',
      key: 'ratings',
      name: 'Ratings & Reviews API',
      method: 'GET',
      icon: '⭐',
      description: 'Get customer rating scores, review counts and top reviews for a product.',
      category: 'Products',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/products/{productId}/ratings',
      inputs: [
        { name: 'productId', type: 'string', required: true, description: 'Product identifier' }
      ],
      sampleRequest: { productId: 'xps15-001' },
      fields: [
        { name: 'productId', type: 'string', description: 'Product reference', exampleValue: 'xps15-001' },
        { name: 'ratingNumber', type: 'number', description: 'Rounded rating (1–5)', exampleValue: 5 },
        { name: 'averageRating', type: 'number', description: 'Precise rating average', exampleValue: 4.7 },
        { name: 'reviewCount', type: 'number', description: 'Total number of reviews', exampleValue: 2841 },
        { name: 'ratingDistribution', type: 'object', description: 'Breakdown by star', exampleValue: { 5: 1820, 4: 710, 3: 210, 2: 70, 1: 31 } },
        { name: 'topReviews', type: 'array', description: 'Top 3 customer reviews', exampleValue: [{ author: 'J. Smith', rating: 5, text: 'Incredible display and performance' }] },
        { name: 'lastUpdated', type: 'string', description: 'Last update timestamp', exampleValue: '2025-04-28' }
      ]
    },
    {
      id: 'inventory-api',
      key: 'inventory',
      name: 'Inventory API',
      method: 'GET',
      icon: '📦',
      description: 'Real-time stock counts, warehouse location and availability.',
      category: 'Inventory',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/inventory/{productId}',
      inputs: [
        { name: 'productId', type: 'string', required: true, description: 'Product identifier' }
      ],
      sampleRequest: { productId: 'xps15-001' },
      fields: [
        { name: 'stock', type: 'number', description: 'Total stock', exampleValue: 1250 },
        { name: 'available', type: 'boolean', description: 'Whether item is available', exampleValue: true },
        { name: 'warehouseId', type: 'string', description: 'Primary warehouse identifier', exampleValue: 'wh-austin' },
        { name: 'reserved', type: 'number', description: 'Reserved stock count', exampleValue: 45 },
        { name: 'restockDate', type: 'string', description: 'Expected restock date if unavailable', exampleValue: null }
      ]
    },
    {
      id: 'shipping-api',
      key: 'shipping',
      name: 'Shipping Calculator API',
      method: 'POST',
      icon: '🚚',
      description: 'Calculate shipping cost and delivery time estimates.',
      category: 'Shipping',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/shipping/calculate',
      inputs: [
        { name: 'productId', type: 'string', required: true, description: 'Product identifier' },
        { name: 'country', type: 'string', required: true, description: 'Destination country code' },
        { name: 'zip', type: 'string', required: false, description: 'Destination ZIP code' }
      ],
      sampleRequest: { productId: 'xps15-001', country: 'US', zip: '78701' },
      fields: [
        { name: 'cost', type: 'number', description: 'Shipping cost', exampleValue: 29.99 },
        { name: 'days', type: 'number', description: 'Estimated delivery days', exampleValue: 3 },
        { name: 'express', type: 'boolean', description: 'Express shipping flag', exampleValue: false },
        { name: 'shippingType', type: 'string', description: 'Shipping type label', exampleValue: 'STANDARD' },
        { name: 'carrier', type: 'string', description: 'Shipping carrier', exampleValue: 'UPS' }
      ]
    },
    {
      id: 'users-api',
      key: 'user',
      name: 'Users API',
      method: 'GET',
      icon: '👤',
      description: 'User profile, loyalty tier, order history and saved addresses.',
      category: 'Users',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/users/{userId}',
      inputs: [
        { name: 'userId', type: 'string', required: true, description: 'User identifier' }
      ],
      sampleRequest: { userId: 'user-12345' },
      fields: [
        { name: 'userId', type: 'string', description: 'User identifier', exampleValue: 'user-12345' },
        { name: 'email', type: 'string', description: 'User email', exampleValue: 'john.doe@example.com' },
        { name: 'firstName', type: 'string', description: 'First name', exampleValue: 'John' },
        { name: 'lastName', type: 'string', description: 'Last name', exampleValue: 'Doe' },
        { name: 'tier', type: 'string', description: 'Loyalty tier', exampleValue: 'Gold' },
        { name: 'orders', type: 'array', description: 'Order history references', exampleValue: ['order-001', 'order-002'] },
        { name: 'savedAddresses', type: 'array', description: 'Shipping addresses', exampleValue: [{ street: '123 Main St', city: 'Austin', state: 'TX' }] },
        { name: 'preferences', type: 'object', description: 'User preferences', exampleValue: { newsletter: true, notifications: true } }
      ]
    },
    {
      id: 'pricing-api',
      key: 'pricing',
      name: 'Pricing & Promotions API',
      method: 'GET',
      icon: '💰',
      description: 'Retrieve product pricing, active promotions, and discount calculations.',
      category: 'Commerce',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/pricing/{productId}',
      inputs: [
        { name: 'productId', type: 'string', required: true, description: 'Product identifier' },
        { name: 'userId', type: 'string', required: false, description: 'User for personalized pricing' }
      ],
      sampleRequest: { productId: 'xps15-001', userId: 'user-12345' },
      fields: [
        { name: 'basePrice', type: 'number', description: 'Original base price', exampleValue: 1299.99 },
        { name: 'salePrice', type: 'number', description: 'Discounted price if on sale', exampleValue: 1099.99 },
        { name: 'discount', type: 'number', description: 'Discount amount', exampleValue: 200 },
        { name: 'discountPercent', type: 'number', description: 'Discount percentage', exampleValue: 15 },
        { name: 'promotions', type: 'array', description: 'Active promotional codes', exampleValue: ['SAVE200', 'SUMMER15'] },
        { name: 'priceExpiry', type: 'string', description: 'Price validity expiry', exampleValue: '2025-06-30' }
      ]
    },
    {
      id: 'recommendations-api',
      key: 'recommendations',
      name: 'Recommendations API',
      method: 'GET',
      icon: '🎯',
      description: 'AI-powered product recommendations based on user behavior and product context.',
      category: 'Commerce',
      baseUrl: 'https://api.dell.com',
      endpoint: '/api/v1/recommendations',
      inputs: [
        { name: 'productId', type: 'string', required: false, description: 'Seed product for similar recommendations' },
        { name: 'userId', type: 'string', required: false, description: 'User for personalized recommendations' },
        { name: 'limit', type: 'number', required: false, description: 'Max number of recommendations' }
      ],
      sampleRequest: { productId: 'xps15-001', userId: 'user-12345', limit: 10 },
      fields: [
        { name: 'items', type: 'array', description: 'List of recommended product IDs', exampleValue: ['xps13-001', 'xps16-001', 'latitude14-001'] },
        { name: 'reason', type: 'string', description: 'Reason for recommendation', exampleValue: 'Similar products' },
        { name: 'score', type: 'number', description: 'Confidence score', exampleValue: 0.92 },
        { name: 'model', type: 'string', description: 'Recommendation model used', exampleValue: 'collaborative-v3' }
      ]
    }
  ],

  products: [
    {
      id: 'xps15-001',
      name: 'Dell XPS 15 (9530)',
      price: 1299.99,
      salePrice: null,
      badge: 'Best Seller',
      rating: 4.7,
      reviews: 2841,
      image: 'linear-gradient(135deg, #1a1a2e, #16213e)',
      features: ['Intel® Core™ Ultra 7', '15.6" OLED 3.5K', '16GB DDR5 RAM', 'Up to 13 hrs battery']
    },
    {
      id: 'xps13-001',
      name: 'Dell XPS 13 (9340)',
      price: 999.99,
      salePrice: 899.99,
      badge: 'Sale',
      rating: 4.5,
      reviews: 1654,
      image: 'linear-gradient(135deg, #2d1b69, #11998e)',
      features: ['Intel® Core™ Ultra 5', '13.4" FHD+ Touch', '8GB LPDDR5', 'All-day battery']
    },
    {
      id: 'alienware-m18',
      name: 'Alienware m18 R2',
      price: 2499.99,
      salePrice: null,
      badge: 'Gaming',
      rating: 4.8,
      reviews: 987,
      image: 'linear-gradient(135deg, #0a0a0a, #1a0533)',
      features: ['Intel® Core™ i9-14900HX', 'NVIDIA RTX 4080', '18" QHD+ 240Hz', '32GB DDR5']
    }
  ],

  filterGroups: [
    {
      id: 'price',
      label: 'Price Range',
      options: [
        { label: 'Under $500', value: '0-500', count: 12 },
        { label: '$500 – $1,000', value: '500-1000', count: 24 },
        { label: '$1,000 – $1,500', value: '1000-1500', count: 18 },
        { label: 'Over $1,500', value: '1500+', count: 8 }
      ]
    },
    {
      id: 'processor',
      label: 'Processor',
      options: [
        { label: 'Intel Core Ultra 7', value: 'ultra7', count: 10 },
        { label: 'Intel Core Ultra 5', value: 'ultra5', count: 14 },
        { label: 'Intel Core i9', value: 'i9', count: 6 },
        { label: 'AMD Ryzen 9', value: 'ryzen9', count: 4 }
      ]
    },
    {
      id: 'memory',
      label: 'RAM',
      options: [
        { label: '8GB', value: '8gb', count: 15 },
        { label: '16GB', value: '16gb', count: 22 },
        { label: '32GB', value: '32gb', count: 11 },
        { label: '64GB', value: '64gb', count: 4 }
      ]
    },
    {
      id: 'display',
      label: 'Display',
      options: [
        { label: '13"', value: '13', count: 8 },
        { label: '14"', value: '14', count: 16 },
        { label: '15"', value: '15', count: 14 },
        { label: '16"', value: '16', count: 6 },
        { label: '18"', value: '18', count: 3 }
      ]
    }
  ],

  webparts: [
    {
      id: 'hero-banner',
      name: 'Hero Banner',
      icon: '🖼️',
      description: 'Full-width hero banner with heading and sub-heading',
      thumbnailHtml: '<div style="background: linear-gradient(135deg, #0076CE, #005EA8); width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:white; font-size:11px; font-weight:500;">Hero Banner</div>',
      slots: [
        { key: 'heading', label: 'Heading', type: 'string' },
        { key: 'subheading', label: 'Subheading', type: 'string' }
      ]
    },
    {
      id: 'filter-nav',
      name: 'Filter Navigation',
      icon: '🔧',
      description: 'Left-rail filter panel with checkboxes',
      thumbnailHtml: '<div style="background:#F5F5F5; width:100%; height:100%; padding:4px;"><div style="background:#C8C9C9; height:10px; margin-bottom:4px; border-radius:2px;"></div><div style="background:#C8C9C9; height:8px; margin-bottom:2px; border-radius:2px; width:80%;"></div><div style="background:#C8C9C9; height:8px; margin-bottom:2px; border-radius:2px; width:70%;"></div><div style="background:#C8C9C9; height:8px; border-radius:2px; width:60%;"></div></div>',
      slots: [
        { key: 'filterGroups', label: 'Filter Groups', type: 'array' }
      ]
    },
    {
      id: 'results-bar',
      name: 'Results Bar',
      icon: '📊',
      description: 'Shows result count and sort controls',
      thumbnailHtml: '<div style="background:#fff; border-bottom:1px solid #C8C9C9; width:100%; height:100%; padding:4px; display:flex; align-items:center; font-size:10px; color:#6E6E6E;">Showing 8 results · Sort ▼</div>',
      slots: [
        { key: 'resultCount', label: 'Result Count', type: 'number' }
      ]
    },
    {
      id: 'product-grid',
      name: 'Product Grid',
      icon: '🔲',
      description: '3-column responsive product card grid',
      thumbnailHtml: '<div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:2px; width:100%; height:100%;"><div style="background:#E5F2FB; border-radius:2px;"></div><div style="background:#E5F2FB; border-radius:2px;"></div><div style="background:#E5F2FB; border-radius:2px;"></div></div>',
      slots: [
        { key: 'products', label: 'Products Array', type: 'array' }
      ]
    },
    {
      id: 'product-card',
      name: 'Product Card',
      icon: '🏷️',
      description: 'Single product card with image, price and CTA',
      thumbnailHtml: '<div style="background:#fff; border:1px solid #C8C9C9; border-radius:2px; width:100%; height:100%; padding:4px;"><div style="background:#F5F5F5; height:40px; margin-bottom:4px; border-radius:2px;"></div><div style="background:#C8C9C9; height:6px; margin-bottom:2px; border-radius:2px;"></div><div style="background:#0076CE; height:14px; border-radius:2px; width:70%;"></div></div>',
      slots: [
        { key: 'name', label: 'Product Name', type: 'string' },
        { key: 'price', label: 'Price', type: 'number' },
        { key: 'rating', label: 'Rating', type: 'number' }
      ]
    },
    {
      id: 'rating-summary',
      name: 'Rating Summary',
      icon: '⭐',
      description: 'Star rating display with review count',
      thumbnailHtml: '<div style="display:flex; align-items:center; gap:4px; font-size:10px; padding:4px;">⭐⭐⭐⭐⭐ <span style="color:#6E6E6E;">4.7 · 2841 reviews</span></div>',
      slots: [
        { key: 'averageRating', label: 'Average Rating', type: 'number' },
        { key: 'reviewCount', label: 'Review Count', type: 'number' }
      ]
    },
    {
      id: 'product-stack',
      name: 'Product Stack',
      icon: '📋',
      description: 'Vertical list of product items with image and price',
      thumbnailHtml: '<div style="width:100%; height:100%;"><div style="display:flex; gap:4px; padding:4px; border-bottom:1px solid #F0F0F0;"><div style="background:#F5F5F5; width:20px; height:20px; border-radius:2px; flex-shrink:0;"></div><div style="flex:1;"><div style="background:#C8C9C9; height:6px; border-radius:2px; margin-bottom:2px;"></div><div style="background:#E5F2FB; height:6px; border-radius:2px; width:60%;"></div></div></div></div>',
      slots: [
        { key: 'products', label: 'Products Array', type: 'array' }
      ]
    },
    {
      id: 'compare-bar',
      name: 'Compare Bar',
      icon: '⚖️',
      description: 'Sticky bottom bar for comparing selected products',
      thumbnailHtml: '<div style="background:#1D2023; color:white; display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:500; width:100%; height:100%;">Compare Products</div>',
      slots: []
    }
  ],

  orchestrations: [
    {
      id: 'orc-001',
      name: 'Laptop Catalog Page',
      description: 'Full product listing for Dell laptops with ratings and inventory',
      version: '1.0.0',
      apis: ['category-api', 'products-api', 'ratings-api'],
      fields: {
        'category-api': ['id', 'name', 'description', 'products', 'totalCount'],
        'products-api': ['id', 'name', 'badge', 'features', 'price', 'salePrice', 'images', 'availability'],
        'ratings-api': ['averageRating', 'reviewCount', 'topReviews']
      },
      steps: [
        {
          callId: 'get-category',
          apiId: 'category-api',
          method: 'GET',
          endpoint: '/api/v1/categories/{categoryId}/products',
          fields: ['id', 'name', 'description', 'products', 'totalCount'],
          inputMapping: { categoryId: 'cat-laptops-001' },
          responseMapping: {},
          execution: { mode: 'parallel' },
          iteration: {
            source: '$response.products',
            itemVariable: 'productId',
            execution: { mode: 'parallel', maxParallel: 10 },
            steps: [
              {
                callId: 'get-product-details',
                apiId: 'products-api',
                method: 'GET',
                endpoint: '/api/v1/products/{productId}',
                fields: ['id', 'name', 'badge', 'features', 'price', 'salePrice', 'images', 'availability'],
                inputMapping: { productId: '$item' },
                responseMapping: {},
                execution: { mode: 'parallel' },
                iteration: null,
                children: null
              },
              {
                callId: 'get-product-ratings',
                apiId: 'ratings-api',
                method: 'GET',
                endpoint: '/api/v1/products/{productId}/ratings',
                fields: ['averageRating', 'reviewCount', 'topReviews'],
                inputMapping: { productId: '$item' },
                responseMapping: {},
                execution: { mode: 'parallel' },
                iteration: null,
                children: null
              }
            ]
          },
          children: null
        }
      ],
      pageLayout: [],
      createdAt: '2025-05-01T10:00:00Z',
      updatedAt: '2025-05-05T14:30:00Z'
    },
    {
      id: 'orc-002',
      name: 'Home Deals Rotator',
      description: 'Featured deals carousel for homepage with pricing and shipping info',
      version: '1.0.0',
      apis: ['products-api', 'pricing-api', 'shipping-api'],
      fields: {
        'products-api': ['id', 'name', 'price', 'salePrice', 'badge', 'images'],
        'pricing-api': ['salePrice', 'discount', 'discountPercent', 'promotions'],
        'shipping-api': ['cost', 'days', 'shippingType']
      },
      steps: [
        {
          callId: 'get-featured-products',
          apiId: 'products-api',
          method: 'GET',
          endpoint: '/api/v1/products/{productId}',
          fields: ['id', 'name', 'price', 'salePrice', 'badge', 'images'],
          inputMapping: { productId: 'xps15-001' },
          responseMapping: {},
          execution: { mode: 'parallel' },
          iteration: null,
          children: {
            steps: [
              {
                callId: 'get-pricing',
                apiId: 'pricing-api',
                method: 'GET',
                endpoint: '/api/v1/pricing/{productId}',
                fields: ['salePrice', 'discount', 'discountPercent', 'promotions'],
                inputMapping: { productId: '$parent.id' },
                responseMapping: {},
                execution: { mode: 'parallel' },
                iteration: null,
                children: null
              }
            ]
          }
        }
      ],
      pageLayout: [],
      createdAt: '2025-05-03T09:00:00Z',
      updatedAt: '2025-05-03T09:00:00Z'
    },
    {
      id: 'orc-003',
      name: 'Gaming Category Page',
      description: 'Gaming products with detailed specs and real-time inventory',
      version: '2.1.0',
      apis: ['category-api', 'products-api', 'inventory-api'],
      fields: {
        'category-api': ['id', 'name', 'description', 'imageUrl'],
        'products-api': ['id', 'name', 'price', 'badge', 'features', 'specifications'],
        'inventory-api': ['stock', 'available']
      },
      steps: [
        {
          callId: 'get-gaming-category',
          apiId: 'category-api',
          method: 'GET',
          endpoint: '/api/v1/categories/{categoryId}/products',
          fields: ['id', 'name', 'description', 'imageUrl'],
          inputMapping: { categoryId: 'cat-gaming-001' },
          responseMapping: {},
          execution: { mode: 'parallel' },
          iteration: null,
          children: {
            steps: [
              {
                callId: 'get-gaming-products',
                apiId: 'products-api',
                method: 'GET',
                endpoint: '/api/v1/products/{productId}',
                fields: ['id', 'name', 'price', 'badge', 'features', 'specifications'],
                inputMapping: { productId: 'alienware-m18' },
                responseMapping: {},
                execution: { mode: 'parallel' },
                iteration: null,
                children: {
                  steps: [
                    {
                      callId: 'get-inventory',
                      apiId: 'inventory-api',
                      method: 'GET',
                      endpoint: '/api/v1/inventory/{productId}',
                      fields: ['stock', 'available'],
                      inputMapping: { productId: '$parent.id' },
                      responseMapping: {},
                      execution: { mode: 'parallel' },
                      iteration: null,
                      children: null
                    }
                  ]
                }
              }
            ]
          }
        }
      ],
      pageLayout: [],
      createdAt: '2025-04-28T16:00:00Z',
      updatedAt: '2025-04-28T16:00:00Z'
    },
    {
      id: 'orc-004',
      name: 'Product Detail Page',
      description: 'Full product detail page data with ratings, inventory, pricing and recommendations',
      version: '3.0.0',
      apis: ['products-api', 'ratings-api', 'inventory-api', 'pricing-api', 'recommendations-api'],
      fields: {
        'products-api': ['id', 'name', 'productLine', 'badge', 'description', 'features', 'price', 'salePrice', 'images', 'specifications', 'availability'],
        'ratings-api': ['averageRating', 'reviewCount', 'ratingDistribution', 'topReviews'],
        'inventory-api': ['stock', 'available', 'warehouseId'],
        'pricing-api': ['basePrice', 'salePrice', 'discount', 'discountPercent', 'promotions'],
        'recommendations-api': ['items', 'reason']
      },
      steps: [
        {
          callId: 'get-product',
          apiId: 'products-api',
          method: 'GET',
          endpoint: '/api/v1/products/{productId}',
          fields: ['id', 'name', 'productLine', 'badge', 'description', 'features', 'price', 'salePrice', 'images', 'specifications', 'availability'],
          inputMapping: { productId: '$context.productId' },
          responseMapping: {},
          execution: { mode: 'parallel' },
          iteration: null,
          children: null
        }
      ],
      pageLayout: [],
      createdAt: '2025-04-15T12:00:00Z',
      updatedAt: '2025-05-08T09:00:00Z'
    }
  ]
};
