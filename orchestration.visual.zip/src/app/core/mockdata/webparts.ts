import { Webpart } from '../../models/webpart.model';

export const MOCK_WEBPARTS: Webpart[] = [
  {
    id: 'hero-banner',
    type: 'hero',
    name: 'Hero Banner',
    description: 'Large banner with heading, subheading, and call-to-action button',
    icon: '🎨',
    properties: [
      { name: 'heading', type: 'string', value: 'Welcome to Our Store' },
      { name: 'subheading', type: 'string', value: 'Discover amazing products' },
      { name: 'ctaText', type: 'string', value: 'Shop Now' },
      { name: 'ctaUrl', type: 'string', value: '/shop' },
      { name: 'backgroundImage', type: 'string', value: '' },
      { name: 'height', type: 'select', value: 'medium', options: ['small', 'medium', 'large'] }
    ],
    dataBindings: []
  },
  {
    id: 'filter-nav',
    type: 'filter',
    name: 'Filter Navigation',
    description: 'Sidebar with category, price, and attribute filters',
    icon: '🔍',
    properties: [
      { name: 'title', type: 'string', value: 'Filters' },
      { name: 'showPrice', type: 'boolean', value: true },
      { name: 'showCategories', type: 'boolean', value: true },
      { name: 'collapsible', type: 'boolean', value: true }
    ],
    dataBindings: []
  },
  {
    id: 'results-bar',
    type: 'results',
    name: 'Results Bar',
    description: 'Shows result count, sorting options, and view toggle',
    icon: '📊',
    properties: [
      { name: 'showCount', type: 'boolean', value: true },
      { name: 'showSort', type: 'boolean', value: true },
      { name: 'sortOptions', type: 'select', value: 'relevance', options: ['relevance', 'price-low', 'price-high', 'newest', 'rating'] },
      { name: 'viewMode', type: 'select', value: 'grid', options: ['grid', 'list'] }
    ],
    dataBindings: []
  },
  {
    id: 'product-grid',
    type: 'grid',
    name: 'Product Grid',
    description: 'Responsive grid layout for displaying products',
    icon: '📦',
    properties: [
      { name: 'columns', type: 'select', value: '3', options: ['2', '3', '4', '5'] },
      { name: 'gap', type: 'select', value: 'medium', options: ['small', 'medium', 'large'] },
      { name: 'showBadges', type: 'boolean', value: true },
      { name: 'showPrice', type: 'boolean', value: true },
      { name: 'showRating', type: 'boolean', value: true },
      { name: 'itemsPerPage', type: 'number', value: 12 }
    ],
    dataBindings: []
  },
  {
    id: 'product-card',
    type: 'card',
    name: 'Product Card',
    description: 'Individual product card with image, title, price, and rating',
    icon: '🏷️',
    properties: [
      { name: 'showImage', type: 'boolean', value: true },
      { name: 'showTitle', type: 'boolean', value: true },
      { name: 'showPrice', type: 'boolean', value: true },
      { name: 'showRating', type: 'boolean', value: true },
      { name: 'showBadge', type: 'boolean', value: true },
      { name: 'imageHeight', type: 'number', value: 250 },
      { name: 'hoverEffect', type: 'select', value: 'lift', options: ['none', 'lift', 'shadow', 'zoom'] }
    ],
    dataBindings: []
  },
  {
    id: 'rating-summary',
    type: 'rating',
    name: 'Rating Summary',
    description: 'Displays average rating, review count, and rating distribution',
    icon: '⭐',
    properties: [
      { name: 'showDistribution', type: 'boolean', value: true },
      { name: 'showReviewCount', type: 'boolean', value: true },
      { name: 'showTopReviews', type: 'boolean', value: true },
      { name: 'maxReviewsShown', type: 'number', value: 3 },
      { name: 'size', type: 'select', value: 'medium', options: ['small', 'medium', 'large'] }
    ],
    dataBindings: []
  },
  {
    id: 'product-stack',
    type: 'stack',
    name: 'Product Stack',
    description: 'Vertical stack layout for detailed product information',
    icon: '📋',
    properties: [
      { name: 'showImage', type: 'boolean', value: true },
      { name: 'showDescription', type: 'boolean', value: true },
      { name: 'showSpecifications', type: 'boolean', value: true },
      { name: 'showAvailability', type: 'boolean', value: true },
      { name: 'imagePosition', type: 'select', value: 'top', options: ['top', 'left', 'right'] }
    ],
    dataBindings: []
  },
  {
    id: 'compare-bar',
    type: 'compare',
    name: 'Compare Bar',
    description: 'Side-by-side product comparison table',
    icon: '⚖️',
    properties: [
      { name: 'maxProducts', type: 'number', value: 4 },
      { name: 'showImages', type: 'boolean', value: true },
      { name: 'showPrice', type: 'boolean', value: true },
      { name: 'showSpecifications', type: 'boolean', value: true },
      { name: 'striped', type: 'boolean', value: true }
    ],
    dataBindings: []
  }
];
