import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MOCKDATA } from '@core/mockdata/mockdata';

const LS_KEY = 'orc_orchestrations';
const LS_DRAFT = 'orc_draft';
const LS_BUILDER_DRAFT = 'orc_builder_draft';
const LS_CURRENT_ID = 'orc_current_id';
const LS_APIS_KEY = 'orc_apis';

@Injectable({ providedIn: 'root' })
export class StateService {

  private _orchestrations$ = new BehaviorSubject<any[]>([]);
  orchestrations$ = this._orchestrations$.asObservable();

  constructor() {
    this.init();
  }

  init(): void {
    if (!localStorage.getItem(LS_KEY)) {
      const initial = JSON.parse(JSON.stringify(MOCKDATA.orchestrations));
      localStorage.setItem(LS_KEY, JSON.stringify(initial));
    }
    this._orchestrations$.next(this.getOrchestrations());
  }

  // ---- Orchestrations ----

  getOrchestrations(): any[] {
    try {
      return JSON.parse(localStorage.getItem(LS_KEY) || '[]');
    } catch { return []; }
  }

  setOrchestrations(orcs: any[]): void {
    localStorage.setItem(LS_KEY, JSON.stringify(orcs));
    this._orchestrations$.next(orcs);
  }

  getOrchestrationById(id: string): any | null {
    return this.getOrchestrations().find((o: any) => o.id === id) || null;
  }

  saveOrchestration(orc: any): void {
    const orcs = this.getOrchestrations();
    const idx = orcs.findIndex((o: any) => o.id === orc.id);
    if (idx >= 0) {
      orcs[idx] = orc;
    } else {
      orcs.push(orc);
    }
    this.setOrchestrations(orcs);
  }

  deleteOrchestration(id: string): void {
    const orcs = this.getOrchestrations().filter((o: any) => o.id !== id);
    this.setOrchestrations(orcs);
  }

  cloneOrchestration(id: string): any | null {
    const orc = this.getOrchestrationById(id);
    if (!orc) return null;
    const clone = JSON.parse(JSON.stringify(orc));
    clone.id = 'orc_' + Date.now();
    clone.name = orc.name + ' (Copy)';
    clone.createdAt = new Date().toISOString();
    clone.updatedAt = new Date().toISOString();
    this.saveOrchestration(clone);
    return clone;
  }

  // ---- Draft (create/edit flow in flyout) ----

  getDraft(): any | null {
    try {
      const raw = localStorage.getItem(LS_DRAFT);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }

  setDraft(draft: any): void {
    localStorage.setItem(LS_DRAFT, JSON.stringify(draft));
  }

  clearDraft(): void {
    localStorage.removeItem(LS_DRAFT);
  }

  // ---- Builder Draft ----

  getBuilderDraft(): any | null {
    try {
      const raw = localStorage.getItem(LS_BUILDER_DRAFT);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }

  setBuilderDraft(draft: any): void {
    localStorage.setItem(LS_BUILDER_DRAFT, JSON.stringify(draft));
  }

  clearBuilderDraft(): void {
    localStorage.removeItem(LS_BUILDER_DRAFT);
  }

  // ---- Current ID (for page builder routing) ----

  getCurrentId(): string | null {
    return localStorage.getItem(LS_CURRENT_ID);
  }

  setCurrentId(id: string): void {
    localStorage.setItem(LS_CURRENT_ID, id);
  }

  // ---- API Helpers ----

  getAllApis(): any[] {
    return [...MOCKDATA.apis, ...this.getImportedApis()];
  }

  getApiById(id: string): any | null {
    const all = this.getAllApis();
    return all.find((a: any) => a.id === id) || null;
  }

  getApiCategories(): string[] {
    const all = this.getAllApis();
    const cats = new Set(all.map((a: any) => a.category));
    return Array.from(cats);
  }

  getImportedApis(): any[] {
    try {
      return JSON.parse(localStorage.getItem(LS_APIS_KEY) || '[]');
    } catch {
      return [];
    }
  }

  importApis(apis: any[]): void {
    const existing = this.getImportedApis();
    const merged = [...existing];
    apis.forEach((api) => {
      const idx = merged.findIndex((e: any) => e.id === api.id);
      if (idx >= 0) {
        merged[idx] = api;
      } else {
        merged.push(api);
      }
    });
    localStorage.setItem(LS_APIS_KEY, JSON.stringify(merged));
  }

  // ---- Webparts ----

  getAllWebparts(): any[] {
    return MOCKDATA.webparts;
  }

  getWebpartById(id: string): any | null {
    return MOCKDATA.webparts.find((w: any) => w.id === id) || null;
  }

  // ---- Products & Filters ----

  getProducts(): any[] {
    return MOCKDATA.products;
  }

  getFilterGroups(): any[] {
    return MOCKDATA.filterGroups;
  }

  // ---- Step Tree Helpers ----

  getStepById(orc: any, callId: string): any | null {
    if (!orc || !Array.isArray(orc.steps)) return null;
    // Flat DAG lookup first
    const flat = orc.steps.find((s: any) => s.callId === callId);
    if (flat) return flat;
    // Fallback: legacy tree search
    return this._findStep(orc.steps, callId);
  }

  private _findStep(steps: any[], callId: string): any | null {
    for (const step of steps) {
      if (step.callId === callId) return step;
      if (step.iteration && Array.isArray(step.iteration.steps)) {
        const found = this._findStep(step.iteration.steps, callId);
        if (found) return found;
      }
      if (step.children && Array.isArray(step.children.steps)) {
        const found = this._findStep(step.children.steps, callId);
        if (found) return found;
      }
    }
    return null;
  }

  addRootStep(orc: any, stepNode: any): void {
    if (!orc.steps) orc.steps = [];
    orc.steps.push(stepNode);
  }

  addChildStep(orc: any, parentCallId: string, stepNode: any): void {
    const parent = this.getStepById(orc, parentCallId);
    if (!parent) return;
    if (!parent.children) parent.children = { steps: [] };
    if (!parent.children.steps) parent.children.steps = [];
    parent.children.steps.push(stepNode);
  }

  addIterationStep(orc: any, parentCallId: string, stepNode: any): void {
    const parent = this.getStepById(orc, parentCallId);
    if (!parent) return;
    if (!parent.iteration) parent.iteration = { source: '', itemVariable: 'item', execution: { mode: 'parallel', maxParallel: 20 }, steps: [] };
    if (!parent.iteration.steps) parent.iteration.steps = [];
    parent.iteration.steps.push(stepNode);
  }

  removeStep(orc: any, callId: string): void {
    if (!orc || !Array.isArray(orc.steps)) return;
    orc.steps = this._removeFromList(orc.steps, callId);
    // Clean dependency references (DAG model)
    orc.steps.forEach((s: any) => {
      if (Array.isArray(s.dependencies)) {
        s.dependencies = s.dependencies.filter((d: string) => d !== callId);
      }
    });
  }

  private _removeFromList(steps: any[], callId: string): any[] {
    const filtered = steps.filter((s: any) => s.callId !== callId);
    return filtered.map((s: any) => {
      if (s.iteration && Array.isArray(s.iteration.steps)) {
        s.iteration.steps = this._removeFromList(s.iteration.steps, callId);
      }
      if (s.children && Array.isArray(s.children.steps)) {
        s.children.steps = this._removeFromList(s.children.steps, callId);
      }
      return s;
    });
  }

  updateStep(orc: any, callId: string, updates: Partial<any>): void {
    const step = this.getStepById(orc, callId);
    if (step) Object.assign(step, updates);
  }

  setIteration(orc: any, callId: string, iterConfig: any): void {
    const step = this.getStepById(orc, callId);
    if (!step) return;
    if (!step.iteration) step.iteration = { steps: [] };
    step.iteration = { ...step.iteration, ...iterConfig };
  }

  removeIteration(orc: any, callId: string): void {
    const step = this.getStepById(orc, callId);
    if (step) step.iteration = null;
  }

  // ---- Unified Response Generator ----

  generateResponse(orc: any): any {
    if (!orc) return {};
    const response: any = {};
    (orc.apis || []).forEach((apiId: string) => {
      const api = this.getApiById(apiId);
      if (!api) return;
      const selectedFields: string[] = (orc.fields || {})[apiId] || [];
      const apiData: any = {};
      selectedFields.forEach((fieldName: string) => {
        const field = api.fields.find((f: any) => f.name === fieldName);
        if (field) apiData[fieldName] = field.exampleValue;
      });
      response[api.key] = apiData;
    });
    return response;
  }

  // ---- Blank Orchestration ----

  createBlankOrchestration(): any {
    const now = new Date().toISOString();
    return {
      id: 'orc_' + Date.now(),
      orchestrationId: '',
      name: 'New Orchestration',
      description: '',
      version: '1.0.0',
      execution: { mode: 'parallel', maxParallel: 20, continueOnError: true },
      context: { requestId: '$system.requestId', traceId: '$system.traceId' },
      variables: {},
      requestData: {},
      defaults: {
        cache: { enabled: true, ttlSeconds: 300 },
        retryPolicy: { maxRetries: 0, backoff: 'exponential', retryableStatusCodes: [429, 502, 503] },
        timeout: { connectMs: 1000, readMs: 10000 }
      },
      steps: [],
      output: {},
      errorHandling: { continueOnError: true, globalFallback: { status: 'PARTIAL_SUCCESS' } },
      observability: {
        logging: { enabled: false, logRequest: false, logResponse: false, maskFields: [] },
        metrics: { enabled: false },
        tracing: { enabled: false }
      },
      pageLayout: [],
      createdAt: now,
      updatedAt: now
    };
  }

  // ---- DAG helpers ----

  addDependency(orc: any, callId: string, dependsOn: string): void {
    const step = this.getStepById(orc, callId);
    if (!step) return;
    if (!Array.isArray(step.dependencies)) step.dependencies = [];
    if (!step.dependencies.includes(dependsOn)) step.dependencies.push(dependsOn);
  }

  removeDependency(orc: any, callId: string, dependsOn: string): void {
    const step = this.getStepById(orc, callId);
    if (!step) return;
    step.dependencies = (step.dependencies || []).filter((d: string) => d !== dependsOn);
  }

  updateOutputMapping(orc: any, output: any): void {
    orc.output = output;
  }

  updateOrcSettings(orc: any, settings: Partial<any>): void {
    Object.assign(orc, settings);
  }

  getAllCallIds(orc: any): string[] {
    if (!orc || !Array.isArray(orc.steps)) return [];
    return orc.steps.map((s: any) => s.callId).filter(Boolean);
  }

  // ---- Version Bump ----

  bumpVersion(version: string): string {
    const parts = version.split('.');
    const patch = parseInt(parts[2] || '0', 10) + 1;
    return `${parts[0]}.${parts[1]}.${patch}`;
  }

  // ---- Notify subscribers ----

  notifyChange(): void {
    this._orchestrations$.next(this.getOrchestrations());
  }
}
