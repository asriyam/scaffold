import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Api, Orchestration, Webpart } from '@models';
import { MOCK_APIS, MOCK_ORCHESTRATION_DEFINITIONS, MOCK_WEBPARTS } from '@core/mockdata';

@Injectable({ providedIn: 'root' })
export class MockDataService {
  // API Methods
  getApis(): Observable<Api[]> {
    return of(MOCK_APIS);
  }

  getApiById(id: string): Observable<Api | undefined> {
    return of(MOCK_APIS.find(api => api.id === id));
  }

  getApisByCategory(category: string): Observable<Api[]> {
    return of(MOCK_APIS.filter(api => api.category === category));
  }

  getApiCategories(): Observable<string[]> {
    const categories = new Set(MOCK_APIS.map(api => api.category));
    return of(Array.from(categories));
  }

  searchApis(query: string): Observable<Api[]> {
    const lowerQuery = query.toLowerCase();
    return of(MOCK_APIS.filter(api =>
      api.name.toLowerCase().includes(lowerQuery) ||
      api.description.toLowerCase().includes(lowerQuery) ||
      api.category.toLowerCase().includes(lowerQuery)
    ));
  }

  getApiFieldTypes(apiId: string): Observable<Record<string, string>> {
    const api = MOCK_APIS.find(a => a.id === apiId);
    if (!api) return of({});
    const fieldTypes: Record<string, string> = {};
    api.outputs.forEach(field => {
      fieldTypes[field.name] = field.type;
    });
    return of(fieldTypes);
  }

  getApiSampleResponse(apiId: string): Observable<Record<string, any> | null> {
    const api = MOCK_APIS.find(a => a.id === apiId);
    if (!api || !api.examples || api.examples.length === 0) return of(null);
    return of(api.examples[0].output);
  }

  // Orchestration Methods
  getOrchestrations(): Observable<Orchestration[]> {
    return of(MOCK_ORCHESTRATION_DEFINITIONS);
  }

  getOrchestrationById(id: string): Observable<Orchestration | undefined> {
    return of(MOCK_ORCHESTRATION_DEFINITIONS.find(orch => orch.id === id));
  }

  // Webpart Methods
  getWebparts(): Observable<Webpart[]> {
    return of(MOCK_WEBPARTS);
  }

  getWebpartById(id: string): Observable<Webpart | undefined> {
    return of(MOCK_WEBPARTS.find(wp => wp.id === id));
  }

  getWebpartsByType(type: string): Observable<Webpart[]> {
    return of(MOCK_WEBPARTS.filter(wp => wp.type === type));
  }
}
