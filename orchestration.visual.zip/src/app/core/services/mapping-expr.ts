// Helpers for parsing, formatting and resolving input-mapping expressions.
//
// Expression forms produced by the new picker:
//   $input.<path>            → flow input field
//   $loop.<path> | $loop     → current iteration item
//   $steps.<callId>.<path>   → output field of a previous step
//
// Legacy forms still parse (so older orchestrations render correctly):
//   $request.<path>          → same as $input.<path>
//   $context.<path>          → same as $input.<path>
//   $item.<path> | $item     → same as $loop.<path>
//   $<callId>.<path>         → same as $steps.<callId>.<path> (requires knownCallIds)

export type MappingExpr =
  | { kind: 'flowInput'; path: string }
  | { kind: 'loopItem'; path: string }
  | { kind: 'stepOutput'; callId: string; path: string }
  | { kind: 'literal'; value: any }
  | { kind: 'unknown'; raw: string };

export function parseMappingExpr(value: any, knownCallIds: string[] = []): MappingExpr {
  if (typeof value !== 'string') {
    return { kind: 'literal', value };
  }
  const v = value.trim();
  if (!v.startsWith('$')) {
    return { kind: 'literal', value };
  }
  const body = v.slice(1);
  const firstDot = body.indexOf('.');
  const head = firstDot >= 0 ? body.slice(0, firstDot) : body;
  const tail = firstDot >= 0 ? body.slice(firstDot + 1) : '';

  if (head === 'input' || head === 'request' || head === 'context') {
    return { kind: 'flowInput', path: tail };
  }
  if (head === 'loop' || head === 'item' || head === 'current') {
    return { kind: 'loopItem', path: tail };
  }
  if (head === 'steps') {
    const secondDot = tail.indexOf('.');
    const callId = secondDot >= 0 ? tail.slice(0, secondDot) : tail;
    const path = secondDot >= 0 ? tail.slice(secondDot + 1) : '';
    return { kind: 'stepOutput', callId, path };
  }
  if (knownCallIds.includes(head)) {
    return { kind: 'stepOutput', callId: head, path: tail };
  }
  return { kind: 'unknown', raw: value };
}

export function formatMappingExpr(expr: MappingExpr): any {
  switch (expr.kind) {
    case 'flowInput':
      return expr.path ? `$input.${expr.path}` : '$input';
    case 'loopItem':
      return expr.path ? `$loop.${expr.path}` : '$loop';
    case 'stepOutput':
      return expr.path ? `$steps.${expr.callId}.${expr.path}` : `$steps.${expr.callId}`;
    case 'literal':
      return expr.value;
    case 'unknown':
      return expr.raw;
  }
}

export function getValueAtPath(obj: any, path: string): any {
  if (obj == null) return undefined;
  if (!path) return obj;
  const parts = path.split('.');
  let cur: any = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

// Render a sample value as a short string for chips like `= "p_1001"` / `= 3 items` / `= USD`.
export function formatSampleValueForDisplay(value: any): string {
  if (value === undefined) return '—';
  if (value === null) return 'null';
  if (typeof value === 'string') return `"${value}"`;
  if (Array.isArray(value)) return `${value.length} items`;
  if (typeof value === 'object') return '{…}';
  return String(value);
}
