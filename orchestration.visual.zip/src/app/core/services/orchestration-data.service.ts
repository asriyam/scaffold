import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class OrchestrationDataService {

  constructor(private http: HttpClient) {}

  /**
   * Fetch an orchestration item from Content Studio by itemId.
   * Returns { item, orc } where `item` is the raw API response and
   * `orc` is the parsed OrchestrationContent JSON.
   */
  fetchFromContentStudio(
    itemId: string,
    collectionId: string,
    contentType: string
  ): Observable<{ item: any; orc: any }> {
    const url = `https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/GetItem`
      + `?collectionId=${encodeURIComponent(collectionId)}`
      + `&contentType=${encodeURIComponent(contentType)}`
      + `&itemId=${encodeURIComponent(itemId)}`;

    return this.http.get<any>(url).pipe(
      map(res => {
        let orchContent = res?.DynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.orchestrationContent
          || res?.dynamicProperties?.OrchestrationContent
          || res?.DynamicProperties?.orchestrationContent;
        if (typeof orchContent === 'string') {
          try { orchContent = JSON.parse(orchContent); } catch (_) {}
        }
        return { item: res, orc: orchContent ?? {} };
      })
    );
  }

  /**
   * Fetch the CMS API list used for resolving inputMapping on imported APIs.
   * Returns an array of normalised API descriptors.
   */
  fetchCmsApiList(): Observable<any[]> {
    const url = 'https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemReaderApi/GetItems?findMissingItems=false';
    const payload = {
      sourceFields: ['Id', 'Key', 'Name', 'DynamicProperties'],
      size: 100,
      blockNumber: 1,
      searchText: '',
      collectionIndexType: 0,
      sortOptions: [{ fieldName: 'Modified', SortDirection: 1 }],
      appliedFilters: [],
      advancedFilter: { filterParts: [] },
      collectionId: 'd10aabc6-3ccd-4bdf-94dd-5a0f7392284a',
      ApplicationId: '',
      mappingName: 'APISForUnifiedOrchestration',
      includeDeletedItems: false,
      searchableFields: ['Key.Key_lowercase^10', 'Name.Name_lowercase^10'],
      from: 0
    };

    return this.http.post<any>(url, payload).pipe(
      map(res => {
        const items = res?.data || [];
        return items.map((item: any) => {
          let metadata: any = {};
          try {
            const raw = item.DynamicProperties?.APIMetadata || item.dynamicProperties?.APIMetadata || '';
            if (raw) metadata = JSON.parse(raw);
          } catch {}
          return {
            id: item.Id || item.id || item.ID,
            key: item.Key || item.key,
            endpoint: metadata.endpoint || '',
            inputMapping: metadata.inputMapping || metadata.inputs || [],
            outputs: metadata.outputs || [],
            method: metadata.method || 'GET'
          };
        });
      })
    );
  }
}
