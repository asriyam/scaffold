import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface FlyoutPanel {
  panelId: string;
  context: any;
  title: string;
}

@Injectable({ providedIn: 'root' })
export class FlyoutService {
  private _stack$ = new BehaviorSubject<FlyoutPanel[]>([]);
  private _isOpen$ = new BehaviorSubject<boolean>(false);

  stack$ = this._stack$.asObservable();
  isOpen$ = this._isOpen$.asObservable();

  get currentPanel(): FlyoutPanel | null {
    const s = this._stack$.value;
    return s.length > 0 ? s[s.length - 1] : null;
  }

  get canGoBack(): boolean {
    return this._stack$.value.length > 1;
  }

  open(panelId: string, context: any = {}): void {
    this._stack$.next([{ panelId, context, title: this.getTitle(panelId, context) }]);
    this._isOpen$.next(true);
  }

  push(panelId: string, context: any = {}): void {
    const stack = [...this._stack$.value, { panelId, context, title: this.getTitle(panelId, context) }];
    this._stack$.next(stack);
  }

  pop(): void {
    const stack = this._stack$.value;
    if (stack.length > 1) {
      this._stack$.next(stack.slice(0, -1));
    }
  }

  close(): void {
    this._stack$.next([]);
    this._isOpen$.next(false);
  }

  isOpen(): boolean {
    return this._isOpen$.value;
  }

  getTitle(panelId: string, context: any = {}): string {
    const titles: Record<string, string> = {
      'browse-apis': 'Select APIs',
      'api-detail': 'API Detail',
      'configure': 'Configure Orchestration',
      'field-selector': 'Select Response Fields',
      'response-preview': 'Response Preview',
      'orchestration-detail': 'Orchestration Detail',
      'browse-apis-builder': 'Browse APIs',
      'api-detail-builder': 'API Detail',
      'step-fields': 'Edit Step Fields',
      'step-configure': 'Configure Step',
      'source-picker': 'Connect input · Choose a source',
      'source-picker-fields': 'Previous step · Pick a field',
      'step-response-mapping': 'Response Mapping',
      'orc-settings': 'Orchestration Settings',
      'orc-output': 'Output Mapping',
      'iteration-configure': 'Configure Iteration',
      'new-orchestration': 'New Orchestration',
      'add-custom-input': 'Add Input Parameter'
    };
    return titles[panelId] || panelId;
  }
}
