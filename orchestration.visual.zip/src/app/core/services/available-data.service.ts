import { Injectable } from '@angular/core';
import { StateService } from './state.service';

export interface FlowInputField {
  name: string;
  type?: string;
  exampleValue?: any;
}

export interface ApiField {
  name: string;
  type?: string;
  description?: string;
  exampleValue?: any;
}

export type AvailableSource =
  | {
      kind: 'flowInput';
      label: string;
      description: string;
      flowFields: FlowInputField[];
    }
  | {
      kind: 'loopItem';
      label: string;
      description: string;
      ownerCallId: string;
      ownerApiId: string | null;
      fields: ApiField[];
      sampleItem?: any;
    }
  | {
      kind: 'step';
      label: string;
      description: string;
      callId: string;
      apiId: string | null;
      apiName?: string;
      apiKey?: string;
      endpoint?: string;
      method?: string;
      fields: ApiField[];
      sampleRequest?: any;
      indexLabel?: string;
    };

interface WalkFrame {
  parents: any[];                  // step nodes that are ancestors of the target
  prevSiblings: any[];             // step nodes that appear before the target / its ancestor at each enclosing level
  iterationOwners: any[];          // ancestor steps whose `iteration.steps` contains the path to the target
}

@Injectable({ providedIn: 'root' })
export class AvailableDataService {
  constructor(private stateService: StateService) {}

  getAvailableSources(orc: any, callId: string): AvailableSource[] {
    const sources: AvailableSource[] = [];

    sources.push({
      kind: 'flowInput',
      label: 'Flow input',
      description: 'Values provided when the flow is started',
      flowFields: this.extractFlowInputFields(orc),
    });

    if (!orc || !Array.isArray(orc.steps) || !callId) return sources;

    const found = this.locate(orc.steps, callId, { parents: [], prevSiblings: [], iterationOwners: [] });
    if (!found) return sources;

    // Innermost iteration scope first
    for (let i = found.iterationOwners.length - 1; i >= 0; i--) {
      const owner = found.iterationOwners[i];
      const ownerApi = owner.apiId ? this.stateService.getApiById(owner.apiId) : null;
      const itemName = ownerApi?.key || owner.callId;
      sources.push({
        kind: 'loopItem',
        label: `Each ${itemName}`,
        description: 'Current item from the repeating step above',
        ownerCallId: owner.callId,
        ownerApiId: owner.apiId || null,
        fields: (ownerApi?.fields as ApiField[]) || [],
        sampleItem: this.buildSampleItem(ownerApi),
      });
    }

    // Prior steps: ancestors + previous siblings (de-duplicated by callId, in declaration order)
    const priorSteps: any[] = [...found.parents, ...found.prevSiblings];
    const seen = new Set<string>();
    let idx = 0;
    for (const step of priorSteps) {
      if (!step?.callId || seen.has(step.callId)) continue;
      seen.add(step.callId);
      const api = step.apiId ? this.stateService.getApiById(step.apiId) : null;
      idx += 1;
      sources.push({
        kind: 'step',
        label: api ? api.name : step.callId,
        description: api?.endpoint || step.endpoint || '',
        callId: step.callId,
        apiId: step.apiId || null,
        apiName: api?.name,
        apiKey: api?.key,
        endpoint: api?.endpoint || step.endpoint || '',
        method: api?.method || step.method,
        fields: (api?.fields as ApiField[]) || [],
        sampleRequest: api?.sampleRequest || {},
        indexLabel: `Step ${idx}`,
      });
    }

    return sources;
  }

  // Build a sample object for an iteration's "each item" using the API's field example values.
  private buildSampleItem(api: any): any {
    if (!api || !Array.isArray(api.fields)) return undefined;
    const sample: any = {};
    api.fields.forEach((f: any) => { sample[f.name] = f.exampleValue; });
    return sample;
  }

  private extractFlowInputFields(orc: any): FlowInputField[] {
    const fields: Record<string, FlowInputField> = {};

    // 1. orc.variables (object keys are flow input field names)
    if (orc?.variables && typeof orc.variables === 'object') {
      Object.keys(orc.variables).forEach(name => {
        fields[name] = {
          name,
          type: this.inferType(orc.variables[name]),
          exampleValue: orc.variables[name],
        };
      });
    }

    // 2. orc.context (acts as additional flow input)
    if (orc?.context && typeof orc.context === 'object') {
      Object.keys(orc.context).forEach(name => {
        if (!fields[name]) {
          fields[name] = {
            name,
            type: this.inferType(orc.context[name]),
            exampleValue: orc.context[name],
          };
        }
      });
    }

    // 3. Any `$input.<name>` / `$request.<name>` referenced from existing input mappings — implies user expects this field.
    this.scanForInputReferences(orc?.steps, fields);

    return Object.values(fields);
  }

  private scanForInputReferences(steps: any[], out: Record<string, FlowInputField>): void {
    if (!Array.isArray(steps)) return;
    for (const step of steps) {
      const im = step?.inputMapping || {};
      Object.values(im).forEach((val: any) => {
        const expr = typeof val === 'string' ? val : (val && typeof val === 'object' && val.$source) ? val.$source : null;
        if (typeof expr === 'string') {
          const m = expr.match(/^\$(?:input|request|context)\.([A-Za-z0-9_]+)/);
          if (m && !out[m[1]]) out[m[1]] = { name: m[1], type: 'string' };
        }
      });
      if (step?.iteration?.steps) this.scanForInputReferences(step.iteration.steps, out);
      if (step?.children?.steps) this.scanForInputReferences(step.children.steps, out);
    }
  }

  private inferType(v: any): string {
    if (v === null) return 'string';
    if (Array.isArray(v)) return 'array';
    return typeof v;
  }

  // Recursive walk: locate the target step in the tree, building parents + previous siblings along the way.
  private locate(steps: any[], target: string, frame: WalkFrame): WalkFrame | null {
    if (!Array.isArray(steps)) return null;
    const localPrev: any[] = [];
    for (const step of steps) {
      if (step?.callId === target) {
        return {
          parents: [...frame.parents],
          prevSiblings: [...frame.prevSiblings, ...localPrev],
          iterationOwners: [...frame.iterationOwners],
        };
      }
      if (step?.iteration?.steps) {
        const r = this.locate(step.iteration.steps, target, {
          parents: [...frame.parents, step],
          prevSiblings: [...frame.prevSiblings, ...localPrev],
          iterationOwners: [...frame.iterationOwners, step],
        });
        if (r) return r;
      }
      if (step?.children?.steps) {
        const r = this.locate(step.children.steps, target, {
          parents: [...frame.parents, step],
          prevSiblings: [...frame.prevSiblings, ...localPrev],
          iterationOwners: [...frame.iterationOwners],
        });
        if (r) return r;
      }
      localPrev.push(step);
    }
    return null;
  }

  // List the call IDs that are valid "step output" sources for the given step. Used by mapping-expr's legacy parser.
  getVisibleCallIds(orc: any, callId: string): string[] {
    const sources = this.getAvailableSources(orc, callId);
    return sources.filter(s => s.kind === 'step').map(s => (s as any).callId);
  }
}
