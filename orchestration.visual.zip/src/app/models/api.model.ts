export interface Api {
  id: string;
  name: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  description: string;
  category: string;
  inputs: ApiInput[];
  outputs: ApiField[];
  examples?: ApiExample[];
}

export interface ApiInput {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  required: boolean;
  description?: string;
  example?: any;
}

export interface ApiField {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  description?: string;
  path?: string;
  required?: boolean;
}

export interface ApiExample {
  name: string;
  inputs: Record<string, any>;
  output: Record<string, any>;
}
