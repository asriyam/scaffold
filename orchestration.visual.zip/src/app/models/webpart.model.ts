export interface Webpart {
  id: string;
  type: 'hero' | 'filter' | 'results' | 'grid' | 'card' | 'rating' | 'stack' | 'compare';
  name: string;
  description: string;
  icon?: string;
  properties: WebpartProperty[];
  dataBindings: DataBinding[];
}

export interface WebpartProperty {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'select';
  value?: any;
  options?: any[];
}

export interface DataBinding {
  propertyName: string;
  dataPath: string;
}

export interface Page {
  id: string;
  orchestrationId: string;
  name: string;
  webparts: PageWebpart[];
  createdAt: Date;
  updatedAt: Date;
}

export interface PageWebpart {
  id: string;
  webpartType: string;
  position: number;
  properties: Record<string, any>;
  dataBindings: DataBinding[];
}
