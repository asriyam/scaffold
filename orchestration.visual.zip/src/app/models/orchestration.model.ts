export interface Orchestration {
  id: string;
  name: string;
  description?: string;
  version: string;
  createdAt: Date;
  updatedAt: Date;
  apiCalls: ApiCall[];
  outputMapping: OutputMapping;
}

export interface ApiCall {
  callId: string;
  apiId: string;
  endpoint: string;
  fields: string[];
  inputs?: Record<string, any>;
  iteration?: IterationConfig;
  parallelWith?: string[];
  dependsOn?: string[];
}

export interface IterationConfig {
  arrayField: string;
  childCalls: ApiCall[];
}

export interface OutputMapping {
  [key: string]: any;
}
