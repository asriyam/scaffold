export interface Orchestration {
  id: string;
  name: string;
  description?: string;
  version: string;
  createdAt: Date;
  updatedAt: Date;
  steps?: ApiCall[];
  apiCalls?: ApiCall[];
  outputMapping: OutputMapping;
}

export interface ApiCall {
  callId: string;
  apiId: string;
  endpoint: string;
  fields: string[];
  inputs?: Record<string, any>;
  iteration?: IterationConfig;
  children?: { steps: ApiCall[] };
  parallelWith?: string[];
  dependsOn?: string[];
  dependencies?: string[];
}

export interface IterationConfig {
  arrayField?: string;
  childCalls?: ApiCall[];
  steps?: ApiCall[];
}

export interface OutputMapping {
  [key: string]: any;
}

export interface OrchestrationDynamicProperties {
  OrchestrationContent: string;
  [key: string]: any;
}

export interface OrchestrationItem {
  Id: string;
  Key: string;
  Name: string;
  Container: string;
  CollectionId: string;
  DynamicProperties: OrchestrationDynamicProperties;
  DocumentMajorVersion: number;
  DocumentMinorVersion: number;
  CheckedoutBy: string | null;
  CreatedBy: string;
  Created: string;
  ModifiedBy: string;
  Modified: string;
  MediaId: string | null;
  ScheduleStartDate: string | null;
  ScheduleEndDate: string | null;
  Comments: string;
  IsImmediate: boolean;
  IsNever: boolean;
  PublishStatus: string;
  disableManualPublish: boolean;
  ReferenceItemId: string | null;
}
