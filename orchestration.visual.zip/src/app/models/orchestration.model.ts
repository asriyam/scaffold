export interface Orchestration {
  id: string;
  name: string;
  description?: string;
  version: string;
  createdAt: Date;
  updatedAt: Date;
  steps?: ApiCall[];
  apiCalls?: ApiCall[];
  outputMapping: OutputMapping;
}

export interface ApiCall {
  callId: string;
  apiId: string;
  endpoint: string;
  fields: string[];
  inputs?: Record<string, any>;
  iteration?: IterationConfig;
  children?: { steps: ApiCall[] };
  parallelWith?: string[];
  dependsOn?: string[];
  dependencies?: string[];
}

export interface IterationConfig {
  arrayField?: string;
  childCalls?: ApiCall[];
  steps?: ApiCall[];
}

export interface OutputMapping {
  [key: string]: any;
}
