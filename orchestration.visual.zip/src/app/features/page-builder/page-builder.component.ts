import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StateService } from '@core/services/state.service';

@Component({
  selector: 'app-page-builder',
  templateUrl: './page-builder.component.html',
  styleUrls: ['./page-builder.component.scss']
})
export class PageBuilderComponent implements OnInit {
  orc: any = null;
  webparts: any[] = [];
  canvas: any[] = [];
  selectedWebpartIndex: number | null = null;
  isSaving = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService
  ) {}

  ngOnInit(): void {
    this.webparts = this.stateService.getAllWebparts();
    const id = this.route.snapshot.queryParamMap.get('id') || this.stateService.getCurrentId();
    if (id) {
      this.orc = this.stateService.getOrchestrationById(id);
      if (this.orc) {
        this.canvas = JSON.parse(JSON.stringify(this.orc.pageLayout || []));
      }
    }
  }

  get selectedWebpart(): any | null {
    if (this.selectedWebpartIndex === null) return null;
    return this.canvas[this.selectedWebpartIndex] || null;
  }

  get selectedWebpartDef(): any | null {
    const w = this.selectedWebpart;
    if (!w) return null;
    return this.stateService.getWebpartById(w.id);
  }

  addWebpart(webpartId: string): void {
    const def = this.stateService.getWebpartById(webpartId);
    if (!def) return;
    const instance: any = { id: webpartId, name: def.name, bindings: {} };
    (def.slots || []).forEach((slot: any) => { instance.bindings[slot.key] = ''; });
    this.canvas.push(instance);
    this.selectedWebpartIndex = this.canvas.length - 1;
  }

  removeWebpart(index: number): void {
    this.canvas.splice(index, 1);
    if (this.selectedWebpartIndex === index) this.selectedWebpartIndex = null;
    else if (this.selectedWebpartIndex !== null && this.selectedWebpartIndex > index) {
      this.selectedWebpartIndex--;
    }
  }

  selectWebpart(index: number): void {
    this.selectedWebpartIndex = index;
  }

  updateBinding(slotKey: string, value: string): void {
    if (this.selectedWebpartIndex === null) return;
    this.canvas[this.selectedWebpartIndex].bindings[slotKey] = value;
  }

  getResponseFields(): string[] {
    if (!this.orc) return [];
    const fields: string[] = [];
    (this.orc.apis || []).forEach((apiId: string) => {
      const api = this.stateService.getApiById(apiId);
      if (!api) return;
      const selected: string[] = (this.orc.fields || {})[apiId] || [];
      selected.forEach((f: string) => fields.push(`${api.key}.${f}`));
    });
    return fields;
  }

  getWebpartDef(webpartId: string): any {
    return this.stateService.getWebpartById(webpartId);
  }

  save(): void {
    if (!this.orc) return;
    this.orc.pageLayout = [...this.canvas];
    this.orc.updatedAt = new Date().toISOString();
    this.stateService.saveOrchestration(this.orc);
    this.isSaving = true;
    setTimeout(() => {
      this.isSaving = false;
      this.showToast('Page layout saved!');
    }, 400);
  }

  goBack(): void {
    this.router.navigate(['/orchestrations']);
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  trackByIndex(index: number): number { return index; }
  trackByWebpartId(_: number, w: any): string { return w.id; }
}
