import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@shared/shared.module';

import { PageBuilderComponent } from './page-builder.component';

@NgModule({
  declarations: [PageBuilderComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      { path: '', component: PageBuilderComponent }
    ])
  ]
})
export class PageBuilderModule { }
