import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-orchestration-detail',
  templateUrl: './orchestration-detail.component.html',
  styleUrls: ['./orchestration-detail.component.scss']
})
export class OrchestrationDetailComponent implements OnInit {
  orchestrationId: string | null = null;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.orchestrationId = this.route.snapshot.paramMap.get('id');
  }
}
