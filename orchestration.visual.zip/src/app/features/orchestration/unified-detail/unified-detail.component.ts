import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';

@Component({
  selector: 'app-unified-detail',
  templateUrl: './unified-detail.component.html',
  styleUrls: ['./unified-detail.component.scss']
})
export class UnifiedDetailComponent implements OnInit, OnDestroy {
  item: any = null;
  orc: any = null;
  itemJson = '';
  jsonDraft = '';
  jsonError = '';
  isJsonDirty = false;
  isSaving = false;
  loading = true;
  itemName = '';
  errorMessage = '';
  activeTab: 'visual' | 'flow' | 'json' = 'visual';
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private stateService: StateService,
    private flyoutService: FlyoutService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const itemId = params.get('id');
      if (!itemId) {
        this.router.navigate(['/orchestrations']);
        return;
      }

      this.route.queryParamMap.subscribe(qp => {
        const collectionId = qp.get('collectionId') || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
        const contentType = qp.get('contentType') || 'UnifiedOrchestration';
        this.itemName = qp.get('name') || '';
        this.fetchItemDetail(itemId, collectionId, contentType);
      });
    });
  }

  fetchItemDetail(itemId: string, collectionId: string, contentType: string): void {
    this.loading = true;
    this.errorMessage = '';
    const url = `https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/GetItem`
      + `?collectionId=${encodeURIComponent(collectionId)}`
      + `&contentType=${encodeURIComponent(contentType)}`
      + `&itemId=${encodeURIComponent(itemId)}`;

    console.log('Fetching item detail from:', url);

    this.http.get<any>(url).subscribe({
      next: (res) => {
        console.log('GetItem response:', res);
        this.item = res;
        let orchContent = res?.DynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.orchestrationContent
          || res?.dynamicProperties?.OrchestrationContent
          || res?.DynamicProperties?.orchestrationContent;
        if (typeof orchContent === 'string') {
          try { orchContent = JSON.parse(orchContent); } catch (_) {}
        }
        this.orc = orchContent ?? {};
        this.stateService.setBuilderDraft(this.orc);
        this.itemJson = JSON.stringify(this.orc, null, 2);
        this.jsonDraft = this.itemJson;
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to fetch item detail:', err);
        this.errorMessage = err?.message || 'Failed to load item';
        this.item = null;
        this.itemJson = '{}';
        this.loading = false;
      }
    });

    // Auto-sync when flyout closes (step was added/modified)
    this.flyoutService.isOpen$.pipe(
      takeUntil(this.destroy$),
      pairwise(),
      filter(([prev, curr]) => prev === true && curr === false)
    ).subscribe(() => this.syncFromDraft());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      this.save(false);
    }
  }

  // ---- Header data ----

  get orcName(): string { return this.orc?.name || this.itemName || 'Untitled Orchestration'; }
  get orcVersion(): string { return this.orc?.version ? 'v' + this.orc.version : 'v1.0.0'; }
  onNameBlur(event: Event): void {
    const text = (event.target as HTMLElement).textContent?.trim() || 'Untitled Orchestration';
    const draft = this.stateService.getBuilderDraft();
    if (draft) { draft.name = text; this.stateService.setBuilderDraft(draft); }
    if (this.orc) this.orc.name = text;
  }

  // ---- Steps / canvas data ----

  getSteps(): any[] {
    const draft = this.stateService.getBuilderDraft();
    return draft?.steps || this.orc?.steps || [];
  }

  get hasSteps(): boolean { return this.getSteps().length > 0; }

  get jsonView(): string {
    const draft = this.stateService.getBuilderDraft();
    return JSON.stringify(draft || this.orc || {}, null, 2);
  }

  setTab(tab: 'visual' | 'flow' | 'json'): void {
    this.activeTab = tab;
    if (tab === 'json') {
      this.jsonDraft = this.jsonView;
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  onJsonInput(value: string): void {
    this.jsonDraft = value;
    this.isJsonDirty = true;
    try {
      JSON.parse(value);
      this.jsonError = '';
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  applyJson(): void {
    if (this.jsonError) return;
    try {
      const parsed = JSON.parse(this.jsonDraft);
      this.stateService.setBuilderDraft(parsed);
      this.orc = JSON.parse(JSON.stringify(parsed));
      this.isJsonDirty = false;
      this.showToast('JSON applied — Visual and Flow tabs updated');
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  resetJson(): void {
    this.jsonDraft = this.jsonView;
    this.jsonError = '';
    this.isJsonDirty = false;
  }

  syncFromDraft(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.orc = JSON.parse(JSON.stringify(draft));
    if (this.activeTab === 'json') {
      this.jsonDraft = JSON.stringify(draft, null, 2);
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  // ---- Header actions ----

  addRootApi(): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'root' });
  }

  openSettings(): void {
    this.flyoutService.open('orc-settings', {});
  }

  openOutput(): void {
    this.flyoutService.open('orc-output', {});
  }

  save(goBack = false): void {
    // If user edited JSON in the third tab, use that directly
    let draft: any;
    if (this.activeTab === 'json' && this.isJsonDirty && !this.jsonError) {
      try {
        draft = JSON.parse(this.jsonDraft);
        this.stateService.setBuilderDraft(draft);
        this.orc = JSON.parse(JSON.stringify(draft));
        this.isJsonDirty = false;
      } catch (_) {
        draft = this.stateService.getBuilderDraft() || this.orc;
      }
    } else {
      draft = this.stateService.getBuilderDraft() || this.orc;
    }
    if (!draft || !this.item) return;

    this.isSaving = true;

    // Clone the complete GetItem response
    const payload: any = JSON.parse(JSON.stringify(this.item));

    // Only update OrchestrationContent dynamically from the current JSON
    if (!payload.DynamicProperties) {
      payload.DynamicProperties = {};
    }
    payload.DynamicProperties.OrchestrationContent = JSON.stringify(draft, null, 2);

    const collectionId = payload.CollectionId || payload.collectionId || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
    const url = `https://csstudio-sitg3-authoringapi.pnp2.pcf.dell.com/api/${collectionId}/item/updateandcheckin?listIdOrName=${collectionId}`;
    console.log('Saving to updateandcheckin:', url, payload);

    this.http.post<any>(url, payload).subscribe({
      next: (res) => {
        console.log('SaveInDraft response:', res);
        this.orc = JSON.parse(JSON.stringify(draft));
        this.stateService.setBuilderDraft(this.orc);
        this.itemJson = JSON.stringify(this.orc, null, 2);
        this.isSaving = false;
        this.showToast('Orchestration saved successfully');
        if (goBack) this.router.navigate(['/orchestrations']);
      },
      error: (err) => {
        console.error('SaveInDraft failed:', err);
        this.isSaving = false;
        const errMsg = err?.error?.message || err?.message || 'Save failed. Please try again.';
        this.showToast('Error: ' + errMsg);
      }
    });
  }

  exportJson(): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;
    const json = JSON.stringify(draft, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = (draft.name || 'orchestration').replace(/[^a-z0-9\-_]+/gi, '-');
    a.href = url; a.download = safeName + '.json';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }

  // ---- Step card actions ----

  openInputMapping(callId: string): void {
    this.flyoutService.open('step-input-mapping', { callId });
  }

  openResponseMapping(callId: string): void {
    this.flyoutService.open('step-response-mapping', { callId });
  }

  addDependentStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'dependent', parentCallId });
  }

  addChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'direct-child', parentCallId });
  }

  setIterateStep(callId: string): void {
    this.flyoutService.open('iteration-configure', { callId });
  }

  addIterationChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'iteration-child', parentCallId });
  }

  editStepFields(callId: string): void {
    this.flyoutService.open('step-fields', { callId });
  }

  configureStep(callId: string): void {
    this.flyoutService.open('step-configure', { callId });
  }

  removeStep(callId: string): void {
    if (!confirm(`Remove step "${callId}"? Any steps that depend on it will lose this dependency.`)) return;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.stateService.removeStep(draft, callId);
    this.stateService.setBuilderDraft(draft);
    this.orc = JSON.parse(JSON.stringify(draft));
  }

  getStepDependencies(step: any): string[] {
    return Array.isArray(step?.dependencies) ? step.dependencies : [];
  }

  getInputMappingCount(step: any): number {
    return Object.keys(step?.inputMapping || {}).length;
  }

  getResponseMappingCount(step: any): number {
    return Object.keys(step?.responseMapping || {}).length;
  }

  trackByCallId(_: number, step: any): string { return step.callId; }

  // ---- Navigation ----

  goBack(): void { this.router.navigate(['/orchestrations']); }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }
}
