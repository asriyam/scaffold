import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@shared/shared.module';

import { OrchestrationListComponent } from './orchestration-list/orchestration-list.component';
import { OrchestrationDetailComponent } from './orchestration-detail/orchestration-detail.component';
import { UnifiedDetailComponent } from './unified-detail/unified-detail.component';

@NgModule({
  declarations: [OrchestrationListComponent, OrchestrationDetailComponent, UnifiedDetailComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', component: OrchestrationListComponent },
      {
        path: 'studio',
        loadChildren: () => import('../studio/studio.module')
          .then(m => m.StudioModule)
      },
      {
        path: 'swagger-import',
        loadChildren: () => import('../swagger-import/swagger-import.module')
          .then(m => m.SwaggerImportModule)
      },
      { path: ':id', component: OrchestrationDetailComponent }
    ])
  ]
})
export class OrchestrationModule { }
