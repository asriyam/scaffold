import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FlyoutService } from '@core/services/flyout.service';

@Component({
  selector: 'app-orchestration-list',
  templateUrl: './orchestration-list.component.html',
  styleUrls: ['./orchestration-list.component.scss']
})
export class OrchestrationListComponent implements OnInit {
  searchQuery = '';
  orchestrationItems: any[] = [];
  orchestrationLoading = false;

  constructor(
    private flyoutService: FlyoutService,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.fetchOrchestrations();
  }

  get filtered(): any[] {
    const q = this.searchQuery.toLowerCase();
    if (!q) return this.orchestrationItems;
    return this.orchestrationItems.filter(item =>
      (item.Name || item.name || '').toLowerCase().includes(q) ||
      (item.Key || item.key || '').toLowerCase().includes(q)
    );
  }

  getApiCount(item: any): number {
    try {
      let content = item?.DynamicProperties?.OrchestrationContent
        || item?.dynamicProperties?.OrchestrationContent;
      if (typeof content === 'string') { content = JSON.parse(content); }
      return (content?.steps || []).length || 0;
    } catch (_) { return 0; }
  }

  getApiNames(item: any): string {
    try {
      let content = item?.DynamicProperties?.OrchestrationContent
        || item?.dynamicProperties?.OrchestrationContent;
      if (typeof content === 'string') { content = JSON.parse(content); }
      const steps = content?.steps || [];
      if (steps.length > 0) {
        return steps.map((s: any) => s.callId || s.endpoint || 'API').join(', ');
      }
    } catch (_) {}
    return '';
  }

  getFieldCount(item: any): number {
    try {
      let content = item?.DynamicProperties?.OrchestrationContent
        || item?.dynamicProperties?.OrchestrationContent;
      if (typeof content === 'string') { content = JSON.parse(content); }
      const steps = content?.steps || [];
      let count = 0;
      steps.forEach((s: any) => { count += (s.fields || []).length; });
      return count;
    } catch (_) { return 0; }
  }

  newOrchestration(): void {
    this.flyoutService.open('new-orchestration', {});
  }

  openItem(item: any): void {
    const itemId = item.Id || item.id;
    const collectionId = item.CollectionId || item.collectionId || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
    const contentType = item.Container || item.container || 'UnifiedOrchestration';
    const name = item.Name || item.name || '';
    this.router.navigate(['/builder/cs', itemId], {
      queryParams: { collectionId, contentType, name }
    });
  }

  fetchOrchestrations(): void {
    this.orchestrationLoading = true;
    const url = 'https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemReaderApi/GetItems?findMissingItems=false';
    const body = {
      sourceFields: [
        'Id', 'Key', 'Name', 'Container', 'DynamicProperties',
        'DocumentMajorVersion', 'DocumentMinorVersion', 'CheckedoutBy',
        'CreatedBy', 'Created', 'ModifiedBy', 'Modified', 'MediaId',
        'ScheduleStartDate', 'ScheduleEndDate', 'Comments', 'IsImmediate',
        'IsNever', 'PublishStatus', 'disableManualPublish', 'CollectionId',
        'ReferenceItemId'
      ],
      size: 25,
      blockNumber: 1,
      searchText: '',
      collectionIndexType: 0,
      sortOptions: [{ fieldName: 'Modified', SortDirection: 1 }],
      appliedFilters: [],
      advancedFilter: { filterParts: [] },
      collectionId: '8e90b9b4-f6cd-4365-99cf-3cdadf69362a',
      ApplicationId: '',
      mappingName: 'UnifiedOrchestration',
      includeDeletedItems: false,
      searchableFields: [
        'Key.Key_lowercase^10', 'Name.Name_lowercase^10', 'Name^5',
        'Key^5', 'Name.Name_analyzed', 'Key.Key_analyzed', 'ModifiedBy'
      ],
      from: 0
    };

    this.http.post<any>(url, body).subscribe({
      next: (res) => {
        this.orchestrationItems = res?.items || res?.Items || res?.Results || res?.results || res?.Data || res?.data || (Array.isArray(res) ? res : []);
        this.orchestrationLoading = false;
      },
      error: (err) => {
        console.error('fetchOrchestrations failed:', err);
        this.orchestrationItems = [];
        this.orchestrationLoading = false;
      }
    });
  }

  trackByItemId(_: number, item: any): string { return item.Id || item.id; }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }
}
