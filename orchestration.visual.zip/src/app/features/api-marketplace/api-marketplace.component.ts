import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StateService } from '@core/services/state.service';

@Component({
  selector: 'app-api-marketplace',
  templateUrl: './api-marketplace.component.html',
  styleUrls: ['./api-marketplace.component.scss']
})
export class ApiMarketplaceComponent implements OnInit {
  searchQuery = '';
  currentFilter = 'all';
  bucketIds: string[] = [];
  categories: string[] = [];
  activeStep = 1;

  constructor(
    private stateService: StateService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.categories = this.stateService.getApiCategories();
    this.loadBucket();
  }

  loadBucket(): void {
    try {
      const raw = localStorage.getItem('orc_marketplace_bucket');
      this.bucketIds = raw ? JSON.parse(raw) : [];
    } catch { this.bucketIds = []; }
  }

  saveBucket(): void {
    localStorage.setItem('orc_marketplace_bucket', JSON.stringify(this.bucketIds));
  }

  get filteredApis(): any[] {
    const q = this.searchQuery.toLowerCase();
    return this.stateService.getAllApis().filter(api => {
      const matchCat = this.currentFilter === 'all' || api.category === this.currentFilter;
      const matchQ = !q || api.name.toLowerCase().includes(q) || api.description.toLowerCase().includes(q);
      return matchCat && matchQ;
    });
  }

  isInBucket(apiId: string): boolean {
    return this.bucketIds.includes(apiId);
  }

  toggleBucket(apiId: string, event: Event): void {
    event.stopPropagation();
    const idx = this.bucketIds.indexOf(apiId);
    if (idx >= 0) this.bucketIds.splice(idx, 1);
    else this.bucketIds.push(apiId);
    this.saveBucket();
    this.showToast(idx >= 0 ? 'Removed from bucket' : 'Added to bucket');
  }

  viewDetails(apiId: string): void {
    this.router.navigate(['/marketplace/apis', apiId]);
  }

  goBucket(): void {
    this.router.navigate(['/marketplace/bucket']);
  }

  get stepItems(): { number: number; label: string; active: boolean }[] {
    return [
      { number: 1, label: 'Browse', active: this.activeStep === 1 },
      { number: 2, label: 'Bucket', active: this.activeStep === 2 },
      { number: 3, label: 'Build', active: this.activeStep === 3 },
      { number: 4, label: 'Preview', active: this.activeStep === 4 },
      { number: 5, label: 'Page', active: this.activeStep === 5 }
    ];
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  trackByApiId(_: number, api: any): string { return api.id; }
}
