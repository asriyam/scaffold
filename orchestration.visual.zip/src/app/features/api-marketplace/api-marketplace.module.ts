import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@shared/shared.module';

import { ApiMarketplaceComponent } from './api-marketplace.component';
import { ApiDetailComponent } from './api-detail.component';

@NgModule({
  declarations: [ApiMarketplaceComponent, ApiDetailComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      { path: '', redirectTo: 'apis', pathMatch: 'full' },
      { path: 'apis', component: ApiMarketplaceComponent },
      { path: 'apis/:id', component: ApiDetailComponent }
    ])
  ]
})
export class ApiMarketplaceModule { }
