import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@shared/shared.module';
import { StudioComponent } from './studio.component';

@NgModule({
  declarations: [StudioComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      { path: '', component: StudioComponent },
      { path: ':id', component: StudioComponent }
    ])
  ]
})
export class StudioModule { }
