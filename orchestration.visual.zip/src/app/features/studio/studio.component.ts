import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';
import { AvailableDataService } from '@core/services/available-data.service';
import { parseMappingExpr } from '@core/services/mapping-expr';
import { MOCK_ORCHESTRATIONS } from '@core/mockdata/orchestrations';

interface StudioTreeNode {
  step: any;
  depth: number;
  badge: 'S' | 'P' | 'M';
  showLabel: boolean;
}

@Component({
  selector: 'app-studio',
  templateUrl: './studio.component.html',
  styleUrls: ['./studio.component.scss']
})
export class StudioComponent implements OnInit, OnDestroy {
  orc: any = null;
  allOrchestrations: any[] = [];
  selectedStep: any = null;
  selectedStepApi: any = null;
  activeDetailTab: 'basic' | 'advanced' = 'basic';
  expandedNodes = new Set<string>();
  treeNodes: StudioTreeNode[] = [];
  draggedCallId: string | null = null;

  // Try It Out
  testApiUrl = 'https://orchestrationapi.studiod-r3-np.kob.dell.com/api/orchestration/preview/execute?skipCache=false&includeMetrics=true';
  testRequestJson = '';
  testResponseJson = '';
  testStatusCode: number | null = null;
  isTesting = false;
  testRequestJsonError = '';

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService,
    private flyoutService: FlyoutService,
    private availableDataService: AvailableDataService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    const apiOrcs = this.stateService.getOrchestrations();
    this.allOrchestrations = apiOrcs.length > 0 ? apiOrcs : MOCK_ORCHESTRATIONS;

    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      if (params['id']) {
        this.orc = this.stateService.getOrchestrationById(params['id']);
        if (!this.orc) {
          this.orc = MOCK_ORCHESTRATIONS.find(o => o.id === params['id']);
        }
      } else {
        this.orc = this.stateService.getBuilderDraft() || this.allOrchestrations[0];
      }
      if (this.orc) {
        this.initStudio();
      }
    });

    // Sync from draft when flyout closes
    this.flyoutService.isOpen$
      .pipe(
        pairwise(),
        filter(([prev, curr]) => prev && !curr),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.orc = this.stateService.getBuilderDraft();
        if (this.selectedStep) {
          this.selectedStep = this.stateService.getStepById(this.orc, this.selectedStep.callId);
          if (this.selectedStep) {
            this.selectedStepApi = this.stateService.getApiById(this.selectedStep.apiId);
          }
        }
        this.updateTreeNodes();
        this.initTestTab();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initStudio(): void {
    this.stateService.setBuilderDraft(this.orc);
    this.expandAllNodes();
    this.updateTreeNodes();
    this.selectedStep = null;
    this.initTestTab();
  }

  private updateTreeNodes(): void {
    this.treeNodes = this.flattenSteps(this.orc?.steps || [], 0);
  }

  private expandAllNodes(): void {
    this.expandedNodes.clear();
    const collectCallIds = (steps: any[]) => {
      steps.forEach(step => {
        this.expandedNodes.add(step.callId);
        if (step.children?.steps) collectCallIds(step.children.steps);
        if (step.iteration?.steps) collectCallIds(step.iteration.steps);
      });
    };
    collectCallIds(this.orc?.steps || []);
  }

  private flattenSteps(steps: any[], depth: number, parentType?: string): StudioTreeNode[] {
    const result: StudioTreeNode[] = [];
    steps.forEach(step => {
      const hasNoDeps = (step.dependencies || []).length === 0;
      const badge = parentType === 'iteration' ? 'M' : hasNoDeps ? 'P' : 'S';
      const showLabel = depth === 0;
      result.push({ step, depth, badge, showLabel });

      if (step.children?.steps?.length) {
        result.push(...this.flattenSteps(step.children.steps, depth + 1, 'children'));
      }
      if (step.iteration?.steps?.length) {
        result.push(...this.flattenSteps(step.iteration.steps, depth + 1, 'iteration'));
      }
    });
    return result;
  }

  isNodeVisible(node: StudioTreeNode): boolean {
    if (node.depth === 0) return true;
    // Walk up the tree to check if all ancestors are expanded
    const findAncestors = (targetCallId: string, steps: any[], ancestors: string[] = []): string[] => {
      for (const step of steps) {
        if (step.callId === targetCallId) return ancestors;
        if (step.children?.steps) {
          const result = findAncestors(targetCallId, step.children.steps, [...ancestors, step.callId]);
          if (result.length > 0) return result;
        }
        if (step.iteration?.steps) {
          const result = findAncestors(targetCallId, step.iteration.steps, [...ancestors, step.callId]);
          if (result.length > 0) return result;
        }
      }
      return [];
    };
    const ancestors = findAncestors(node.step.callId, this.orc?.steps || []);
    return ancestors.every(ancestorCallId => this.expandedNodes.has(ancestorCallId));
  }

  hasChildren(step: any): boolean {
    return !!(step.children?.steps?.length || step.iteration?.steps?.length);
  }

  toggleNode(callId: string, event?: Event): void {
    if (event) event.stopPropagation();
    if (this.expandedNodes.has(callId)) {
      this.expandedNodes.delete(callId);
    } else {
      this.expandedNodes.add(callId);
    }
  }

  isExpanded(callId: string): boolean {
    return this.expandedNodes.has(callId);
  }

  onDragStart(event: DragEvent, node: StudioTreeNode): void {
    this.draggedCallId = node.step.callId;
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'move';
    }
  }

  onDrop(event: DragEvent, targetNode: StudioTreeNode): void {
    event.preventDefault();
    if (!this.draggedCallId || targetNode.depth > 0) return; // Only allow top-level reordering

    const steps = this.orc?.steps || [];
    const draggedIdx = steps.findIndex((s: any) => s.callId === this.draggedCallId);
    const targetIdx = steps.findIndex((s: any) => s.callId === targetNode.step.callId);

    if (draggedIdx >= 0 && targetIdx >= 0 && draggedIdx !== targetIdx) {
      const [draggedStep] = steps.splice(draggedIdx, 1);
      steps.splice(targetIdx, 0, draggedStep);
      this.stateService.saveOrchestration(this.orc);
      this.stateService.setBuilderDraft(this.orc);
    }
    this.draggedCallId = null;
  }

  selectStep(step: any): void {
    this.selectedStep = step;
    this.selectedStepApi = this.stateService.getApiById(step.apiId);
    this.initTestTab();
  }

  get flowSummary(): { services: number; dependencies: number; executionMode: string } {
    const steps = this.orc?.steps || [];
    const services = steps.length;
    const dependencies = steps.reduce((n: number, s: any) => n + (s.dependencies?.length || 0), 0);
    const executionMode = this.orc?.execution?.mode || 'parallel';
    return { services, dependencies, executionMode };
  }

  onAddStep(): void {
    this.flyoutService.open('browse-apis-builder', {
      targetType: this.selectedStep ? 'dependent' : 'root',
      parentCallId: this.selectedStep?.callId || null
    });
  }

  openOrcSettings(): void {
    this.flyoutService.open('orc-settings', { id: this.orc?.id });
  }

  // Input mapping
  getStepInputRows(step: any): { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] {
    const rows: { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] = [];
    const seen = new Set<string>();

    // 1. URL path params
    this.extractUrlPathParams(step?.endpoint || '').forEach(name => {
      rows.push({ name, type: 'string', required: true, custom: false, paramIn: 'path' });
      seen.add(name);
    });

    // 2. Explicit step.inputs
    if (Array.isArray(step?.inputs)) {
      step.inputs.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || 'string', required: !!i.required, custom: false, paramIn: i.in || 'body' });
          seen.add(i.name);
        }
      });
    }

    // 3. API-definition inputs
    const api = this.getApiForStep(step);
    if (api && Array.isArray(api.inputMapping)) {
      api.inputMapping.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || '', required: !!i.required, custom: false, paramIn: i.in || 'query' });
          seen.add(i.name);
        }
      });
    }

    // 4. Extra custom inputMapping keys
    const map = step?.inputMapping || {};
    Object.keys(map).forEach(k => {
      if (!seen.has(k)) rows.push({ name: k, type: '', required: false, custom: true, paramIn: this.getMappingIn(map[k]) });
    });

    return rows;
  }

  getInputMappingChip(step: any, paramName: string): { icon: string; label: string; tag: string; isUnmapped: boolean } {
    if (!this.isInputMapped(step, paramName)) {
      return { icon: '＋', label: 'Connect a source…', tag: '', isUnmapped: true };
    }
    const raw = this.getMappingSourceExpr((step?.inputMapping || {})[paramName]);
    const draft = this.orc;
    const sources = draft ? this.availableDataService.getAvailableSources(draft, step.callId) : [];
    const expr = parseMappingExpr(raw, sources.filter(s => s.kind === 'step').map((s: any) => s.callId));

    if (expr.kind === 'flowInput') {
      return { icon: '⚡', label: `Flow input · ${expr.path || '(root)'}`, tag: 'flow', isUnmapped: false };
    }
    if (expr.kind === 'loopItem') {
      return { icon: '🔄', label: `Loop item · ${expr.path || '(root)'}`, tag: 'loop', isUnmapped: false };
    }
    if (expr.kind === 'stepOutput') {
      return { icon: '📤', label: `${expr.callId} · ${expr.path || '(root)'}`, tag: 'step', isUnmapped: false };
    }
    return { icon: '✎', label: `Literal · ${String(raw).substring(0, 20)}...`, tag: 'literal', isUnmapped: false };
  }

  private isInputMapped(step: any, paramName: string): boolean {
    const map = step?.inputMapping || {};
    if (!Object.prototype.hasOwnProperty.call(map, paramName)) return false;
    const v = map[paramName];
    const src = this.getMappingSourceExpr(v);
    return src !== '' && src !== undefined && src !== null;
  }

  openSourcePicker(step: any, paramName: string, paramIn: string): void {
    this.flyoutService.open('source-picker', { callId: step.callId, paramName, paramIn });
  }

  // Field selection
  isFieldSelected(name: string): boolean {
    return (this.selectedStep?.fields || []).includes(name);
  }

  toggleField(name: string): void {
    if (!this.selectedStep) return;
    const fields = this.selectedStep.fields || [];
    const idx = fields.indexOf(name);
    if (idx >= 0) {
      fields.splice(idx, 1);
    } else {
      fields.push(name);
    }
    this.selectedStep.fields = fields;
    this.stateService.updateStep(this.orc, this.selectedStep.callId, { fields });
    this.stateService.saveOrchestration(this.orc);
    this.stateService.setBuilderDraft(this.orc);
  }

  toggleAllFields(): void {
    if (!this.selectedStep || !this.selectedStepApi) return;
    const allFieldNames = (this.selectedStepApi.fields || this.selectedStepApi.outputs || []).map((f: any) => f.name);
    const hasAll = allFieldNames.every((name: string) => this.isFieldSelected(name));
    this.selectedStep.fields = hasAll ? [] : allFieldNames;
    this.stateService.updateStep(this.orc, this.selectedStep.callId, { fields: this.selectedStep.fields });
    this.stateService.saveOrchestration(this.orc);
    this.stateService.setBuilderDraft(this.orc);
  }

  saveRequest(): void {
    this.stateService.saveOrchestration(this.orc);
  }

  initTestTab(): void {
    const draft = this.orc;
    if (!draft) return;
    const requestBody: any = { orchestration: draft };
    const requestData: any = {
      profile: {
        country: 'us',
        language: 'en',
        region: 'us',
        segment: 'cnsr',
        market: 'usa_market'
      }
    };
    if (draft.requestData && typeof draft.requestData === 'object') {
      Object.assign(requestData, draft.requestData);
    }
    requestBody.requestData = requestData;
    this.testRequestJson = JSON.stringify(requestBody, null, 2);
    this.testRequestJsonError = '';
  }

  onTestRequestInput(val: string): void {
    try {
      JSON.parse(val);
      this.testRequestJsonError = '';
    } catch (e: any) {
      this.testRequestJsonError = e.message;
    }
  }

  sendTestRequest(): void {
    let parsedBody: any;
    try {
      parsedBody = JSON.parse(this.testRequestJson);
    } catch (e: any) {
      this.testStatusCode = 400;
      this.testResponseJson = JSON.stringify({ error: 'Invalid request JSON', detail: e.message }, null, 2);
      return;
    }

    this.isTesting = true;
    this.testResponseJson = '';
    this.testStatusCode = null;

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.http.post(this.testApiUrl, parsedBody, { headers, observe: 'response' })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.testStatusCode = response.status;
          this.testResponseJson = JSON.stringify(response.body, null, 2);
          this.isTesting = false;
        },
        error: (err: HttpErrorResponse) => {
          this.testStatusCode = err.status || 0;
          const body = err.error;
          if (body && typeof body === 'object') {
            this.testResponseJson = JSON.stringify(body, null, 2);
          } else if (typeof body === 'string') {
            try { this.testResponseJson = JSON.stringify(JSON.parse(body), null, 2); }
            catch { this.testResponseJson = JSON.stringify({ error: body || err.message }, null, 2); }
          } else {
            this.testResponseJson = JSON.stringify({ error: err.message || 'Request failed', status: err.status }, null, 2);
          }
          this.isTesting = false;
        }
      });
  }

  private extractUrlPathParams(endpoint: string): string[] {
    if (!endpoint) return [];
    const matches = endpoint.match(/\{([^}]+)\}/g);
    return matches ? matches.map(m => m.slice(1, -1)) : [];
  }

  private getMappingSourceExpr(val: any): any {
    if (val && typeof val === 'object' && '$source' in val) return val.$source;
    return val;
  }

  private getMappingIn(val: any): string {
    if (val && typeof val === 'object' && '$in' in val) return val.$in;
    return 'body';
  }

  private getApiForStep(step: any): any | null {
    if (!step) return null;
    if (step.apiId) {
      return this.stateService.getApiById(step.apiId) || null;
    }
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint) || null;
  }

  getFieldRows(): any[][][] {
    const fields = this.selectedStepApi?.fields || this.selectedStepApi?.outputs || [];
    const fieldsPerColumn = 5;
    const columnsPerRow = 3;
    const fieldsPerRow = fieldsPerColumn * columnsPerRow;
    const rows: any[][][] = [];

    for (let i = 0; i < fields.length; i += fieldsPerRow) {
      const rowFields = fields.slice(i, i + fieldsPerRow);
      const columns: any[][] = [];

      for (let j = 0; j < rowFields.length; j += fieldsPerColumn) {
        columns.push(rowFields.slice(j, j + fieldsPerColumn));
      }

      rows.push(columns);
    }

    return rows;
  }
}
