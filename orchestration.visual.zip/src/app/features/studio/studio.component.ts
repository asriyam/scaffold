import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';
import { AvailableDataService } from '@core/services/available-data.service';
import { parseMappingExpr } from '@core/services/mapping-expr';
import { MOCK_ORCHESTRATIONS, MOCK_ORCHESTRATION_DEFINITIONS } from '@core/mockdata/orchestrations';

interface StudioTreeNode {
  step: any;
  depth: number;
  badge: 'S' | 'P' | 'M';
  showLabel: boolean;
  nodeKind: 'root' | 'dependent' | 'child' | 'iteration';
}

@Component({
  selector: 'app-studio',
  templateUrl: './studio.component.html',
  styleUrls: ['./studio.component.scss']
})
export class StudioComponent implements OnInit, OnDestroy {
  orc: any = null;
  allOrchestrations: any[] = [];
  selectedStep: any = null;
  selectedStepApi: any = null;
  activeDetailTab: 'basic' | 'advanced' | 'try' = 'basic';
  isInputMappingExpanded = true;
  isFieldSelectionExpanded = true;

  // Advanced JSON editor
  jsonDraft = '';
  jsonError = '';
  isJsonDirty = false;
  isJsonExpanded = false;
  isTryExpanded = false;
  expandedNodes = new Set<string>();
  treeNodes: StudioTreeNode[] = [];
  item: any = null;
  isSaving = false;
  draggedCallId: string | null = null;
  activeAddMenu: string | null = null;
  addMenuPos: { top: number; right: number } = { top: 0, right: 0 };

  // Try It Out
  testApiUrl = 'https://orchestrationapi.studiod-r3-np.kob.dell.com/api/orchestration/preview/execute?skipCache=false&includeMetrics=true';
  testRequestJson = '';
  testResponseJson = '';
  testStatusCode: number | null = null;
  isTesting = false;
  testRequestJsonError = '';

  showRequest = false;
  isDebugMode = false;
  isMockData = false;
  loading = false;

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService,
    private flyoutService: FlyoutService,
    private availableDataService: AvailableDataService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.isDebugMode = this.route.snapshot.queryParamMap.get('debug') === 'true';
    const apiOrcs = this.stateService.getOrchestrations();
    this.allOrchestrations = apiOrcs.length > 0 ? apiOrcs : MOCK_ORCHESTRATION_DEFINITIONS;

    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const useMock = this.route.snapshot.queryParamMap.get('mock') === 'true';

      if (params['id']) {
        if (useMock) {
          this.orc = this.loadMockOrchestrationById(params['id']);
          this.setMockDataFlag(true);
        } else {
          this.orc = this.stateService.getOrchestrationById(params['id']);
          if (!this.orc) {
            this.orc = MOCK_ORCHESTRATION_DEFINITIONS.find(o => o.id === params['id']);
            if (this.orc) {
              this.setMockDataFlag(true);
            } else {
              const collectionId = this.route.snapshot.queryParamMap.get('collectionId');
              const contentType = this.route.snapshot.queryParamMap.get('contentType') || 'UnifiedOrchestration';
              if (collectionId) {
                this.fetchFromContentStudio(params['id'], collectionId, contentType);
                return;
              }
            }
          } else {
            this.setMockDataFlag(false);
          }
        }
      } else {
        this.orc = this.stateService.getBuilderDraft() || this.allOrchestrations[0];
        this.setMockDataFlag(useMock);
      }
      if (this.orc) {
        this.initStudio();
      }
    });

    // Sync from draft when flyout closes
    this.flyoutService.isOpen$
      .pipe(
        pairwise(),
        filter(([prev, curr]) => prev && !curr),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.orc = this.stateService.getBuilderDraft();
        if (this.selectedStep) {
          this.selectedStep = this.stateService.getStepById(this.orc, this.selectedStep.callId);
          if (this.selectedStep) {
            this.selectedStepApi = this.getApiForStep(this.selectedStep);
          }
        }
        this.updateTreeNodes();
        this.initTestTab();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initStudio(): void {
    this.orc = this.stateService.sanitize(this.orc);
    this.stateService.setBuilderDraft(this.orc);
    this.expandAllNodes();
    this.updateTreeNodes();
    this.resetJsonDraft();
    const firstStep = this.orc?.steps?.[0];
    if (firstStep) {
      this.selectStep(firstStep);
    } else {
      this.selectedStep = null;
      this.selectedStepApi = null;
      this.initTestTab();
    }
  }

  onAdvancedTabClick(): void {
    this.activeDetailTab = 'advanced';
    if (!this.isJsonDirty) {
      this.resetJsonDraft();
    }
  }

  private resetJsonDraft(): void {
    this.jsonDraft = JSON.stringify(this.orc || {}, null, 2);
    this.jsonError = '';
    this.isJsonDirty = false;
  }

  onJsonInput(value: string): void {
    this.jsonDraft = value;
    this.isJsonDirty = true;
    try {
      JSON.parse(value);
      this.jsonError = '';
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  applyJson(): void {
    if (this.jsonError) return;
    try {
      const parsed = JSON.parse(this.jsonDraft);
      this.orc = parsed;
      this.stateService.setBuilderDraft(this.orc);
      this.stateService.saveOrchestration(this.orc);
      this.expandAllNodes();
      this.updateTreeNodes();
      if (this.selectedStep) {
        const restored = this.stateService.getStepById(this.orc, this.selectedStep.callId);
        if (restored) {
          this.selectedStep = restored;
          this.selectedStepApi = this.getApiForStep(restored);
        } else {
          this.selectedStep = null;
          this.selectedStepApi = null;
        }
      }
      this.initTestTab();
      this.isJsonDirty = false;
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  resetJson(): void {
    this.resetJsonDraft();
  }

  toggleJsonExpanded(): void {
    this.isJsonExpanded = !this.isJsonExpanded;
  }

  toggleInputMapping(): void {
    this.isInputMappingExpanded = !this.isInputMappingExpanded;
  }

  toggleFieldSelection(): void {
    this.isFieldSelectionExpanded = !this.isFieldSelectionExpanded;
  }

  toggleTryExpanded(): void {
    this.isTryExpanded = !this.isTryExpanded;
  }

  private fetchFromContentStudio(itemId: string, collectionId: string, contentType: string): void {
    this.loading = true;
    const url = `https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/GetItem`
      + `?collectionId=${encodeURIComponent(collectionId)}`
      + `&contentType=${encodeURIComponent(contentType)}`
      + `&itemId=${encodeURIComponent(itemId)}`;

    this.http.get<any>(url).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        this.item = res;
        let orchContent = res?.DynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.orchestrationContent
          || res?.DynamicProperties?.orchestrationContent;
        if (typeof orchContent === 'string') {
          try { orchContent = JSON.parse(orchContent); } catch (_) { orchContent = {}; }
        }
        this.orc = orchContent ?? {};
        this.loading = false;
        this.setMockDataFlag(false);
        this.initStudio();
      },
      error: (err) => {
        console.error('fetchFromContentStudio failed in studio:', err);
        this.orc = this.stateService.createBlankOrchestration();
        this.loading = false;
        this.setMockDataFlag(false);
        this.initStudio();
      }
    });
  }

  private loadMockOrchestrationById(id: string): any {
    const item = MOCK_ORCHESTRATIONS.find(o => o.Id === id) || MOCK_ORCHESTRATIONS[0];
    if (!item) return null;
    let content: any = item.DynamicProperties?.OrchestrationContent;
    if (typeof content === 'string') {
      try { content = JSON.parse(content); } catch (_) { content = {}; }
    }
    return content ?? {};
  }

  private setMockDataFlag(isMock: boolean): void {
    this.isMockData = isMock;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { mock: isMock ? 'true' : null },
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }

  private updateTreeNodes(): void {
    this.treeNodes = this.flattenSteps(this.orc?.steps || [], 0);
  }

  private expandAllNodes(): void {
    this.expandedNodes.clear();
    const collectCallIds = (steps: any[]) => {
      steps.forEach(step => {
        this.expandedNodes.add(step.callId);
        if (step.children?.steps) collectCallIds(step.children.steps);
        if (step.iteration?.steps) collectCallIds(step.iteration.steps);
      });
    };
    collectCallIds(this.orc?.steps || []);
  }

  private flattenSteps(steps: any[], depth: number, parentType?: string): StudioTreeNode[] {
    const result: StudioTreeNode[] = [];
    steps.forEach(step => {
      const hasNoDeps = (step.dependencies || []).length === 0;
      const badge = parentType === 'iteration' ? 'M' : hasNoDeps ? 'P' : 'S';
      const nodeKind: 'root' | 'dependent' | 'child' | 'iteration' =
        parentType === 'iteration' ? 'iteration' :
        parentType === 'children' ? 'child' :
        hasNoDeps ? 'root' : 'dependent';
      const showLabel = depth === 0;
      result.push({ step, depth, badge, showLabel, nodeKind });

      if (step.children?.steps?.length) {
        result.push(...this.flattenSteps(step.children.steps, depth + 1, 'children'));
      }
      if (step.iteration?.steps?.length) {
        result.push(...this.flattenSteps(step.iteration.steps, depth + 1, 'iteration'));
      }
    });
    return result;
  }

  isNodeVisible(node: StudioTreeNode): boolean {
    if (node.depth === 0) return true;
    // Walk up the tree to check if all ancestors are expanded
    const findAncestors = (targetCallId: string, steps: any[], ancestors: string[] = []): string[] => {
      for (const step of steps) {
        if (step.callId === targetCallId) return ancestors;
        if (step.children?.steps) {
          const result = findAncestors(targetCallId, step.children.steps, [...ancestors, step.callId]);
          if (result.length > 0) return result;
        }
        if (step.iteration?.steps) {
          const result = findAncestors(targetCallId, step.iteration.steps, [...ancestors, step.callId]);
          if (result.length > 0) return result;
        }
      }
      return [];
    };
    const ancestors = findAncestors(node.step.callId, this.orc?.steps || []);
    return ancestors.every(ancestorCallId => this.expandedNodes.has(ancestorCallId));
  }

  hasChildren(step: any): boolean {
    return !!(step.children?.steps?.length || step.iteration?.steps?.length);
  }

  toggleNode(callId: string, event?: Event): void {
    if (event) event.stopPropagation();
    if (this.expandedNodes.has(callId)) {
      this.expandedNodes.delete(callId);
    } else {
      this.expandedNodes.add(callId);
    }
  }

  isExpanded(callId: string): boolean {
    return this.expandedNodes.has(callId);
  }

  onDragStart(event: DragEvent, node: StudioTreeNode): void {
    this.draggedCallId = node.step.callId;
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'move';
    }
  }

  onDrop(event: DragEvent, targetNode: StudioTreeNode): void {
    event.preventDefault();
    if (!this.draggedCallId || targetNode.depth > 0) return; // Only allow top-level reordering

    const steps = this.orc?.steps || [];
    const draggedIdx = steps.findIndex((s: any) => s.callId === this.draggedCallId);
    const targetIdx = steps.findIndex((s: any) => s.callId === targetNode.step.callId);

    if (draggedIdx >= 0 && targetIdx >= 0 && draggedIdx !== targetIdx) {
      const [draggedStep] = steps.splice(draggedIdx, 1);
      steps.splice(targetIdx, 0, draggedStep);
      this.stateService.saveOrchestration(this.orc);
      this.stateService.setBuilderDraft(this.orc);
    }
    this.draggedCallId = null;
  }

  selectStep(step: any): void {
    this.selectedStep = step;
    this.selectedStepApi = this.getApiForStep(step);
    this.activeDetailTab = 'basic';
    this.initTestTab();
  }

  get flowSummary(): { services: number; dependencies: number; executionMode: string } {
    const steps = this.orc?.steps || [];
    const services = steps.length;
    const dependencies = steps.reduce((n: number, s: any) => n + (s.dependencies?.length || 0), 0);
    return { services, dependencies, executionMode: 'parallel' };
  }

  onAddStep(): void {
    this.flyoutService.open('browse-apis-builder', {
      targetType: this.selectedStep ? 'dependent' : 'root',
      parentCallId: this.selectedStep?.callId || null
    });
  }

  @HostListener('document:click')
  closeAddMenu(): void {
    this.activeAddMenu = null;
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      this.save();
    }
  }

  save(goBack = false): void {
    let draft: any;
    if (this.activeDetailTab === 'advanced' && this.isJsonDirty && !this.jsonError) {
      try {
        draft = JSON.parse(this.jsonDraft);
        this.stateService.setBuilderDraft(draft);
        this.orc = JSON.parse(JSON.stringify(draft));
        this.isJsonDirty = false;
      } catch (_) {
        draft = this.stateService.getBuilderDraft() || this.orc;
      }
    } else {
      draft = this.stateService.getBuilderDraft() || this.orc;
    }
    if (!draft) return;

    if (this.item) {
      this.isSaving = true;
      const payload: any = JSON.parse(JSON.stringify(this.item));
      if (!payload.DynamicProperties) { payload.DynamicProperties = {}; }
      payload.DynamicProperties.OrchestrationContent = JSON.stringify(draft, null, 2);
      const collectionId = payload.CollectionId || payload.collectionId || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
      const url = `https://csstudio-sitg3-authoringapi.pnp2.pcf.dell.com/api/${collectionId}/item/updateandcheckin?listIdOrName=${collectionId}`;
      this.http.post<any>(url, payload).subscribe({
        next: () => {
          this.orc = JSON.parse(JSON.stringify(draft));
          this.stateService.setBuilderDraft(this.orc);
          this.isSaving = false;
          this.showToast('Orchestration saved successfully');
          if (goBack) this.router.navigate(['/orchestrations']);
        },
        error: (err) => {
          this.isSaving = false;
          const errMsg = err?.error?.message || err?.message || 'Save failed. Please try again.';
          this.showToast('Error: ' + errMsg);
        }
      });
    } else {
      if (!draft.name?.trim()) { alert('Please enter an orchestration name'); return; }
      draft.version = this.stateService.bumpVersion(draft.version || '1.0.0');
      this.stateService.saveOrchestration(draft);
      this.stateService.setBuilderDraft(draft);
      this.orc = JSON.parse(JSON.stringify(draft));
      this.isSaving = true;
      setTimeout(() => { this.isSaving = false; }, 600);
      this.showToast('Orchestration saved locally');
      if (goBack) this.router.navigate(['/orchestrations']);
    }
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  toggleAddMenu(key: string, event: Event): void {
    event.stopPropagation();
    if (this.activeAddMenu === key) { this.activeAddMenu = null; return; }
    const btn = (event.currentTarget as HTMLElement);
    const rect = btn.getBoundingClientRect();
    this.addMenuPos = {
      top: rect.bottom + 4,
      right: window.innerWidth - rect.right
    };
    this.activeAddMenu = key;
  }

  addRootStep(): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', { targetType: 'root', parentCallId: null });
  }

  addFollowupStep(parentCallId?: string | null): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', {
      targetType: 'dependent',
      parentCallId: parentCallId ?? this.selectedStep?.callId ?? null
    });
  }

  addChildStep(parentCallId: string): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', {
      targetType: 'direct-child',
      parentCallId
    });
  }

  setIterateStep(callId: string): void {
    this.activeAddMenu = null;
    this.flyoutService.open('iteration-configure', { callId });
  }

  getStepKindIcon(node: StudioTreeNode): string {
    if (node.step.iteration) return '↻';
    if (node.step.children?.steps?.length) return '⊕';
    if (node.nodeKind === 'iteration') return '↻';
    if (node.nodeKind === 'child') return '⤷';
    if (node.nodeKind === 'dependent') return '↪';
    return '◉';
  }

  getStepKindTitle(node: StudioTreeNode): string {
    if (node.step.iteration) return 'Iterating step';
    if (node.step.children?.steps?.length) return 'Has child steps';
    if (node.nodeKind === 'iteration') return 'Iteration child';
    if (node.nodeKind === 'child') return 'Child step';
    if (node.nodeKind === 'dependent') return 'Follow-up step';
    return 'Root step';
  }

  openOrcSettings(): void {
    this.flyoutService.open('orc-settings', { id: this.orc?.id });
  }

  downloadFlow(): void {
    if (!this.orc) return;
    const stripped = {
      id: this.orc.id,
      orchestrationId: this.orc.orchestrationId,
      name: this.orc.name,
      description: this.orc.description,
      version: this.orc.version,
      steps: this.orc.steps || []
    };
    const profile = this.orc.requestData?.profile || { country: 'us', language: 'en', region: 'us', segment: 'cnsr', market: 'usa_market' };
    const payload = { orchestration: stripped, requestData: { profile } };
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const safeName = (this.orc.name || this.orc.id || 'orchestration')
      .toString()
      .trim()
      .replace(/[^a-z0-9-_]+/gi, '-')
      .replace(/^-+|-+$/g, '') || 'orchestration';
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeName}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Input mapping
  getStepInputRows(step: any): { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] {
    const rows: { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] = [];
    const seen = new Set<string>();

    // 1. URL path params
    this.extractUrlPathParams(step?.endpoint || '').forEach(name => {
      rows.push({ name, type: 'string', required: true, custom: false, paramIn: 'path' });
      seen.add(name);
    });

    // 2. Explicit step.inputs
    if (Array.isArray(step?.inputs)) {
      step.inputs.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || 'string', required: !!i.required, custom: false, paramIn: i.in || 'body' });
          seen.add(i.name);
        }
      });
    }

    // 3. API-definition inputs (check both api.inputs and api.inputMapping)
    const api = this.getApiForStep(step);
    if (api) {
      const apiInputs: any[] = Array.isArray(api.inputs) ? api.inputs
        : Array.isArray(api.inputMapping) ? api.inputMapping
        : [];
      apiInputs.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || '', required: !!i.required, custom: false, paramIn: i.in || 'query' });
          seen.add(i.name);
        }
      });
    }

    // 4. Extra custom inputMapping keys
    const map = step?.inputMapping || {};
    Object.keys(map).forEach(k => {
      if (!seen.has(k)) rows.push({ name: k, type: '', required: false, custom: true, paramIn: this.getMappingIn(map[k]) });
    });

    return rows;
  }

  getInputMappingChip(step: any, paramName: string): { icon: string; label: string; tag: string; isUnmapped: boolean } {
    if (!this.isInputMapped(step, paramName)) {
      return { icon: '＋', label: 'Connect a source…', tag: '', isUnmapped: true };
    }
    const raw = this.getMappingSourceExpr((step?.inputMapping || {})[paramName]);
    const draft = this.orc;
    const sources = draft ? this.availableDataService.getAvailableSources(draft, step.callId) : [];
    const expr = parseMappingExpr(raw, sources.filter(s => s.kind === 'step').map((s: any) => s.callId));

    if (expr.kind === 'flowInput') {
      return { icon: '⚡', label: `Flow input · ${expr.path || '(root)'}`, tag: 'flow', isUnmapped: false };
    }
    if (expr.kind === 'loopItem') {
      return { icon: '🔄', label: `Loop item · ${expr.path || '(root)'}`, tag: 'loop', isUnmapped: false };
    }
    if (expr.kind === 'stepOutput') {
      return { icon: '📤', label: `${expr.callId} · ${expr.path || '(root)'}`, tag: 'step', isUnmapped: false };
    }
    return { icon: '✎', label: `Literal · ${String(raw).substring(0, 20)}...`, tag: 'literal', isUnmapped: false };
  }

  private isInputMapped(step: any, paramName: string): boolean {
    const map = step?.inputMapping || {};
    if (!Object.prototype.hasOwnProperty.call(map, paramName)) return false;
    const v = map[paramName];
    const src = this.getMappingSourceExpr(v);
    return src !== '' && src !== undefined && src !== null;
  }

  openSourcePicker(step: any, paramName: string, paramIn: string): void {
    this.flyoutService.open('source-picker', { callId: step.callId, paramName, paramIn });
  }

  clearInputMapping(callId: string, paramName: string): void {
    if (!this.orc) return;
    const step = this.stateService.getStepById(this.orc, callId);
    if (!step || !step.inputMapping) return;
    delete step.inputMapping[paramName];
    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
  }

  addCustomInput(): void {
    if (!this.selectedStep) return;
    this.flyoutService.open('add-custom-input', { callId: this.selectedStep.callId });
  }

  deleteSelectedStep(): void {
    if (!this.selectedStep || !this.orc) return;
    if (!confirm(`Remove step "${this.selectedStep.callId}"? Any steps that depend on it will lose this dependency.`)) return;
    this.stateService.removeStep(this.orc, this.selectedStep.callId);
    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
    this.selectedStep = null;
    this.selectedStepApi = null;
    this.updateTreeNodes();
  }

  getMappedInputCount(step: any): number {
    return this.getStepInputRows(step).filter(r => this.isInputMapped(step, r.name)).length;
  }

  getTotalInputCount(step: any): number {
    return this.getStepInputRows(step).length;
  }

  // Field selection
  isFieldSelected(name: string): boolean {
    return (this.selectedStep?.fields || []).includes(name);
  }

  toggleField(name: string): void {
    if (!this.selectedStep) return;
    const fields = this.selectedStep.fields || [];
    const idx = fields.indexOf(name);
    if (idx >= 0) {
      fields.splice(idx, 1);
    } else {
      fields.push(name);
    }
    this.selectedStep.fields = fields;
    this.stateService.updateStep(this.orc, this.selectedStep.callId, { fields });
    this.stateService.saveOrchestration(this.orc);
    this.stateService.setBuilderDraft(this.orc);
  }

  toggleAllFields(): void {
    if (!this.selectedStep) return;
    const rawFields = this.selectedStepApi?.outputs || this.selectedStepApi?.fields
      || this.selectedStep?.outputs || [];
    const allFieldNames = rawFields.map((f: any) => typeof f === 'string' ? f : f.name);
    const hasAll = allFieldNames.every((name: string) => this.isFieldSelected(name));
    this.selectedStep.fields = hasAll ? [] : allFieldNames;
    this.stateService.updateStep(this.orc, this.selectedStep.callId, { fields: this.selectedStep.fields });
    this.stateService.saveOrchestration(this.orc);
    this.stateService.setBuilderDraft(this.orc);
  }

  saveRequest(): void {
    this.stateService.saveOrchestration(this.orc);
  }

  initTestTab(): void {
    const draft = this.orc;
    if (!draft) return;
    const stripped = {
      id: draft.id,
      orchestrationId: draft.orchestrationId,
      name: draft.name,
      description: draft.description,
      version: draft.version,
      steps: draft.steps || []
    };
    const defaultProfile = { country: 'us', language: 'en', region: 'us', segment: 'cnsr', market: 'usa_market' };
    const profile = draft.requestData?.profile
      ? { ...defaultProfile, ...draft.requestData.profile }
      : defaultProfile;
    const requestBody = { orchestration: stripped, requestData: { profile } };
    this.testRequestJson = JSON.stringify(requestBody, null, 2);
    this.testRequestJsonError = '';
  }

  onTestRequestInput(val: string): void {
    try {
      JSON.parse(val);
      this.testRequestJsonError = '';
    } catch (e: any) {
      this.testRequestJsonError = e.message;
    }
  }

  sendTestRequest(): void {
    let parsedBody: any;
    try {
      parsedBody = JSON.parse(this.testRequestJson);
    } catch (e: any) {
      this.testStatusCode = 400;
      this.testResponseJson = JSON.stringify({ error: 'Invalid request JSON', detail: e.message }, null, 2);
      return;
    }

    this.isTesting = true;
    this.testResponseJson = '';
    this.testStatusCode = null;

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.http.post(this.testApiUrl, parsedBody, { headers, observe: 'response' })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.testStatusCode = response.status;
          this.testResponseJson = JSON.stringify(response.body, null, 2);
          this.isTesting = false;
        },
        error: (err: HttpErrorResponse) => {
          this.testStatusCode = err.status || 0;
          const body = err.error;
          if (body && typeof body === 'object') {
            this.testResponseJson = JSON.stringify(body, null, 2);
          } else if (typeof body === 'string') {
            try { this.testResponseJson = JSON.stringify(JSON.parse(body), null, 2); }
            catch { this.testResponseJson = JSON.stringify({ error: body || err.message }, null, 2); }
          } else {
            this.testResponseJson = JSON.stringify({ error: err.message || 'Request failed', status: err.status }, null, 2);
          }
          this.isTesting = false;
        }
      });
  }

  private extractUrlPathParams(endpoint: string): string[] {
    if (!endpoint) return [];
    const matches = endpoint.match(/\{([^}]+)\}/g);
    return matches ? matches.map(m => m.slice(1, -1)) : [];
  }

  private getMappingSourceExpr(val: any): any {
    if (val && typeof val === 'object' && '$source' in val) return val.$source;
    return val;
  }

  private getMappingIn(val: any): string {
    if (val && typeof val === 'object' && '$in' in val) return val.$in;
    return 'body';
  }

  private getApiForStep(step: any): any | null {
    if (!step) return null;
    if (step.apiId) {
      return this.stateService.getApiById(step.apiId) || null;
    }
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint) || null;
  }

  getFieldRows(): any[][][] {
    const rawFields = this.selectedStepApi?.outputs || this.selectedStepApi?.fields
      || this.selectedStep?.outputs || [];
    const fields = rawFields.map((f: any) =>
      typeof f === 'string' ? { name: f } : f
    );
    const fieldsPerColumn = 5;
    const columnsPerRow = 3;
    const fieldsPerRow = fieldsPerColumn * columnsPerRow;
    const rows: any[][][] = [];

    for (let i = 0; i < fields.length; i += fieldsPerRow) {
      const rowFields = fields.slice(i, i + fieldsPerRow);
      const columns: any[][] = [];

      for (let j = 0; j < rowFields.length; j += fieldsPerColumn) {
        columns.push(rowFields.slice(j, j + fieldsPerColumn));
      }

      rows.push(columns);
    }

    return rows;
  }
}
