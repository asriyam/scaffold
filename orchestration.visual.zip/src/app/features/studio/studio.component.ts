import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';
import { AvailableDataService } from '@core/services/available-data.service';
import { parseMappingExpr } from '@core/services/mapping-expr';
import { MOCK_ORCHESTRATIONS, MOCK_ORCHESTRATION_DEFINITIONS } from '@core/mockdata/orchestrations';

interface StudioTreeNode {
  step: any;
  depth: number;
  badge: 'S' | 'P' | 'M';
  showLabel: boolean;
  nodeKind: 'root' | 'dependent' | 'child' | 'iteration' | 'iteration-container';
  isIterationContainer?: boolean;
  iterationParentCallId?: string;
  iterationSource?: string;
}

@Component({
  selector: 'app-studio',
  templateUrl: './studio.component.html',
  styleUrls: ['./studio.component.scss']
})
export class StudioComponent implements OnInit, OnDestroy {
  orc: any = null;
  allOrchestrations: any[] = [];
  selectedStep: any = null;
  selectedStepApi: any = null;
  rootNodeSelected = false;
  variableRows: { key: string; value: string; error?: string }[] = [];
  /** Per-input-row inline editor state, keyed by param name. Rebuilt on selectedStep change.
   *  sourceKey discriminator: '' | 'flow' | 'fixed' | 'loop:<ownerCallId>' | 'step:<callId>' */
  inputEditState: Record<string, { sourceKey: string; field: string; loopProp: string; fixedText: string }> = {};
  /** Sources for the current selectedStep — precomputed once per selection change so template
   *  bindings stay referentially stable (otherwise Angular CD calls getRowSources() infinitely). */
  rowSources: any[] = [];
  loopSources: any[] = [];
  stepSources: any[] = [];
  flowSource: any = null;
  sourceByKey: Record<string, any> = {};
  /** Stable input-row list for the current selectedStep — precomputed so *ngFor doesn't see
   *  a new array ref on every CD pass (which would tear down each [ngModel] form control). */
  inputRowsForSelected: { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] = [];
  trackInputRowByName = (_: number, r: { name: string }) => r.name;
  activeDetailTab: 'basic' | 'advanced' | 'try' = 'basic';
  isInputMappingExpanded = true;
  isFieldSelectionExpanded = true;

  // Advanced JSON editor
  jsonDraft = '';
  jsonError = '';
  isJsonDirty = false;
  isJsonExpanded = false;
  isTryExpanded = false;
  expandedNodes = new Set<string>();
  treeNodes: StudioTreeNode[] = [];
  item: any = null;
  isSaving = false;
  draggedCallId: string | null = null;
  activeAddMenu: string | null = null;
  addMenuPos: { top: number; right: number } = { top: 0, right: 0 };

  // Try It Out
  testApiUrl = 'https://orchestrationapi.studiod-r3-np.kob.dell.com/api/orchestration/preview/execute?skipCache=false&includeMetrics=true';
  testRequestJson = '';
  testResponseJson = '';
  testStatusCode: number | null = null;
  isTesting = false;
  testRequestJsonError = '';

  isDebugMode = false;
  isMockData = false;
  loading = false;

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService,
    private flyoutService: FlyoutService,
    private availableDataService: AvailableDataService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.isDebugMode = this.route.snapshot.queryParamMap.get('debug') === 'true';
    const apiOrcs = this.stateService.getOrchestrations();
    this.allOrchestrations = apiOrcs.length > 0 ? apiOrcs : MOCK_ORCHESTRATION_DEFINITIONS;

    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const useMock = this.route.snapshot.queryParamMap.get('mock') === 'true';

      if (params['id']) {
        if (useMock) {
          this.orc = this.loadMockOrchestrationById(params['id']);
          this.setMockDataFlag(true);
        } else {
          this.orc = this.stateService.getOrchestrationById(params['id']);
          if (!this.orc) {
            this.orc = MOCK_ORCHESTRATION_DEFINITIONS.find(o => o.id === params['id']);
            if (this.orc) {
              this.setMockDataFlag(true);
            } else {
              const collectionId = this.route.snapshot.queryParamMap.get('collectionId');
              const contentType = this.route.snapshot.queryParamMap.get('contentType') || 'UnifiedOrchestration';
              if (collectionId) {
                this.fetchFromContentStudio(params['id'], collectionId, contentType);
                return;
              }
            }
          } else {
            this.setMockDataFlag(false);
          }
        }
      } else {
        this.orc = this.stateService.getBuilderDraft() || this.allOrchestrations[0];
        this.setMockDataFlag(useMock);
      }
      if (this.orc) {
        this.initStudio();
      }
    });

    // Sync from draft when flyout closes
    this.flyoutService.isOpen$
      .pipe(
        pairwise(),
        filter(([prev, curr]) => prev && !curr),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.orc = this.stateService.getBuilderDraft();
        if (this.selectedStep) {
          const renamed = this.flyoutService.lastClosedContext?.newCallId;
          const oldId = this.selectedStep.callId;
          if (renamed && oldId !== renamed && this.expandedNodes.has(oldId)) {
            this.expandedNodes.delete(oldId);
            this.expandedNodes.add(renamed);
          }
          const lookupId = renamed || oldId;
          this.selectedStep = this.stateService.getStepById(this.orc, lookupId);
          if (this.selectedStep) {
            this.selectedStepApi = this.getApiForStep(this.selectedStep);
            this.initInputEditState();
          }
        }
        this.flyoutService.lastClosedContext = null;
        if (this.rootNodeSelected) {
          this.loadVariableRows();
        }
        this.updateTreeNodes();
        this.initTestTab();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initStudio(): void {
    this.orc = this.stateService.sanitize(this.orc);
    this.stateService.setBuilderDraft(this.orc);
    this.expandAllNodes();
    this.updateTreeNodes();
    this.resetJsonDraft();
    const firstStep = this.orc?.steps?.[0];
    if (firstStep) {
      this.selectStep(firstStep);
    } else {
      this.selectedStep = null;
      this.selectedStepApi = null;
      this.initTestTab();
    }
  }

  onAdvancedTabClick(): void {
    this.activeDetailTab = 'advanced';
    if (!this.isJsonDirty) {
      this.resetJsonDraft();
    }
  }

  private resetJsonDraft(): void {
    this.jsonDraft = JSON.stringify(this.orc || {}, null, 2);
    this.jsonError = '';
    this.isJsonDirty = false;
  }

  onJsonInput(value: string): void {
    this.jsonDraft = value;
    this.isJsonDirty = true;
    try {
      JSON.parse(value);
      this.jsonError = '';
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  applyJson(): void {
    if (this.jsonError) return;
    try {
      const parsed = JSON.parse(this.jsonDraft);
      this.orc = parsed;
      this.stateService.setBuilderDraft(this.orc);
      this.stateService.saveOrchestration(this.orc);
      this.expandAllNodes();
      this.updateTreeNodes();
      if (this.selectedStep) {
        const restored = this.stateService.getStepById(this.orc, this.selectedStep.callId);
        if (restored) {
          this.selectedStep = restored;
          this.selectedStepApi = this.getApiForStep(restored);
        } else {
          this.selectedStep = null;
          this.selectedStepApi = null;
        }
      }
      this.initTestTab();
      this.isJsonDirty = false;
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  resetJson(): void {
    this.resetJsonDraft();
  }

  toggleJsonExpanded(): void {
    this.isJsonExpanded = !this.isJsonExpanded;
  }

  toggleInputMapping(): void {
    this.isInputMappingExpanded = !this.isInputMappingExpanded;
  }

  toggleFieldSelection(): void {
    this.isFieldSelectionExpanded = !this.isFieldSelectionExpanded;
  }

  toggleTryExpanded(): void {
    this.isTryExpanded = !this.isTryExpanded;
  }

  private fetchFromContentStudio(itemId: string, collectionId: string, contentType: string): void {
    this.loading = true;
    const url = `https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/GetItem`
      + `?collectionId=${encodeURIComponent(collectionId)}`
      + `&contentType=${encodeURIComponent(contentType)}`
      + `&itemId=${encodeURIComponent(itemId)}`;

    this.http.get<any>(url).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        this.item = res;
        let orchContent = res?.DynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.orchestrationContent
          || res?.DynamicProperties?.orchestrationContent;
        if (typeof orchContent === 'string') {
          try { orchContent = JSON.parse(orchContent); } catch (_) { orchContent = {}; }
        }
        this.orc = orchContent ?? {};
        this.loading = false;
        this.setMockDataFlag(false);
        this.initStudio();
      },
      error: (err) => {
        console.error('fetchFromContentStudio failed in studio:', err);
        this.orc = this.stateService.createBlankOrchestration();
        this.loading = false;
        this.setMockDataFlag(false);
        this.initStudio();
      }
    });
  }

  private loadMockOrchestrationById(id: string): any {
    const item = MOCK_ORCHESTRATIONS.find(o => o.Id === id) || MOCK_ORCHESTRATIONS[0];
    if (!item) return null;
    let content: any = item.DynamicProperties?.OrchestrationContent;
    if (typeof content === 'string') {
      try { content = JSON.parse(content); } catch (_) { content = {}; }
    }
    return content ?? {};
  }

  private setMockDataFlag(isMock: boolean): void {
    this.isMockData = isMock;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { mock: isMock ? 'true' : null },
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }

  private updateTreeNodes(): void {
    this.treeNodes = this.flattenSteps(this.orc?.steps || [], 0);
  }

  private expandAllNodes(): void {
    this.expandedNodes.clear();
    const collectCallIds = (steps: any[]) => {
      steps.forEach(step => {
        this.expandedNodes.add(step.callId);
        if (step.children?.steps) collectCallIds(step.children.steps);
        if (step.iteration?.steps) collectCallIds(step.iteration.steps);
      });
    };
    collectCallIds(this.orc?.steps || []);
  }

  private flattenSteps(steps: any[], depth: number, parentType?: string): StudioTreeNode[] {
    const result: StudioTreeNode[] = [];
    steps.forEach(step => {
      const hasNoDeps = (step.dependencies || []).length === 0;
      const badge = parentType === 'iteration' ? 'M' : hasNoDeps ? 'P' : 'S';
      const nodeKind: 'root' | 'dependent' | 'child' | 'iteration' =
        parentType === 'iteration' ? 'iteration' :
        parentType === 'children' ? 'child' :
        hasNoDeps ? 'root' : 'dependent';
      const showLabel = depth === 0;
      result.push({ step, depth, badge, showLabel, nodeKind });

      if (step.children?.steps?.length) {
        result.push(...this.flattenSteps(step.children.steps, depth + 1, 'children'));
      }
      if (step.iteration) {
        const containerCallId = `__iter__${step.callId}`;
        result.push({
          step: { callId: containerCallId },
          depth: depth + 1,
          badge: 'M',
          showLabel: false,
          nodeKind: 'iteration-container',
          isIterationContainer: true,
          iterationParentCallId: step.callId,
          iterationSource: step.iteration.source || ''
        });
        if (step.iteration.steps?.length) {
          result.push(...this.flattenSteps(step.iteration.steps, depth + 2, 'iteration'));
        }
      }
    });
    return result;
  }

  isNodeVisible(node: StudioTreeNode): boolean {
    if (node.depth === 0) return true;
    // Walk up the tree to check if all ancestors are expanded
    const findAncestors = (targetCallId: string, steps: any[], ancestors: string[] = []): string[] => {
      for (const step of steps) {
        if (step.callId === targetCallId) return ancestors;
        if (step.children?.steps) {
          const result = findAncestors(targetCallId, step.children.steps, [...ancestors, step.callId]);
          if (result.length > 0) return result;
        }
        if (step.iteration?.steps) {
          const result = findAncestors(targetCallId, step.iteration.steps, [...ancestors, step.callId]);
          if (result.length > 0) return result;
        }
      }
      return [];
    };
    // Virtual iteration container: visible if its owner step (and its ancestors) are expanded
    if (node.isIterationContainer) {
      const ownerCallId = node.iterationParentCallId!;
      if (!this.expandedNodes.has(ownerCallId)) return false;
      const ancestors = findAncestors(ownerCallId, this.orc?.steps || []);
      return ancestors.every(ancestorCallId => this.expandedNodes.has(ancestorCallId));
    }
    const ancestors = findAncestors(node.step.callId, this.orc?.steps || []);
    return ancestors.every(ancestorCallId => this.expandedNodes.has(ancestorCallId));
  }

  hasChildren(step: any): boolean {
    return !!(step.children?.steps?.length || step.iteration);
  }

  toggleNode(callId: string, event?: Event): void {
    if (event) event.stopPropagation();
    if (this.expandedNodes.has(callId)) {
      this.expandedNodes.delete(callId);
    } else {
      this.expandedNodes.add(callId);
    }
  }

  isExpanded(callId: string): boolean {
    return this.expandedNodes.has(callId);
  }

  onDragStart(event: DragEvent, node: StudioTreeNode): void {
    this.draggedCallId = node.step.callId;
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'move';
    }
  }

  onDrop(event: DragEvent, targetNode: StudioTreeNode): void {
    event.preventDefault();
    const draggedId = this.draggedCallId;
    this.draggedCallId = null;
    if (!draggedId || !this.orc?.steps) return;
    if (targetNode.isIterationContainer) return; // virtual row, not a real step
    if (draggedId === targetNode.step.callId) return;

    const draggedLoc = this.findContainingArray(this.orc.steps, draggedId);
    const targetLoc = this.findContainingArray(this.orc.steps, targetNode.step.callId);
    if (!draggedLoc || !targetLoc) return;
    // Only reorder within the same sibling list.
    if (draggedLoc.arr !== targetLoc.arr) return;

    const arr = draggedLoc.arr;
    const fromIdx = draggedLoc.idx;
    const targetIdx = targetLoc.idx;
    const [moved] = arr.splice(fromIdx, 1);
    // After removal, indices ≥ fromIdx shift left by one.
    const insertIdx = fromIdx < targetIdx ? targetIdx - 1 : targetIdx;
    arr.splice(insertIdx, 0, moved);

    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
    this.updateTreeNodes();
  }

  /** Find the array (orc.steps, step.children.steps, or step.iteration.steps) that directly
   *  contains a step with the given callId, plus its index in that array. Returns null if
   *  the callId is not found anywhere in the tree. */
  private findContainingArray(steps: any[], callId: string): { arr: any[]; idx: number } | null {
    for (let i = 0; i < steps.length; i++) {
      const s = steps[i];
      if (s.callId === callId) return { arr: steps, idx: i };
      if (Array.isArray(s.children?.steps)) {
        const r = this.findContainingArray(s.children.steps, callId);
        if (r) return r;
      }
      if (Array.isArray(s.iteration?.steps)) {
        const r = this.findContainingArray(s.iteration.steps, callId);
        if (r) return r;
      }
    }
    return null;
  }

  selectRootNode(): void {
    this.selectedStep = null;
    this.selectedStepApi = null;
    this.rootNodeSelected = true;
    this.loadVariableRows();
  }

  selectStep(step: any): void {
    this.selectedStep = step;
    this.selectedStepApi = this.getApiForStep(step);
    this.rootNodeSelected = false;
    this.activeDetailTab = 'basic';
    this.initInputEditState();
    this.initTestTab();
  }

  private loadVariableRows(): void {
    const draft = this.stateService.getBuilderDraft();
    this.variableRows = Object.entries(draft?.variables || {}).map(([k, v]) => ({
      key: k,
      value: (v !== null && typeof v === 'object') ? JSON.stringify(v, null, 2) : String(v)
    }));
  }

  isObjectLike(text: string): boolean {
    const t = (text || '').trim();
    return t.startsWith('{') || t.startsWith('[');
  }

  private coerceVariableValue(raw: string): { ok: boolean; value?: any } {
    if (this.isObjectLike(raw)) {
      try { return { ok: true, value: JSON.parse(raw.trim()) }; }
      catch { return { ok: false }; }
    }
    return { ok: true, value: isNaN(Number(raw)) ? raw : Number(raw) };
  }

  addVariableRow(): void {
    this.variableRows = [...this.variableRows, { key: '', value: '' }];
  }

  removeVariableRow(i: number): void {
    this.variableRows = this.variableRows.filter((_, idx) => idx !== i);
  }

  saveVariables(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const variables: any = {};
    let hasError = false;
    this.variableRows.filter(r => r.key.trim()).forEach(r => {
      const key = r.key.trim();
      const result = this.coerceVariableValue(r.value);
      if (result.ok) {
        r.error = '';
        variables[key] = result.value;
      } else {
        r.error = 'Invalid JSON';
        hasError = true;
      }
    });
    if (hasError) {
      this.showToast('Fix invalid JSON before applying');
      return;
    }
    this.stateService.updateOrcSettings(draft, { variables });
    this.stateService.setBuilderDraft(draft);
    this.orc = { ...this.orc, variables };
    this.showToast('Variables saved');
  }

  get flowSummary(): { services: number; dependencies: number; executionMode: string } {
    const steps = this.orc?.steps || [];
    const services = steps.length;
    const dependencies = steps.reduce((n: number, s: any) => n + (s.dependencies?.length || 0), 0);
    return { services, dependencies, executionMode: 'parallel' };
  }

  onAddStep(): void {
    this.flyoutService.open('browse-apis-builder', {
      targetType: this.selectedStep ? 'dependent' : 'root',
      parentCallId: this.selectedStep?.callId || null
    });
  }

  @HostListener('document:click')
  closeAddMenu(): void {
    this.activeAddMenu = null;
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      this.save();
    }
  }

  save(goBack = false): void {
    let draft: any;
    if (this.activeDetailTab === 'advanced' && this.isJsonDirty && !this.jsonError) {
      try {
        draft = JSON.parse(this.jsonDraft);
        this.stateService.setBuilderDraft(draft);
        this.orc = JSON.parse(JSON.stringify(draft));
        this.isJsonDirty = false;
      } catch (_) {
        draft = this.stateService.getBuilderDraft() || this.orc;
      }
    } else {
      draft = this.stateService.getBuilderDraft() || this.orc;
    }
    if (!draft) return;

    if (this.item) {
      this.isSaving = true;
      const payload: any = JSON.parse(JSON.stringify(this.item));
      if (!payload.DynamicProperties) { payload.DynamicProperties = {}; }
      payload.DynamicProperties.OrchestrationContent = JSON.stringify(draft, null, 2);
      const collectionId = payload.CollectionId || payload.collectionId || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
      const url = `https://csstudio-sitg3-authoringapi.pnp2.pcf.dell.com/api/${collectionId}/item/updateandcheckin?listIdOrName=${collectionId}`;
      this.http.post<any>(url, payload).subscribe({
        next: () => {
          this.orc = JSON.parse(JSON.stringify(draft));
          this.stateService.setBuilderDraft(this.orc);
          this.isSaving = false;
          this.showToast('Orchestration saved successfully');
          if (goBack) this.router.navigate(['/orchestrations']);
        },
        error: (err) => {
          this.isSaving = false;
          const errMsg = err?.error?.message || err?.message || 'Save failed. Please try again.';
          this.showToast('Error: ' + errMsg);
        }
      });
    } else {
      if (!draft.name?.trim()) { alert('Please enter an orchestration name'); return; }
      draft.version = this.stateService.bumpVersion(draft.version || '1.0.0');
      this.stateService.saveOrchestration(draft);
      this.stateService.setBuilderDraft(draft);
      this.orc = JSON.parse(JSON.stringify(draft));
      this.isSaving = true;
      setTimeout(() => { this.isSaving = false; }, 600);
      this.showToast('Orchestration saved locally');
      if (goBack) this.router.navigate(['/orchestrations']);
    }
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  toggleAddMenu(key: string, event: Event): void {
    event.stopPropagation();
    if (this.activeAddMenu === key) { this.activeAddMenu = null; return; }
    const btn = (event.currentTarget as HTMLElement);
    const rect = btn.getBoundingClientRect();
    this.addMenuPos = {
      top: rect.bottom + 4,
      right: window.innerWidth - rect.right
    };
    this.activeAddMenu = key;
  }

  addRootStep(): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', { targetType: 'root', parentCallId: null });
  }

  addFollowupStep(parentCallId?: string | null): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', {
      targetType: 'dependent',
      parentCallId: parentCallId ?? this.selectedStep?.callId ?? null
    });
  }

  addChildStep(parentCallId: string): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', {
      targetType: 'direct-child',
      parentCallId
    });
  }

  setIterateStep(callId: string): void {
    this.activeAddMenu = null;
    this.flyoutService.open('iteration-configure', { callId });
  }

  addIterationChildStep(parentCallId: string): void {
    this.activeAddMenu = null;
    this.flyoutService.open('browse-apis-builder', {
      targetType: 'iteration-child',
      parentCallId
    });
  }

  hasIteration(callId: string | null | undefined): boolean {
    if (!callId || !this.orc) return false;
    return !!this.stateService.getStepById(this.orc, callId)?.iteration;
  }

  removeIteration(parentCallId: string): void {
    if (!this.orc) return;
    if (!confirm('Remove this iteration? Any steps configured inside it will be deleted.')) return;
    this.stateService.removeIteration(this.orc, parentCallId);
    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
    this.updateTreeNodes();
  }

  getStepKindIcon(node: StudioTreeNode): string {
    if (node.step.iteration) return '↻';
    if (node.step.children?.steps?.length) return '⊕';
    if (node.nodeKind === 'iteration') return '↻';
    if (node.nodeKind === 'child') return '⤷';
    if (node.nodeKind === 'dependent') return '↪';
    return '◉';
  }

  getStepKindTitle(node: StudioTreeNode): string {
    if (node.step.iteration) return 'Iterating step';
    if (node.step.children?.steps?.length) return 'Has child steps';
    if (node.nodeKind === 'iteration') return 'Iteration child';
    if (node.nodeKind === 'child') return 'Child step';
    if (node.nodeKind === 'dependent') return 'Follow-up step';
    return 'Root step';
  }

  openOrcSettings(): void {
    this.flyoutService.open('orc-settings', { id: this.orc?.id });
  }

  downloadFlow(): void {
    if (!this.orc) return;
    const stripped = {
      id: this.orc.id,
      orchestrationId: this.orc.orchestrationId,
      name: this.orc.name,
      description: this.orc.description,
      version: this.orc.version,
      steps: this.orc.steps || []
    };
    const profile = this.orc.requestData?.profile || { country: 'us', language: 'en', region: 'us', segment: 'cnsr', market: 'usa_market' };
    const variables = (this.orc.variables && typeof this.orc.variables === 'object') ? this.orc.variables : {};
    const payload = { orchestration: stripped, requestData: { ...variables, profile } };
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const safeName = (this.orc.name || this.orc.id || 'orchestration')
      .toString()
      .trim()
      .replace(/[^a-z0-9-_]+/gi, '-')
      .replace(/^-+|-+$/g, '') || 'orchestration';
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeName}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Input mapping
  getStepInputRows(step: any): { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] {
    const rows: { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] = [];
    const seen = new Set<string>();

    // 1. URL path params
    this.extractUrlPathParams(step?.endpoint || '').forEach(name => {
      rows.push({ name, type: 'string', required: true, custom: false, paramIn: 'path' });
      seen.add(name);
    });

    // 2. Explicit step.inputs
    if (Array.isArray(step?.inputs)) {
      step.inputs.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || 'string', required: !!i.required, custom: false, paramIn: i.in || 'body' });
          seen.add(i.name);
        }
      });
    }

    // 3. API-definition inputs (check both api.inputs and api.inputMapping)
    const api = this.getApiForStep(step);
    if (api) {
      const apiInputs: any[] = Array.isArray(api.inputs) ? api.inputs
        : Array.isArray(api.inputMapping) ? api.inputMapping
        : [];
      apiInputs.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || '', required: !!i.required, custom: false, paramIn: i.in || 'query' });
          seen.add(i.name);
        }
      });
    }

    // 4. Extra custom inputMapping keys
    const map = step?.inputMapping || {};
    Object.keys(map).forEach(k => {
      if (!seen.has(k)) rows.push({ name: k, type: '', required: false, custom: true, paramIn: this.getMappingIn(map[k]) });
    });

    return rows.filter(r => r.paramIn !== 'query' && r.name !== 'profile');
  }

  getInputMappingChip(step: any, paramName: string): { icon: string; label: string; tag: string; isUnmapped: boolean } {
    if (!this.isInputMapped(step, paramName)) {
      return { icon: '＋', label: 'Connect a source…', tag: '', isUnmapped: true };
    }
    const raw = this.getMappingSourceExpr((step?.inputMapping || {})[paramName]);
    const draft = this.orc;
    const sources = draft ? this.availableDataService.getAvailableSources(draft, step.callId) : [];
    const expr = parseMappingExpr(raw, sources.filter(s => s.kind === 'step').map((s: any) => s.callId));

    if (expr.kind === 'flowInput') {
      return { icon: '⚡', label: `Flow input · ${expr.path || '(root)'}`, tag: 'flow', isUnmapped: false };
    }
    if (expr.kind === 'loopItem') {
      return { icon: '🔄', label: `Loop item · ${expr.path || '(root)'}`, tag: 'loop', isUnmapped: false };
    }
    if (expr.kind === 'stepOutput') {
      return { icon: '📤', label: `${expr.callId} · ${expr.path || '(root)'}`, tag: 'step', isUnmapped: false };
    }
    return { icon: '✎', label: `Literal · ${String(raw).substring(0, 20)}...`, tag: 'literal', isUnmapped: false };
  }

  private isInputMapped(step: any, paramName: string): boolean {
    const map = step?.inputMapping || {};
    if (!Object.prototype.hasOwnProperty.call(map, paramName)) return false;
    const v = map[paramName];
    const src = this.getMappingSourceExpr(v);
    return src !== '' && src !== undefined && src !== null;
  }

  clearInputMapping(callId: string, paramName: string): void {
    if (!this.orc) return;
    const step = this.stateService.getStepById(this.orc, callId);
    if (!step || !step.inputMapping) return;
    delete step.inputMapping[paramName];
    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
    this.inputEditState[paramName] = { sourceKey: '', field: '', loopProp: '', fixedText: '' };
  }

  // ---- Inline source binding (replaces source-picker flyout) ----

  /** Build the row state from an existing $source expression, using parseMappingExpr.
   *  Assumes this.rowSources is already populated for `step` (caller: initInputEditState). */
  private rowStateFromMapping(step: any, paramName: string): { sourceKey: string; field: string; loopProp: string; fixedText: string } {
    const empty = { sourceKey: '', field: '', loopProp: '', fixedText: '' };
    if (!step || !this.isInputMapped(step, paramName)) return empty;
    const raw = this.getMappingSourceExpr((step.inputMapping || {})[paramName]);
    const sources = this.rowSources;
    const expr = parseMappingExpr(raw, sources.filter(s => s.kind === 'step').map((s: any) => s.callId));
    if (expr.kind === 'flowInput') {
      return { sourceKey: 'flow', field: expr.path || '', loopProp: '', fixedText: '' };
    }
    if (expr.kind === 'loopItem') {
      // Pick the innermost loop owner whose itemVariable matches the expression's prefix, or fall back to the first.
      const loops = sources.filter(s => s.kind === 'loopItem');
      const owner = loops[0]; // getAvailableSources already lists innermost first
      return { sourceKey: owner ? `loop:${owner.ownerCallId}` : '', field: '', loopProp: expr.path || '', fixedText: '' };
    }
    if (expr.kind === 'stepOutput') {
      return { sourceKey: `step:${expr.callId}`, field: expr.path || '', loopProp: '', fixedText: '' };
    }
    // Literal (number, object, string-that-didn't-parse-as-an-expr)
    const text = (raw !== null && typeof raw === 'object') ? JSON.stringify(raw) : String(raw ?? '');
    return { sourceKey: 'fixed', field: '', loopProp: '', fixedText: text };
  }

  /** Rebuild inputEditState, the cached source lists, and the cached row list for the current
   *  selected step. Called whenever selectedStep changes; never inside a template binding. */
  private initInputEditState(): void {
    this.inputEditState = {};
    this.rowSources = [];
    this.loopSources = [];
    this.stepSources = [];
    this.flowSource = null;
    this.sourceByKey = {};
    this.inputRowsForSelected = [];
    if (!this.selectedStep || !this.orc) return;

    this.rowSources = this.availableDataService.getAvailableSources(this.orc, this.selectedStep.callId);
    for (const s of this.rowSources) {
      if (s.kind === 'flowInput') {
        this.flowSource = s;
        this.sourceByKey['flow'] = s;
      } else if (s.kind === 'loopItem') {
        this.loopSources.push(s);
        this.sourceByKey[`loop:${s.ownerCallId}`] = s;
      } else if (s.kind === 'step') {
        this.stepSources.push(s);
        this.sourceByKey[`step:${s.callId}`] = s;
      }
    }

    this.inputRowsForSelected = this.getStepInputRows(this.selectedStep);
    this.inputRowsForSelected.forEach(r => {
      this.inputEditState[r.name] = this.rowStateFromMapping(this.selectedStep, r.name);
    });
  }

  onInputSourceKeyChange(paramName: string, newKey: string): void {
    const state = this.inputEditState[paramName] || { sourceKey: '', field: '', loopProp: '', fixedText: '' };
    state.sourceKey = newKey;
    state.field = '';
    state.loopProp = '';
    state.fixedText = '';
    this.inputEditState[paramName] = state;
    if (!newKey) {
      // No source selected — drop any existing mapping.
      if (this.selectedStep) this.clearInputMapping(this.selectedStep.callId, paramName);
      return;
    }
    // Don't write anything until the user supplies the secondary value.
  }

  onInputValueChange(paramName: string): void {
    if (!this.orc || !this.selectedStep) return;
    const state = this.inputEditState[paramName];
    if (!state) return;
    const rows = this.getStepInputRows(this.selectedStep);
    const row = rows.find(r => r.name === paramName);
    const paramIn = row?.paramIn || 'body';
    const source = this.sourceByKey[state.sourceKey] || null;

    let sourceVal: any;
    if (state.sourceKey === 'flow') {
      if (!state.field) return; // wait until user picks a field
      sourceVal = `$request.${state.field}`;
    } else if (state.sourceKey.startsWith('loop:')) {
      if (!source) return;
      const itemVar = source.itemVariable || 'item';
      const prop = (state.loopProp || '').trim();
      sourceVal = prop ? `$${itemVar}.${prop}` : `$${itemVar}`;
    } else if (state.sourceKey.startsWith('step:')) {
      if (!source || !state.field) return;
      sourceVal = `$${source.callId}.${state.field}`;
    } else if (state.sourceKey === 'fixed') {
      const raw = state.fixedText;
      const trimmed = raw.trim();
      sourceVal = raw;
      if (trimmed !== '') {
        try { sourceVal = JSON.parse(trimmed); } catch { sourceVal = raw; }
      }
    } else {
      return;
    }

    const step = this.stateService.getStepById(this.orc, this.selectedStep.callId);
    if (!step) return;
    if (!step.inputMapping) step.inputMapping = {};
    step.inputMapping[paramName] = { $source: sourceVal, $in: paramIn };
    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
  }

  addCustomInput(): void {
    if (!this.selectedStep) return;
    this.flyoutService.open('add-custom-input', { callId: this.selectedStep.callId });
  }

  editSelectedStep(): void {
    if (!this.selectedStep) return;
    this.flyoutService.open('step-edit', { callId: this.selectedStep.callId });
  }

  deleteSelectedStep(): void {
    if (!this.selectedStep || !this.orc) return;
    if (!confirm(`Remove step "${this.selectedStep.callId}"? Any steps that depend on it will lose this dependency.`)) return;
    this.stateService.removeStep(this.orc, this.selectedStep.callId);
    this.stateService.setBuilderDraft(this.orc);
    this.stateService.saveOrchestration(this.orc);
    this.selectedStep = null;
    this.selectedStepApi = null;
    this.updateTreeNodes();
  }

  getMappedInputCount(step: any): number {
    return this.getStepInputRows(step).filter(r => this.isInputMapped(step, r.name)).length;
  }

  getTotalInputCount(step: any): number {
    return this.getStepInputRows(step).length;
  }

  // Field selection
  isFieldSelected(name: string): boolean {
    return (this.selectedStep?.fields || []).includes(name);
  }

  toggleField(name: string): void {
    if (!this.selectedStep) return;
    const fields = this.selectedStep.fields || [];
    const idx = fields.indexOf(name);
    if (idx >= 0) {
      fields.splice(idx, 1);
    } else {
      fields.push(name);
    }
    this.selectedStep.fields = fields;
    this.stateService.updateStep(this.orc, this.selectedStep.callId, { fields });
    this.stateService.saveOrchestration(this.orc);
    this.stateService.setBuilderDraft(this.orc);
  }

  toggleAllFields(): void {
    if (!this.selectedStep) return;
    const rawFields = this.selectedStepApi?.outputs || this.selectedStepApi?.fields
      || this.selectedStep?.outputs || [];
    const allFieldNames = rawFields.map((f: any) => typeof f === 'string' ? f : f.name);
    const hasAll = allFieldNames.every((name: string) => this.isFieldSelected(name));
    this.selectedStep.fields = hasAll ? [] : allFieldNames;
    this.stateService.updateStep(this.orc, this.selectedStep.callId, { fields: this.selectedStep.fields });
    this.stateService.saveOrchestration(this.orc);
    this.stateService.setBuilderDraft(this.orc);
  }

  saveRequest(): void {
    this.stateService.saveOrchestration(this.orc);
  }

  initTestTab(): void {
    const draft = this.orc;
    if (!draft) return;
    const stripped = {
      id: draft.id,
      orchestrationId: draft.orchestrationId,
      name: draft.name,
      description: draft.description,
      version: draft.version,
      steps: draft.steps || []
    };
    const defaultProfile = { country: 'us', language: 'en', region: 'us', segment: 'cnsr', market: 'usa_market' };
    const profile = draft.requestData?.profile
      ? { ...defaultProfile, ...draft.requestData.profile }
      : defaultProfile;
    const variables = (draft.variables && typeof draft.variables === 'object') ? draft.variables : {};
    const requestBody = { orchestration: stripped, requestData: { ...variables, profile } };
    this.testRequestJson = JSON.stringify(requestBody, null, 2);
    this.testRequestJsonError = '';
  }

  onTestRequestInput(val: string): void {
    try {
      JSON.parse(val);
      this.testRequestJsonError = '';
    } catch (e: any) {
      this.testRequestJsonError = e.message;
    }
  }

  sendTestRequest(): void {
    let parsedBody: any;
    try {
      parsedBody = JSON.parse(this.testRequestJson);
    } catch (e: any) {
      this.testStatusCode = 400;
      this.testResponseJson = JSON.stringify({ error: 'Invalid request JSON', detail: e.message }, null, 2);
      return;
    }

    this.isTesting = true;
    this.testResponseJson = '';
    this.testStatusCode = null;

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.http.post(this.testApiUrl, parsedBody, { headers, observe: 'response' })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.testStatusCode = response.status;
          this.testResponseJson = JSON.stringify(response.body, null, 2);
          this.isTesting = false;
        },
        error: (err: HttpErrorResponse) => {
          this.testStatusCode = err.status || 0;
          const body = err.error;
          if (body && typeof body === 'object') {
            this.testResponseJson = JSON.stringify(body, null, 2);
          } else if (typeof body === 'string') {
            try { this.testResponseJson = JSON.stringify(JSON.parse(body), null, 2); }
            catch { this.testResponseJson = JSON.stringify({ error: body || err.message }, null, 2); }
          } else {
            this.testResponseJson = JSON.stringify({ error: err.message || 'Request failed', status: err.status }, null, 2);
          }
          this.isTesting = false;
        }
      });
  }

  private extractUrlPathParams(endpoint: string): string[] {
    if (!endpoint) return [];
    const matches = endpoint.match(/\{([^}]+)\}/g);
    return matches ? matches.map(m => m.slice(1, -1)) : [];
  }

  private getMappingSourceExpr(val: any): any {
    if (val && typeof val === 'object' && '$source' in val) return val.$source;
    return val;
  }

  private getMappingIn(val: any): string {
    if (val && typeof val === 'object' && '$in' in val) return val.$in;
    return 'body';
  }

  private getApiForStep(step: any): any | null {
    if (!step) return null;
    if (step.apiId) {
      return this.stateService.getApiById(step.apiId) || null;
    }
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint) || null;
  }

  getFieldRows(): any[][][] {
    const rawFields = this.selectedStepApi?.outputs || this.selectedStepApi?.fields
      || this.selectedStep?.outputs || [];
    const fields = rawFields.map((f: any) =>
      typeof f === 'string' ? { name: f } : f
    );
    const fieldsPerColumn = 5;
    const columnsPerRow = 3;
    const fieldsPerRow = fieldsPerColumn * columnsPerRow;
    const rows: any[][][] = [];

    for (let i = 0; i < fields.length; i += fieldsPerRow) {
      const rowFields = fields.slice(i, i + fieldsPerRow);
      const columns: any[][] = [];

      for (let j = 0; j < rowFields.length; j += fieldsPerColumn) {
        columns.push(rowFields.slice(j, j + fieldsPerColumn));
      }

      rows.push(columns);
    }

    return rows;
  }
}
