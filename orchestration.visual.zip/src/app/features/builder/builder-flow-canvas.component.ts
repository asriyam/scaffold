import {
  Component, Input, OnChanges, AfterViewInit, ViewChild,
  ElementRef, SimpleChanges
} from '@angular/core';

interface GraphNode { id: string; step: any; depth: number; kind: string; }
interface GraphEdge { from: string; to: string; kind: string; }
interface Graph { nodes: GraphNode[]; edges: GraphEdge[]; nodesByDepth: Record<number, string[]>; }
interface Layout { width: number; height: number; nodeWidth: number; nodeHeight: number; }

@Component({
  selector: 'app-builder-flow-canvas',
  template: `
    <div class="flow-canvas" #hostDiv>
      <canvas #flowCanvas style="display:block; cursor:default;"></canvas>
    </div>
    <div *ngIf="isEmpty" style="text-align:center; padding:40px; color:var(--text-secondary);">
      No steps to visualize yet. Add APIs in the Visual tab.
    </div>
  `,
  styles: [`:host { display:block; } .flow-canvas { overflow:auto; }`]
})
export class BuilderFlowCanvasComponent implements AfterViewInit, OnChanges {
  @Input() orchestration: any = null;
  @ViewChild('hostDiv') hostDiv!: ElementRef<HTMLDivElement>;
  @ViewChild('flowCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  isEmpty = true;

  private readonly NODE_W = 160;
  private readonly NODE_H = 40;
  private readonly MARGIN_X = 80;
  private readonly MARGIN_Y = 40;
  private readonly H_SPACING = 220;
  private readonly V_SPACING = 80;

  private graph: Graph = { nodes: [], edges: [], nodesByDepth: {} };
  private positions: Record<string, { x: number; y: number }> = {};
  private layout: Layout = { width: 800, height: 400, nodeWidth: this.NODE_W, nodeHeight: this.NODE_H };

  constructor() {}

  ngAfterViewInit(): void { this.render(); }

  ngOnChanges(_changes: SimpleChanges): void {
    if (this.canvasRef) this.render();
  }

  render(): void {
    const orc = this.orchestration;
    if (!orc || !Array.isArray(orc.steps) || orc.steps.length === 0) {
      this.isEmpty = true;
      return;
    }
    this.isEmpty = false;

    this.graph = this.buildGraph(orc);
    if (!this.graph.nodes.length) { this.isEmpty = true; return; }

    setTimeout(() => this.setupCanvas(), 0);
  }

  private setupCanvas(): void {
    const canvas = this.canvasRef?.nativeElement;
    const host = this.hostDiv?.nativeElement;
    if (!canvas || !host) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const depthKeys = Object.keys(this.graph.nodesByDepth).map(Number).sort((a, b) => a - b);
    const maxDepth = depthKeys.length ? Math.max(...depthKeys) : 0;
    const maxPerDepth = depthKeys.length
      ? Math.max(...depthKeys.map(d => this.graph.nodesByDepth[d].length))
      : this.graph.nodes.length;

    const pixelRatio = window.devicePixelRatio || 1;
    const baseWidth = host.clientWidth || 800;
    const baseHeight = Math.max(400, this.MARGIN_Y * 2 + this.V_SPACING * Math.max(1, maxPerDepth));
    const width = Math.max(baseWidth, this.MARGIN_X * 2 + this.H_SPACING * (maxDepth + 1));
    const height = baseHeight;

    canvas.width = width * pixelRatio;
    canvas.height = height * pixelRatio;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);

    this.layout = { width, height, nodeWidth: this.NODE_W, nodeHeight: this.NODE_H };

    this.positions = {};
    depthKeys.forEach(depth => {
      const ids = this.graph.nodesByDepth[depth];
      if (!ids?.length) return;
      ids.forEach((id, index) => {
        this.positions[id] = {
          x: this.MARGIN_X + depth * this.H_SPACING,
          y: this.MARGIN_Y + index * this.V_SPACING
        };
      });
    });

    this.drawGraph(ctx);
    this.attachDragHandlers(canvas, ctx);
  }

  private drawGraph(ctx: CanvasRenderingContext2D): void {
    const { width, height, nodeWidth, nodeHeight } = this.layout;
    ctx.clearRect(0, 0, width, height);
    ctx.font = '12px "Roboto", "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Draw edges first
    this.graph.edges.forEach(edge => {
      const from = this.positions[edge.from];
      const to = this.positions[edge.to];
      if (!from || !to) return;

      const startX = from.x + nodeWidth / 2;
      const startY = from.y;
      const endX = to.x - nodeWidth / 2;
      const endY = to.y;

      ctx.strokeStyle = edge.kind === 'iteration' ? '#F5821F'
        : edge.kind === 'child' ? '#9C27B0'
        : edge.kind === 'dependency' ? '#0076CE' : '#999';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      const midX = (startX + endX) / 2;
      ctx.lineTo(midX, startY);
      ctx.lineTo(midX, endY);
      ctx.lineTo(endX, endY);
      ctx.stroke();

      // Arrowhead
      const angle = Math.atan2(endY - startY, endX - startX);
      const arrowLen = 8;
      const arrowAngle = Math.PI / 8;
      ctx.beginPath();
      ctx.moveTo(endX, endY);
      ctx.lineTo(endX - arrowLen * Math.cos(angle - arrowAngle), endY - arrowLen * Math.sin(angle - arrowAngle));
      ctx.lineTo(endX - arrowLen * Math.cos(angle + arrowAngle), endY - arrowLen * Math.sin(angle + arrowAngle));
      ctx.closePath();
      ctx.fillStyle = ctx.strokeStyle;
      ctx.fill();
    });

    // Draw nodes
    this.graph.nodes.forEach(node => {
      const pos = this.positions[node.id];
      if (!pos) return;
      const { x, y } = pos;
      const left = x - nodeWidth / 2;
      const top = y - nodeHeight / 2;
      const radius = 6;

      ctx.strokeStyle = node.kind === 'root' ? '#0076CE'
        : node.kind === 'iteration' ? '#F5821F'
        : node.kind === 'child' ? '#9C27B0' : '#555555';
      ctx.fillStyle = '#FFFFFF';
      ctx.lineWidth = 2;

      ctx.beginPath();
      ctx.moveTo(left + radius, top);
      ctx.lineTo(left + nodeWidth - radius, top);
      ctx.quadraticCurveTo(left + nodeWidth, top, left + nodeWidth, top + radius);
      ctx.lineTo(left + nodeWidth, top + nodeHeight - radius);
      ctx.quadraticCurveTo(left + nodeWidth, top + nodeHeight, left + nodeWidth - radius, top + nodeHeight);
      ctx.lineTo(left + radius, top + nodeHeight);
      ctx.quadraticCurveTo(left, top + nodeHeight, left, top + nodeHeight - radius);
      ctx.lineTo(left, top + radius);
      ctx.quadraticCurveTo(left, top, left + radius, top);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#333333';
      const label = this.buildLabel(node.step);
      const text = label.length > 26 ? label.slice(0, 25) + '…' : label;
      ctx.fillText(text, x, y);
    });
  }

  private attachDragHandlers(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D): void {
    let isDragging = false;
    let dragNodeId: string | null = null;
    let dragOffsetX = 0;
    let dragOffsetY = 0;
    const { nodeWidth, nodeHeight } = this.layout;

    const hitTest = (x: number, y: number): string | null => {
      for (const node of this.graph.nodes) {
        const pos = this.positions[node.id];
        if (!pos) continue;
        if (x >= pos.x - nodeWidth / 2 && x <= pos.x + nodeWidth / 2 &&
            y >= pos.y - nodeHeight / 2 && y <= pos.y + nodeHeight / 2) {
          return node.id;
        }
      }
      return null;
    };

    canvas.addEventListener('mousedown', (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const nodeId = hitTest(x, y);
      if (!nodeId) return;
      isDragging = true;
      dragNodeId = nodeId;
      canvas.style.cursor = 'grabbing';
      const pos = this.positions[nodeId];
      dragOffsetX = x - pos.x;
      dragOffsetY = y - pos.y;
    });

    canvas.addEventListener('mousemove', (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      if (!isDragging || !dragNodeId) {
        canvas.style.cursor = hitTest(x, y) ? 'grab' : 'default';
        return;
      }
      const { width, height } = this.layout;
      this.positions[dragNodeId] = {
        x: Math.max(nodeWidth / 2, Math.min(width - nodeWidth / 2, x - dragOffsetX)),
        y: Math.max(nodeHeight / 2, Math.min(height - nodeHeight / 2, y - dragOffsetY))
      };
      this.drawGraph(ctx);
    });

    const stopDrag = () => {
      isDragging = false;
      dragNodeId = null;
      canvas.style.cursor = 'default';
    };
    canvas.addEventListener('mouseup', stopDrag);
    canvas.addEventListener('mouseleave', stopDrag);
  }

  private buildGraph(orc: any): Graph {
    const rootSteps: any[] = Array.isArray(orc.steps) ? orc.steps : [];
    const nodes: GraphNode[] = [];
    const edges: GraphEdge[] = [];
    const nodesByDepth: Record<number, string[]> = {};
    const depth: Record<string, number> = {};
    const nodeKind: Record<string, string> = {};
    const stepMap: Record<string, any> = {};

    // Collect ALL steps (root + nested iteration/children) into a flat list
    const allSteps: any[] = [];
    this.collectAllSteps(rootSteps, allSteps, stepMap);

    // Assign initial depths for root-level steps via flat dependency BFS
    rootSteps.forEach(s => {
      if (!s.callId) return;
      const deps = s.dependencies;
      nodeKind[s.callId] = Array.isArray(deps) && deps.length > 0 ? 'child' : 'root';
      if (!Array.isArray(deps) || !deps.length) depth[s.callId] = 0;
    });

    let changed = true;
    while (changed) {
      changed = false;
      rootSteps.forEach(s => {
        if (!s.callId || !Array.isArray(s.dependencies) || !s.dependencies.length) return;
        const validDeps = s.dependencies.filter((d: string) => d in depth);
        if (!validDeps.length) { if (!(s.callId in depth)) { depth[s.callId] = 0; changed = true; } return; }
        const nd = Math.max(...validDeps.map((d: string) => depth[d])) + 1;
        if ((depth[s.callId] ?? -1) < nd) { depth[s.callId] = nd; changed = true; }
      });
    }

    // Flat dependency edges (root-level steps only)
    rootSteps.forEach(s => {
      (s.dependencies || []).forEach((dep: string) => {
        if (stepMap[dep]) edges.push({ from: dep, to: s.callId, kind: 'dependency' });
      });
    });

    // Assign depths and create edges for nested iteration/children steps recursively
    const assignNested = (steps: any[], parentCallId: string, kind: 'iteration' | 'child') => {
      const pd = depth[parentCallId] ?? 0;
      steps.forEach(child => {
        if (!child.callId) return;
        depth[child.callId] = pd + 1;
        nodeKind[child.callId] = kind;
        edges.push({ from: parentCallId, to: child.callId, kind });
        if (child.iteration?.steps?.length) assignNested(child.iteration.steps, child.callId, 'iteration');
        if (child.children?.steps?.length) assignNested(child.children.steps, child.callId, 'child');
      });
    };

    rootSteps.forEach(s => {
      if (s.iteration?.steps?.length) assignNested(s.iteration.steps, s.callId, 'iteration');
      if (s.children?.steps?.length) assignNested(s.children.steps, s.callId, 'child');
    });

    // Build nodes for every collected step
    allSteps.forEach(s => {
      if (!s.callId) return;
      const d = depth[s.callId] ?? 0;
      const kind = nodeKind[s.callId] || 'root';
      nodes.push({ id: s.callId, step: s, depth: d, kind });
      if (!nodesByDepth[d]) nodesByDepth[d] = [];
      nodesByDepth[d].push(s.callId);
    });

    return { nodes, edges, nodesByDepth };
  }

  private collectAllSteps(steps: any[], result: any[], stepMap: Record<string, any>): void {
    for (const s of steps) {
      if (s.callId) { result.push(s); stepMap[s.callId] = s; }
      if (s.iteration?.steps) this.collectAllSteps(s.iteration.steps, result, stepMap);
      if (s.children?.steps) this.collectAllSteps(s.children.steps, result, stepMap);
    }
  }

  private buildLabel(step: any): string {
    const base = step?.callId || step?.apiId || 'Step';
    const detail = step?.endpoint || step?.method || '';
    return detail ? `${base} – ${detail}` : base;
  }
}
