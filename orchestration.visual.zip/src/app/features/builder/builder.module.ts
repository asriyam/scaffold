import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@shared/shared.module';
import { BuilderComponent } from './builder.component';
import { BuilderFlowCanvasComponent } from './builder-flow-canvas.component';

@NgModule({
  declarations: [BuilderComponent, BuilderFlowCanvasComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([
      { path: '', redirectTo: 'new', pathMatch: 'full' },
      { path: 'new', component: BuilderComponent },
      { path: 'cs/:itemId', component: BuilderComponent },
      { path: ':id/edit', component: BuilderComponent }
    ])
  ],
  exports: [BuilderFlowCanvasComponent]
})
export class BuilderModule { }
