import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';

@Component({
  selector: 'app-builder',
  templateUrl: './builder.component.html',
  styleUrls: ['./builder.component.scss']
})
export class BuilderComponent implements OnInit, OnDestroy {
  orc: any = null;
  item: any = null;
  activeTab: 'build' | 'test' = 'build';
  buildView: 'visual' | 'flow' | 'json' = 'visual';
  expandedFieldsSet = new Set<string>();
  isSaving = false;
  jsonDraft = '';
  jsonError = '';
  isJsonDirty = false;

  // ---- Content Studio state ----
  loading = false;
  errorMessage = '';

  // ---- Test tab state ----
  testApiUrl = '';
  testRequestJson = '';
  testResponseJson = '';
  testStatusCode: number | null = null;
  isTesting = false;
  testResponseExpanded = false;
  testRequestJsonError = '';

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService,
    private flyoutService: FlyoutService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.route.paramMap.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const itemId = params.get('itemId');
      const id = params.get('id');

      if (itemId) {
        const qp = this.route.snapshot.queryParamMap;
        const collectionId = qp.get('collectionId') || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
        const contentType = qp.get('contentType') || 'UnifiedOrchestration';
        this.fetchFromContentStudio(itemId, collectionId, contentType);
      } else if (id) {
        const existing = this.stateService.getOrchestrationById(id);
        if (existing) {
          this.orc = JSON.parse(JSON.stringify(existing));
          this.stateService.setBuilderDraft(this.orc);
        } else {
          this.router.navigate(['/orchestrations']);
        }
      } else {
        const draft = this.stateService.getBuilderDraft();
        if (draft) {
          this.orc = { ...draft };
        } else {
          this.orc = this.stateService.createBlankOrchestration();
          this.stateService.setBuilderDraft(this.orc);
        }
      }
    });

    // Auto-sync when flyout closes (step was added/modified)
    this.flyoutService.isOpen$.pipe(
      takeUntil(this.destroy$),
      pairwise(),
      filter(([prev, curr]) => prev === true && curr === false)
    ).subscribe(() => this.syncFromDraft());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      this.save(false);
    }
  }

  // ---- Header data ----

  get orcName(): string { return this.orc?.name || 'Untitled Orchestration'; }
  get orcVersion(): string { return this.orc?.version ? 'v' + this.orc.version : 'v1.0.0'; }
  onNameBlur(event: Event): void {
    const text = (event.target as HTMLElement).textContent?.trim() || 'Untitled Orchestration';
    const draft = this.stateService.getBuilderDraft();
    if (draft) { draft.name = text; this.stateService.setBuilderDraft(draft); }
    if (this.orc) this.orc.name = text;
  }

  // ---- Steps / canvas data ----

  getSteps(): any[] {
    const draft = this.stateService.getBuilderDraft();
    return draft?.steps || this.orc?.steps || [];
  }

  get hasSteps(): boolean { return this.getSteps().length > 0; }

  get jsonView(): string {
    const draft = this.stateService.getBuilderDraft();
    return JSON.stringify(draft || this.orc || {}, null, 2);
  }

  setTab(tab: 'build' | 'test'): void {
    this.activeTab = tab;
    if (tab === 'test' && !this.testRequestJson) {
      this.initTestTab();
    }
  }

  setBuildView(view: 'visual' | 'flow' | 'json'): void {
    this.buildView = view;
    if (view === 'json') {
      this.jsonDraft = this.jsonView;
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  onJsonInput(value: string): void {
    this.jsonDraft = value;
    this.isJsonDirty = true;
    try {
      JSON.parse(value);
      this.jsonError = '';
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  applyJson(): void {
    if (this.jsonError) return;
    try {
      const parsed = JSON.parse(this.jsonDraft);
      this.stateService.setBuilderDraft(parsed);
      this.orc = JSON.parse(JSON.stringify(parsed));
      this.isJsonDirty = false;
      this.showToast('JSON applied — Visual and Flow tabs updated');
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  resetJson(): void {
    this.jsonDraft = this.jsonView;
    this.jsonError = '';
    this.isJsonDirty = false;
  }

  syncFromDraft(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.orc = JSON.parse(JSON.stringify(draft));
    if (this.buildView === 'json') {
      this.jsonDraft = JSON.stringify(draft, null, 2);
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  // ---- Content Studio fetch ----

  fetchFromContentStudio(itemId: string, collectionId: string, contentType: string): void {
    this.loading = true;
    this.errorMessage = '';
    const url = `https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/GetItem`
      + `?collectionId=${encodeURIComponent(collectionId)}`
      + `&contentType=${encodeURIComponent(contentType)}`
      + `&itemId=${encodeURIComponent(itemId)}`;

    this.http.get<any>(url).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        this.item = res;
        let orchContent = res?.DynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.orchestrationContent
          || res?.dynamicProperties?.OrchestrationContent
          || res?.DynamicProperties?.orchestrationContent;
        if (typeof orchContent === 'string') {
          try { orchContent = JSON.parse(orchContent); } catch (_) {}
        }
        this.orc = orchContent ?? {};
        this.stateService.setBuilderDraft(this.orc);
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = err?.message || 'Failed to load orchestration from Content Studio';
        this.loading = false;
      }
    });
  }

  // ---- Header actions (matching orcstudio builder.js) ----

  addRootApi(): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'root' });
  }

  openSettings(): void {
    this.flyoutService.open('orc-settings', {});
  }

  openOutput(): void {
    this.flyoutService.open('orc-output', {});
  }

  openInputMapping(callId: string): void {
    this.flyoutService.open('step-input-mapping', { callId });
  }

  openResponseMapping(callId: string): void {
    this.flyoutService.open('step-response-mapping', { callId });
  }

  addDependentStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'dependent', parentCallId });
  }

  addChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'direct-child', parentCallId });
  }

  setIterateStep(callId: string): void {
    this.flyoutService.open('iteration-configure', { callId });
  }

  addIterationChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'iteration-child', parentCallId });
  }

  save(goBack = false): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;

    // If we have an original API item, save via SaveInDraft API
    if (this.item) {
      this.isSaving = true;
      const orchContentStr = JSON.stringify(draft, null, 2);
      const origItem = this.item;
      const collectionId = origItem.CollectionId || origItem.collectionId
        || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';

      const itemToSave: any = JSON.parse(JSON.stringify(origItem));
      if (!itemToSave.DynamicProperties) {
        itemToSave.DynamicProperties = {};
      }
      itemToSave.DynamicProperties.OrchestrationContent = orchContentStr;

      const itemId = origItem.Id || origItem.id || '';
      const payload = {
        SaveItemRequest: {
          CollectionId: collectionId,
          CollectionIndexType: 0,
          CollectionType: 0,
          ConfigJson: {},
          DynamicDataValidationUrl: '',
          Item: itemToSave,
          ItemId: itemId,
          RelatedCollectionDetails: {},
          Comments: origItem.Comments || null,
          SchedulingStartDate: origItem.ScheduleStartDate || '1900-12-30T18:38:50.000Z',
          SchedulingEndDate: origItem.ScheduleEndDate || '9999-12-30T18:30:00.000Z'
        }
      };

      const url = 'https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/SaveInDraft';
      console.log('Saving to SaveInDraft:', url, payload);

      this.http.post<any>(url, payload).subscribe({
        next: (res) => {
          console.log('SaveInDraft response:', res);
          this.orc = JSON.parse(JSON.stringify(draft));
          this.stateService.setBuilderDraft(this.orc);
          this.isSaving = false;
          this.showToast('Orchestration saved successfully');
          if (goBack) this.router.navigate(['/orchestrations']);
        },
        error: (err) => {
          console.error('SaveInDraft failed:', err);
          this.isSaving = false;
          const errMsg = err?.error?.message || err?.message || 'Save failed. Please try again.';
          this.showToast('Error: ' + errMsg);
        }
      });
    } else {
      // Local-only save (no API item loaded)
      if (!draft.name?.trim()) { alert('Please enter an orchestration name'); return; }
      draft.version = this.stateService.bumpVersion(draft.version || '1.0.0');
      draft.updatedAt = new Date().toISOString();
      this.stateService.saveOrchestration(draft);
      this.stateService.setBuilderDraft(draft);
      this.orc = JSON.parse(JSON.stringify(draft));
      this.isSaving = true;
      setTimeout(() => { this.isSaving = false; }, 600);
      this.showToast('Orchestration saved locally');
      if (goBack) this.router.navigate(['/orchestrations']);
    }
  }

  exportJson(): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;
    const json = JSON.stringify(draft, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = (draft.name || 'orchestration').replace(/[^a-z0-9\-_]+/gi, '-');
    a.href = url; a.download = safeName + '.json';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }

  goBack(): void { this.router.navigate(['/orchestrations']); }

  // ---- Step card actions (matching builder-visual.js) ----

  editStepFields(callId: string): void {
    this.flyoutService.open('step-fields', { callId });
  }

  removeField(callId: string, fieldName: string): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const step = this.findStepByCallId(draft, callId);
    if (step && Array.isArray(step.fields)) {
      step.fields = step.fields.filter((f: string) => f !== fieldName);
      this.stateService.setBuilderDraft(draft);
      this.orc = JSON.parse(JSON.stringify(draft));
    }
  }

  private findStepByCallId(item: any, callId: string): any {
    if (item.callId === callId) return item;
    if (Array.isArray(item.steps)) {
      for (const step of item.steps) {
        const found = this.findStepByCallId(step, callId);
        if (found) return found;
      }
    }
    if (item.children?.steps) {
      for (const child of item.children.steps) {
        const found = this.findStepByCallId(child, callId);
        if (found) return found;
      }
    }
    if (item.iteration?.steps) {
      for (const iterChild of item.iteration.steps) {
        const found = this.findStepByCallId(iterChild, callId);
        if (found) return found;
      }
    }
    return null;
  }

  configureStep(callId: string): void {
    this.flyoutService.open('step-configure', { callId });
  }

  removeStep(callId: string): void {
    if (!confirm(`Remove step "${callId}"? Any steps that depend on it will lose this dependency.`)) return;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.stateService.removeStep(draft, callId);
    this.stateService.setBuilderDraft(draft);
    this.orc = JSON.parse(JSON.stringify(draft));
  }

  getStepDependencies(step: any): string[] {
    return Array.isArray(step?.dependencies) ? step.dependencies : [];
  }

  getInputMappingCount(step: any): number {
    return Object.keys(step?.inputMapping || {}).length;
  }

  getResponseMappingCount(step: any): number {
    return Object.keys(step?.responseMapping || {}).length;
  }

  // ---- Test tab methods ----

  initTestTab(): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;
    const orcId = (draft.orchestrationId || draft.id || 'my-orchestration').trim();
    this.testApiUrl = `https://orchestrationapi.studiod-r3-np.kob.dell.com/api/orchestration/${orcId}/execute`;
    this.testRequestJson = this.buildTestRequestJson(draft);
  }

  buildTestRequestJson(draft: any): string {
    const params: Record<string, any> = {};
    if (draft.variables && typeof draft.variables === 'object') {
      Object.keys(draft.variables).forEach(k => { params[k] = (draft.variables[k] ?? ''); });
    }
    const collectFromSteps = (steps: any[]) => {
      if (!Array.isArray(steps)) return;
      steps.forEach(step => {
        if (step.inputMapping && typeof step.inputMapping === 'object') {
          Object.values(step.inputMapping).forEach((val: any) => {
            if (typeof val === 'string' && val.startsWith('$input.')) {
              const key = val.replace('$input.', '');
              if (!(key in params)) params[key] = '';
            }
          });
        }
        if (step.iteration?.steps) collectFromSteps(step.iteration.steps);
        if (step.children?.steps) collectFromSteps(step.children.steps);
      });
    };
    collectFromSteps(draft.steps || []);
    return JSON.stringify({
      requestId: `test-${Date.now()}`,
      context: { ...(draft.context || {}) },
      parameters: Object.keys(params).length > 0 ? params : { exampleParam: 'value' }
    }, null, 2);
  }

  buildMockResponse(draft: any): string {
    const output: Record<string, any> = {};
    const collectOutput = (steps: any[]) => {
      if (!Array.isArray(steps)) return;
      steps.forEach(step => {
        if (!step.callId) return;
        const stepOut: Record<string, any> = {};
        if (step.responseMapping && typeof step.responseMapping === 'object') {
          Object.keys(step.responseMapping).forEach(k => { stepOut[k] = `<${k}>`; });
        }
        if (Array.isArray(step.fields)) {
          step.fields.forEach((f: string) => { if (!(f in stepOut)) stepOut[f] = `<${f}>`; });
        }
        if (Object.keys(stepOut).length > 0) output[step.callId] = stepOut;
        if (step.iteration?.steps) collectOutput(step.iteration.steps);
        if (step.children?.steps) collectOutput(step.children.steps);
      });
    };
    collectOutput(draft?.steps || []);
    return JSON.stringify({
      requestId: `test-${Date.now()}`,
      status: 'SUCCESS',
      orchestrationId: draft?.orchestrationId || draft?.id || '',
      executedAt: new Date().toISOString(),
      durationMs: Math.floor(Math.random() * 270) + 80,
      output: Object.keys(output).length > 0 ? output : { result: 'OK' }
    }, null, 2);
  }

  sendTestRequest(): void {
    let parsedBody: any;
    try {
      parsedBody = JSON.parse(this.testRequestJson);
    } catch (e: any) {
      this.testStatusCode = 400;
      this.testResponseJson = JSON.stringify({ error: 'Invalid request JSON', detail: e.message }, null, 2);
      return;
    }

    this.isTesting = true;
    this.testResponseJson = '';
    this.testStatusCode = null;

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.http.post(this.testApiUrl, parsedBody, { headers, observe: 'response' })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.testStatusCode = response.status;
          this.testResponseJson = JSON.stringify(response.body, null, 2);
          this.isTesting = false;
        },
        error: (err: HttpErrorResponse) => {
          this.testStatusCode = err.status || 0;
          const body = err.error;
          if (body && typeof body === 'object') {
            this.testResponseJson = JSON.stringify(body, null, 2);
          } else if (typeof body === 'string') {
            try { this.testResponseJson = JSON.stringify(JSON.parse(body), null, 2); }
            catch { this.testResponseJson = JSON.stringify({ error: body || err.message }, null, 2); }
          } else {
            this.testResponseJson = JSON.stringify({ error: err.message || 'Request failed', status: err.status }, null, 2);
          }
          this.isTesting = false;
        }
      });
  }

  onTestRequestInput(value: string): void {
    this.testRequestJson = value;
    try {
      JSON.parse(value);
      this.testRequestJsonError = '';
    } catch (e: any) {
      this.testRequestJsonError = e.message || 'Invalid JSON';
    }
  }

  toggleResponseExpand(): void {
    this.testResponseExpanded = !this.testResponseExpanded;
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  trackByCallId(_: number, step: any): string { return step.callId; }

  methodLabel(method: string): string {
    const map: Record<string, string> = {
      GET: 'Reads', POST: 'Creates', PUT: 'Updates', DELETE: 'Removes'
    };
    return map[(method || 'GET').toUpperCase()] || (method || 'GET');
  }

  toggleFields(callId: string): void {
    if (this.expandedFieldsSet.has(callId)) {
      this.expandedFieldsSet.delete(callId);
    } else {
      this.expandedFieldsSet.add(callId);
    }
  }

  isFieldsExpanded(callId: string): boolean {
    return this.expandedFieldsSet.has(callId);
  }
}
