import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { FlyoutService } from '@core/services/flyout.service';
import { AvailableDataService, AvailableSource } from '@core/services/available-data.service';
import { parseMappingExpr, formatSampleValueForDisplay } from '@core/services/mapping-expr';
import { MOCK_ORCHESTRATIONS } from '@core/mockdata';

@Component({
  selector: 'app-builder',
  templateUrl: './builder.component.html',
  styleUrls: ['./builder.component.scss']
})
export class BuilderComponent implements OnInit, OnDestroy {
  orc: any = null;
  item: any = null;
  activeTab: 'build' | 'test' = 'build';
  buildView: 'visual' | 'flow' | 'json' = 'visual';
  expandedFieldsSet = new Set<string>();
  collapsedStepsSet = new Set<string>();
  isSaving = false;
  jsonDraft = '';
  jsonError = '';
  isJsonDirty = false;

  // ---- Content Studio state ----
  loading = false;
  errorMessage = '';
  isMockData = false;

  // ---- CMS API list (for resolving inputMapping on imported APIs) ----
  cmsApiList: any[] = [];

  // ---- Test tab state ----
  testApiUrl = '';
  testRequestJson = '';
  testResponseJson = '';
  testStatusCode: number | null = null;
  isTesting = false;
  testResponseExpanded = false;
  testRequestExpanded = false;
  testRequestJsonError = '';

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private stateService: StateService,
    private flyoutService: FlyoutService,
    private availableDataService: AvailableDataService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.route.paramMap.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const itemId = params.get('itemId');
      const id = params.get('id');

      if (itemId) {
        const qp = this.route.snapshot.queryParamMap;
        const collectionId = qp.get('collectionId') || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
        const contentType = qp.get('contentType') || 'UnifiedOrchestration';
        if (qp.get('mock') === 'true') {
          this.loadFromMockData(itemId);
        } else {
          this.fetchFromContentStudio(itemId, collectionId, contentType);
        }
      } else if (id) {
        const existing = this.stateService.getOrchestrationById(id);
        if (existing) {
          this.stateService.setBuilderDraft(existing);
          this.orc = this.stateService.getBuilderDraft()!;
        } else {
          this.router.navigate(['/orchestrations']);
        }
      } else {
        const draft = this.stateService.getBuilderDraft();
        if (draft) {
          this.orc = { ...draft };
        } else {
          this.orc = this.stateService.createBlankOrchestration();
          this.stateService.setBuilderDraft(this.orc);
        }
      }
    });

    this.fetchCmsApiList();

    // Auto-sync when flyout closes (step was added/modified)
    this.flyoutService.isOpen$.pipe(
      takeUntil(this.destroy$),
      pairwise(),
      filter(([prev, curr]) => prev === true && curr === false)
    ).subscribe(() => this.syncFromDraft());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent): void {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      this.save(false);
    }
  }

  // ---- Header data ----

  get orcName(): string { return this.orc?.name || 'Untitled Orchestration'; }
  get orcVersion(): string { return this.orc?.version ? 'v' + this.orc.version : 'v1.0.0'; }
  onNameBlur(event: Event): void {
    const text = (event.target as HTMLElement).textContent?.trim() || 'Untitled Orchestration';
    const draft = this.stateService.getBuilderDraft();
    if (draft) { 
      draft.name = text; 
      draft.id = text;
      draft.orchestrationId = text;
      this.stateService.setBuilderDraft(draft); 
    }
    if (this.orc) {
      this.orc.name = text;
      this.orc.id = text;
      this.orc.orchestrationId = text;
    }
  }

  // ---- Steps / canvas data ----

  getSteps(): any[] {
    const draft = this.stateService.getBuilderDraft();
    return draft?.steps || this.orc?.steps || [];
  }

  get hasSteps(): boolean { return this.getSteps().length > 0; }

  get jsonView(): string {
    const draft = this.stateService.getBuilderDraft();
    return JSON.stringify(draft || this.orc || {}, null, 2);
  }

  setTab(tab: 'build' | 'test'): void {
    this.activeTab = tab;
    if (tab === 'test') {
      this.initTestTab();
    }
  }

  setBuildView(view: 'visual' | 'flow' | 'json'): void {
    this.buildView = view;
    if (view === 'json') {
      this.jsonDraft = this.jsonView;
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  onJsonInput(value: string): void {
    this.jsonDraft = value;
    this.isJsonDirty = true;
    try {
      JSON.parse(value);
      this.jsonError = '';
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  applyJson(): void {
    if (this.jsonError) return;
    try {
      const parsed = JSON.parse(this.jsonDraft);
      this.stateService.setBuilderDraft(parsed);
      this.orc = this.stateService.getBuilderDraft()!;
      this.isJsonDirty = false;
      this.showToast('JSON applied — Visual and Flow tabs updated');
    } catch (e: any) {
      this.jsonError = e.message || 'Invalid JSON';
    }
  }

  resetJson(): void {
    this.jsonDraft = this.jsonView;
    this.jsonError = '';
    this.isJsonDirty = false;
  }

  syncFromDraft(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.orc = JSON.parse(JSON.stringify(draft));
    if (this.buildView === 'json') {
      this.jsonDraft = JSON.stringify(draft, null, 2);
      this.jsonError = '';
      this.isJsonDirty = false;
    }
  }

  // ---- CMS API list fetch ----

  fetchCmsApiList(): void {
    const url = 'https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemReaderApi/GetItems?findMissingItems=false';
    const payload = {
      sourceFields: ['Id', 'Key', 'Name', 'DynamicProperties'],
      size: 100,
      blockNumber: 1,
      searchText: '',
      collectionIndexType: 0,
      sortOptions: [{ fieldName: 'Modified', SortDirection: 1 }],
      appliedFilters: [],
      advancedFilter: { filterParts: [] },
      collectionId: 'd10aabc6-3ccd-4bdf-94dd-5a0f7392284a',
      ApplicationId: '',
      mappingName: 'APISForUnifiedOrchestration',
      includeDeletedItems: false,
      searchableFields: ['Key.Key_lowercase^10', 'Name.Name_lowercase^10'],
      from: 0
    };
    this.http.post<any>(url, payload).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        const items = res?.data || [];
        this.cmsApiList = items.map((item: any) => {
          let metadata: any = {};
          try {
            const raw = item.DynamicProperties?.APIMetadata || item.dynamicProperties?.APIMetadata || '';
            if (raw) metadata = JSON.parse(raw);
          } catch {}
          return {
            id: item.Id || item.id || item.ID,
            key: item.Key || item.key,
            endpoint: metadata.endpoint || '',
            inputMapping: metadata.inputMapping || metadata.inputs || [],
            outputs: metadata.outputs || [],
            method: metadata.method || 'GET'
          };
        });
      },
      error: () => {}
    });
  }

  // ---- Content Studio fetch ----

  fetchFromContentStudio(itemId: string, collectionId: string, contentType: string): void {
    this.loading = true;
    this.errorMessage = '';
    const url = `https://contentstudiocae4-sit.r2.pcf.dell.com/api/ItemApi/GetItem`
      + `?collectionId=${encodeURIComponent(collectionId)}`
      + `&contentType=${encodeURIComponent(contentType)}`
      + `&itemId=${encodeURIComponent(itemId)}`;

    this.http.get<any>(url).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        this.item = res;
        let orchContent = res?.DynamicProperties?.OrchestrationContent
          || res?.dynamicProperties?.orchestrationContent
          || res?.dynamicProperties?.OrchestrationContent
          || res?.DynamicProperties?.orchestrationContent;
        if (typeof orchContent === 'string') {
          try { orchContent = JSON.parse(orchContent); } catch (_) {}
        }
        this.stateService.setBuilderDraft(orchContent ?? {});
        this.orc = this.stateService.getBuilderDraft()!;
        this.loading = false;
        this.setMockDataFlag(false);
      },
      error: (err) => {
        console.error('fetchFromContentStudio failed, loading mock data:', err);
        this.loadFromMockData(itemId);
      }
    });
  }

  loadFromMockData(itemId: string): void {
    const item = MOCK_ORCHESTRATIONS.find(o => o.Id === itemId) || MOCK_ORCHESTRATIONS[0];
    if (!item) {
      this.errorMessage = 'No mock orchestration found for id: ' + itemId;
      this.loading = false;
      return;
    }
    this.item = item;
    let orchContent: any = item.DynamicProperties?.OrchestrationContent;
    if (typeof orchContent === 'string') {
      try { orchContent = JSON.parse(orchContent); } catch (_) { orchContent = {}; }
    }
    this.stateService.setBuilderDraft(orchContent ?? {});
    this.orc = this.stateService.getBuilderDraft()!;
    this.loading = false;
    this.setMockDataFlag(true);
  }

  private setMockDataFlag(isMock: boolean): void {
    this.isMockData = isMock;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { mock: isMock ? 'true' : null },
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }

  // ---- Header actions (matching orcstudio builder.js) ----

  addRootApi(): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'root' });
  }

  openSettings(): void {
    this.flyoutService.open('orc-settings', {});
  }

  openOutput(): void {
    this.flyoutService.open('orc-output', {});
  }

  addDependentStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'dependent', parentCallId });
  }

  addChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'direct-child', parentCallId });
  }

  setIterateStep(callId: string): void {
    this.flyoutService.open('iteration-configure', { callId });
  }

  addIterationChildStep(parentCallId: string): void {
    this.flyoutService.open('browse-apis-builder', { targetType: 'iteration-child', parentCallId });
  }

  save(goBack = false): void {
    // If user edited JSON in the third tab, use that directly
    let draft: any;
    if (this.buildView === 'json' && this.isJsonDirty && !this.jsonError) {
      try {
        draft = JSON.parse(this.jsonDraft);
        this.stateService.setBuilderDraft(draft);
        this.orc = this.stateService.getBuilderDraft()!;
        this.isJsonDirty = false;
      } catch (_) {
        draft = this.stateService.getBuilderDraft() || this.orc;
      }
    } else {
      draft = this.stateService.getBuilderDraft() || this.orc;
    }
    if (!draft) return;

    // If we have an original API item, save via API
    if (this.item) {
      this.isSaving = true;

      // Clone the complete GetItem response
      const payload: any = JSON.parse(JSON.stringify(this.item));

      // Only update OrchestrationContent dynamically from the current JSON
      if (!payload.DynamicProperties) {
        payload.DynamicProperties = {};
      }
      payload.DynamicProperties.OrchestrationContent = JSON.stringify(draft, null, 2);

      const collectionId = payload.CollectionId || payload.collectionId || '8e90b9b4-f6cd-4365-99cf-3cdadf69362a';
      const url = `https://csstudio-sitg3-authoringapi.pnp2.pcf.dell.com/api/${collectionId}/item/updateandcheckin?listIdOrName=${collectionId}`;
      console.log('Saving to updateandcheckin:', url, payload);

      this.http.post<any>(url, payload).subscribe({
        next: (res) => {
          console.log('SaveInDraft response:', res);
          this.stateService.setBuilderDraft(draft);
          this.orc = this.stateService.getBuilderDraft()!;
          this.isSaving = false;
          this.showToast('Orchestration saved successfully');
          if (goBack) this.router.navigate(['/orchestrations']);
        },
        error: (err) => {
          console.error('SaveInDraft failed:', err);
          this.isSaving = false;
          const errMsg = err?.error?.message || err?.message || 'Save failed. Please try again.';
          this.showToast('Error: ' + errMsg);
        }
      });
    } else {
      // Local-only save (no API item loaded)
      if (!draft.name?.trim()) { alert('Please enter an orchestration name'); return; }
      draft.version = this.stateService.bumpVersion(draft.version || '1.0.0');
      this.stateService.saveOrchestration(draft);
      this.stateService.setBuilderDraft(draft);
      this.orc = JSON.parse(JSON.stringify(draft));
      this.isSaving = true;
      setTimeout(() => { this.isSaving = false; }, 600);
      this.showToast('Orchestration saved locally');
      if (goBack) this.router.navigate(['/orchestrations']);
    }
  }

  exportJson(): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;
    const json = JSON.stringify(draft, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = (draft.name || 'orchestration').replace(/[^a-z0-9\-_]+/gi, '-');
    a.href = url; a.download = safeName + '.json';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }

  goBack(): void { this.router.navigate(['/orchestrations']); }

  // ---- Step card actions (matching builder-visual.js) ----

  editStepFields(callId: string): void {
    this.flyoutService.open('step-fields', { callId });
  }

  removeField(callId: string, fieldName: string): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const step = this.findStepByCallId(draft, callId);
    if (step && Array.isArray(step.fields)) {
      step.fields = step.fields.filter((f: string) => f !== fieldName);
      this.stateService.setBuilderDraft(draft);
      this.orc = JSON.parse(JSON.stringify(draft));
    }
  }

  private findStepByCallId(item: any, callId: string): any {
    if (item.callId === callId) return item;
    if (Array.isArray(item.steps)) {
      for (const step of item.steps) {
        const found = this.findStepByCallId(step, callId);
        if (found) return found;
      }
    }
    if (item.children?.steps) {
      for (const child of item.children.steps) {
        const found = this.findStepByCallId(child, callId);
        if (found) return found;
      }
    }
    if (item.iteration?.steps) {
      for (const iterChild of item.iteration.steps) {
        const found = this.findStepByCallId(iterChild, callId);
        if (found) return found;
      }
    }
    return null;
  }

  configureStep(callId: string): void {
    this.flyoutService.open('step-configure', { callId });
  }

  removeStep(callId: string): void {
    if (!confirm(`Remove step "${callId}"? Any steps that depend on it will lose this dependency.`)) return;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.stateService.removeStep(draft, callId);
    this.stateService.setBuilderDraft(draft);
    this.orc = JSON.parse(JSON.stringify(draft));
  }

  getStepDependencies(step: any): string[] {
    return Array.isArray(step?.dependencies) ? step.dependencies : [];
  }

  // ---- Inline input rows on the step card ----

  // Extract {paramName} tokens from a URL path template.
  private extractUrlPathParams(endpoint: string): string[] {
    if (!endpoint) return [];
    const matches = endpoint.match(/\{([^}]+)\}/g);
    return matches ? matches.map(m => m.slice(1, -1)) : [];
  }

  // Extract the source expression from either old flat format or new { $source, $in } format.
  private getMappingSourceExpr(val: any): any {
    if (val && typeof val === 'object' && '$source' in val) return val.$source;
    return val;
  }

  // Extract the $in target from a mapping value (defaults to 'body').
  private getMappingIn(val: any): string {
    if (val && typeof val === 'object' && '$in' in val) return val.$in;
    return 'body';
  }

  getApiForStep(step: any): any | null {
    if (!step) return null;
    if (step.apiId) {
      return this.stateService.getApiById(step.apiId)
        || this.cmsApiList.find((a: any) => a.id === step.apiId)
        || null;
    }
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint)
      || this.cmsApiList.find((a: any) => a.endpoint === step.endpoint)
      || null;
  }

  // The rows rendered on the step card:
  //   1. URL path params extracted from {param} tokens  → paramIn: 'path'
  //   2. step.inputs[] explicit entries                 → paramIn: i.in || 'body'
  //   3. API-definition inputs (mock-data fallback)      → paramIn: i.in || 'query'
  //   4. Extra keys in inputMapping not covered above    → paramIn: derived from existing value
  getStepInputRows(step: any): { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] {
    const rows: { name: string; type: string; required: boolean; custom: boolean; paramIn: string }[] = [];
    const seen = new Set<string>();

    // 1. URL path params
    this.extractUrlPathParams(step?.endpoint || '').forEach(name => {
      rows.push({ name, type: 'string', required: true, custom: false, paramIn: 'path' });
      seen.add(name);
    });

    // 2. Explicit step.inputs
    if (Array.isArray(step?.inputs)) {
      step.inputs.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || 'string', required: !!i.required, custom: false, paramIn: i.in || 'body' });
          seen.add(i.name);
        }
      });
    }

    // 3. API-definition inputs (fallback)
    const api = this.getApiForStep(step);
    if (api && Array.isArray(api.inputMapping)) {
      api.inputMapping.forEach((i: any) => {
        if (!seen.has(i.name)) {
          rows.push({ name: i.name, type: i.type || '', required: !!i.required, custom: false, paramIn: i.in || 'query' });
          seen.add(i.name);
        }
      });
    }

    // 4. Extra custom inputMapping keys
    const map = step?.inputMapping || {};
    Object.keys(map).forEach(k => {
      if (!seen.has(k)) rows.push({ name: k, type: '', required: false, custom: true, paramIn: this.getMappingIn(map[k]) });
    });

    return rows;
  }

  isInputMapped(step: any, paramName: string): boolean {
    const map = step?.inputMapping || {};
    if (!Object.prototype.hasOwnProperty.call(map, paramName)) return false;
    const v = map[paramName];
    const src = this.getMappingSourceExpr(v);
    return src !== '' && src !== undefined && src !== null;
  }

  getMappedInputCount(step: any): number {
    return this.getStepInputRows(step).filter(r => this.isInputMapped(step, r.name)).length;
  }

  getTotalInputCount(step: any): number {
    return this.getStepInputRows(step).length;
  }

  // Resolve the mapping value for a (step, paramName) pair into a readable {icon, label} chip plus a sample value.
  getInputMappingChip(step: any, paramName: string): { icon: string; label: string; tag: string; isUnmapped: boolean } {
    if (!this.isInputMapped(step, paramName)) {
      return { icon: '＋', label: 'Connect a source…', tag: '', isUnmapped: true };
    }
    const raw = this.getMappingSourceExpr((step?.inputMapping || {})[paramName]);
    const draft = this.stateService.getBuilderDraft() || this.orc;
    const sources = draft ? this.availableDataService.getAvailableSources(draft, step.callId) : [];
    const expr = parseMappingExpr(raw, sources.filter(s => s.kind === 'step').map((s: any) => s.callId));

    if (expr.kind === 'flowInput') {
      return { icon: '⚡', label: `Flow input · ${expr.path || '(root)'}`, tag: 'flow', isUnmapped: false };
    }
    if (expr.kind === 'loopItem') {
      const loop = sources.find(s => s.kind === 'loopItem') as any;
      const loopLabel = loop ? loop.label : 'Each item';
      return { icon: '🔄', label: `${loopLabel} · ${expr.path || 'item'}`, tag: 'item', isUnmapped: false };
    }
    if (expr.kind === 'stepOutput') {
      const stepSrc = sources.find(s => s.kind === 'step' && (s as any).callId === expr.callId) as any;
      const apiName = stepSrc?.label || expr.callId;
      return { icon: '📦', label: `${apiName} · ${expr.path || 'response'}`, tag: stepSrc?.apiKey || 'step', isUnmapped: false };
    }
    if (expr.kind === 'literal') {
      return { icon: '🏷', label: formatSampleValueForDisplay(expr.value), tag: 'fixed', isUnmapped: false };
    }
    return { icon: '?', label: expr.raw, tag: 'raw', isUnmapped: false };
  }

  // Sample value chip on the right of each row — resolves the expression to a representative value.
  getInputMappingSampleValue(step: any, paramName: string): string {
    if (!this.isInputMapped(step, paramName)) return '';
    const raw = this.getMappingSourceExpr((step?.inputMapping || {})[paramName]);
    const draft = this.stateService.getBuilderDraft() || this.orc;
    const sources = draft ? this.availableDataService.getAvailableSources(draft, step.callId) : [];
    const expr = parseMappingExpr(raw, sources.filter(s => s.kind === 'step').map((s: any) => s.callId));
    const lookupField = (fields: any[], name: string) => {
      const head = name.split('.')[0];
      return fields.find(f => f.name === head);
    };
    if (expr.kind === 'flowInput') {
      const flow = sources.find(s => s.kind === 'flowInput') as any;
      const f = flow ? lookupField(flow.flowFields, expr.path) : null;
      return f ? formatSampleValueForDisplay(f.exampleValue) : '—';
    }
    if (expr.kind === 'loopItem') {
      const loop = sources.find(s => s.kind === 'loopItem') as any;
      const f = loop ? lookupField(loop.fields, expr.path) : null;
      return f ? formatSampleValueForDisplay(f.exampleValue) : '—';
    }
    if (expr.kind === 'stepOutput') {
      const stepSrc = sources.find(s => s.kind === 'step' && (s as any).callId === expr.callId) as any;
      const f = stepSrc ? lookupField(stepSrc.fields, expr.path) : null;
      return f ? formatSampleValueForDisplay(f.exampleValue) : '—';
    }
    if (expr.kind === 'literal') {
      return formatSampleValueForDisplay(expr.value);
    }
    return '';
  }

  openSourcePicker(callId: string, paramName: string): void {
    const draft = this.stateService.getBuilderDraft();
    const step = draft ? this.stateService.getStepById(draft, callId) : null;
    const row = step ? this.getStepInputRows(step).find(r => r.name === paramName) : null;
    const paramIn = row?.paramIn || 'body';
    this.flyoutService.open('source-picker', { callId, paramName, paramIn });
  }

  clearInputMapping(callId: string, paramName: string): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const step = this.stateService.getStepById(draft, callId);
    if (!step || !step.inputMapping) return;
    delete step.inputMapping[paramName];
    this.stateService.setBuilderDraft(draft);
    this.orc = JSON.parse(JSON.stringify(draft));
  }

  addCustomInput(callId: string): void {
    this.flyoutService.open('add-custom-input', { callId });
  }

  truncateFieldName(name: string): string {
    if (!name) return '';
    return name.length > 15 ? name.slice(0, 15) + '...' : name;
  }

  // ---- Test tab methods ----

  initTestTab(): void {
    const draft = this.stateService.getBuilderDraft() || this.orc;
    if (!draft) return;
    this.testApiUrl = `https://orchestrationapi.studiod-r3-np.kob.dell.com/api/orchestration/preview/execute?skipCache=false&includeMetrics=true`;
    const stripped = {
      id: draft.id,
      orchestrationId: draft.orchestrationId,
      name: draft.name,
      description: draft.description,
      version: draft.version,
      steps: draft.steps || []
    };
    const defaultProfile = { country: 'us', language: 'en', region: 'us', segment: 'cnsr', market: 'usa_market' };
    const profile = draft.requestData?.profile
      ? { ...defaultProfile, ...draft.requestData.profile }
      : defaultProfile;
    const requestBody = { orchestration: stripped, requestData: { profile } };
    this.testRequestJson = JSON.stringify(requestBody, null, 2);
    this.testRequestJsonError = '';
  }

  buildTestRequestJson(draft: any): string {
    const stripped = {
      id: draft.id,
      orchestrationId: draft.orchestrationId,
      name: draft.name,
      description: draft.description,
      version: draft.version,
      steps: draft.steps || []
    };
    const defaultProfile = { country: 'us', language: 'en', region: 'us', segment: 'cnsr', market: 'usa_market' };
    const profile = draft.requestData?.profile
      ? { ...defaultProfile, ...draft.requestData.profile }
      : defaultProfile;
    return JSON.stringify({ orchestration: stripped, requestData: { profile } }, null, 2);
  }

  sendTestRequest(): void {
    let parsedBody: any;
    try {
      parsedBody = JSON.parse(this.testRequestJson);
    } catch (e: any) {
      this.testStatusCode = 400;
      this.testResponseJson = JSON.stringify({ error: 'Invalid request JSON', detail: e.message }, null, 2);
      return;
    }

    this.isTesting = true;
    this.testResponseJson = '';
    this.testStatusCode = null;

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.http.post(this.testApiUrl, parsedBody, { headers, observe: 'response' })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.testStatusCode = response.status;
          this.testResponseJson = JSON.stringify(response.body, null, 2);
          this.isTesting = false;
        },
        error: (err: HttpErrorResponse) => {
          this.testStatusCode = err.status || 0;
          const body = err.error;
          if (body && typeof body === 'object') {
            this.testResponseJson = JSON.stringify(body, null, 2);
          } else if (typeof body === 'string') {
            try { this.testResponseJson = JSON.stringify(JSON.parse(body), null, 2); }
            catch { this.testResponseJson = JSON.stringify({ error: body || err.message }, null, 2); }
          } else {
            this.testResponseJson = JSON.stringify({ error: err.message || 'Request failed', status: err.status }, null, 2);
          }
          this.isTesting = false;
        }
      });
  }

  onTestRequestInput(value: string): void {
    this.testRequestJson = value;
    try {
      JSON.parse(value);
      this.testRequestJsonError = '';
    } catch (e: any) {
      this.testRequestJsonError = e.message || 'Invalid JSON';
    }
  }

  toggleResponseExpand(): void {
    this.testResponseExpanded = !this.testResponseExpanded;
  }

  toggleRequestExpand(): void {
    this.testRequestExpanded = !this.testRequestExpanded;
  }

  showToast(msg: string): void {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  trackByCallId(_: number, step: any): string { return step.callId; }

  methodLabel(method: string): string {
    const map: Record<string, string> = {
      GET: 'Reads', POST: 'Creates', PUT: 'Updates', DELETE: 'Removes'
    };
    return map[(method || 'GET').toUpperCase()] || (method || 'GET');
  }

  toggleFields(callId: string): void {
    if (this.expandedFieldsSet.has(callId)) {
      this.expandedFieldsSet.delete(callId);
    } else {
      this.expandedFieldsSet.add(callId);
    }
  }

  isFieldsExpanded(callId: string): boolean {
    return this.expandedFieldsSet.has(callId);
  }

  isStepCollapsed(callId: string): boolean {
    return this.collapsedStepsSet.has(callId);
  }

  toggleStepCollapsed(callId: string): void {
    if (this.collapsedStepsSet.has(callId)) {
      this.collapsedStepsSet.delete(callId);
    } else {
      this.collapsedStepsSet.add(callId);
    }
  }

  private collectAllStepCallIds(steps: any[] | undefined, acc: string[]): void {
    if (!Array.isArray(steps)) return;
    steps.forEach(s => {
      if (s?.callId) acc.push(s.callId);
      if (s?.children?.steps) this.collectAllStepCallIds(s.children.steps, acc);
      if (s?.iteration?.steps) this.collectAllStepCallIds(s.iteration.steps, acc);
    });
  }

  getAllStepCallIds(): string[] {
    const acc: string[] = [];
    this.collectAllStepCallIds(this.getSteps(), acc);
    return acc;
  }

  areAllStepsCollapsed(): boolean {
    const ids = this.getAllStepCallIds();
    return ids.length > 0 && ids.every(id => this.collapsedStepsSet.has(id));
  }

  collapseAllSteps(): void {
    this.collapsedStepsSet = new Set(this.getAllStepCallIds());
  }

  expandAllSteps(): void {
    this.collapsedStepsSet.clear();
  }
}
