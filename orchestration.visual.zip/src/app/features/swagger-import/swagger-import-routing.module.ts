import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SwaggerImportComponent } from './swagger-import.component';

const routes: Routes = [
  { path: '', component: SwaggerImportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SwaggerImportRoutingModule { }
