import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StateService } from '@core/services/state.service';

interface SwaggerApiEntry {
  selected: boolean;
  method: string;
  name: string;
  endpoint: string;
  jsonText: string;
  parsed: any;
}

interface ExtractionFlyout {
  isOpen: boolean;
  activeApiIndex: number | null;
  fullUrl: string;
  sampleRequest: string;
  apiResponse: string;
  responseLoading: boolean;
  responseError: string;
}

@Component({
  selector: 'app-swagger-import',
  templateUrl: './swagger-import.component.html',
  styleUrls: ['./swagger-import.component.scss']
})
export class SwaggerImportComponent implements OnInit {
  swaggerUrl: string = '';
  loading: boolean = false;
  errorMsg: string = '';
  parsedApis: SwaggerApiEntry[] = [];
  expandedIndex: number | null = null;
  importSuccess: boolean = false;
  extraction: ExtractionFlyout = {
    isOpen: false,
    activeApiIndex: null,
    fullUrl: '',
    sampleRequest: '',
    apiResponse: '',
    responseLoading: false,
    responseError: ''
  };

  constructor(
    private http: HttpClient,
    private stateService: StateService
  ) {}

  ngOnInit(): void {}

  loadSwagger(): void {
    if (!this.swaggerUrl.trim()) {
      this.errorMsg = 'Please enter a Swagger URL.';
      return;
    }

    this.errorMsg = '';
    this.loading = true;
    this.parsedApis = [];

    this.http.get(this.swaggerUrl.trim()).subscribe({
      next: (spec: any) => {
        this.loading = false;
        this.parsedApis = this.parseSwagger(spec);
        if (this.parsedApis.length === 0) {
          this.errorMsg = 'No API endpoints found in the Swagger spec.';
        }
      },
      error: (err) => {
        this.loading = false;
        this.errorMsg = 'Failed to fetch Swagger spec. CORS may be blocking this URL or the URL is invalid.';
      }
    });
  }

  private parseSwagger(spec: any): SwaggerApiEntry[] {
    const apis: SwaggerApiEntry[] = [];
    const isV3 = !!spec.openapi;

    let baseUrl = 'https://api.example.com';
    if (isV3 && spec.servers && spec.servers.length > 0) {
      baseUrl = spec.servers[0].url;
    } else if (!isV3 && spec.schemes && spec.host) {
      baseUrl = `${spec.schemes[0]}://${spec.host}${spec.basePath || ''}`;
    }

    if (!spec.paths || typeof spec.paths !== 'object') {
      return apis;
    }

    Object.entries(spec.paths).forEach(([path, pathItem]: any) => {
      const methods = ['get', 'post', 'put', 'delete', 'patch'];
      methods.forEach((method) => {
        const operation = pathItem[method];
        if (!operation) return;

        const operationId = operation.operationId || `${method}_${path.replace(/[{}\/]/g, '_')}`;
        const api = this.buildApiObject(
          operationId,
          method.toUpperCase(),
          operation.summary || operationId,
          path,
          baseUrl,
          operation,
          isV3
        );

        apis.push({
          selected: false,
          method: method.toUpperCase(),
          name: operation.summary || operationId,
          endpoint: path,
          jsonText: this.formatApi(api),
          parsed: api
        });
      });
    });

    return apis;
  }

  private buildApiObject(
    operationId: string,
    method: string,
    summary: string,
    path: string,
    baseUrl: string,
    operation: any,
    isV3: boolean
  ): any {
    const inputs = this.extractInputs(operation, isV3);
    const fields: any[] = [];
    const sampleRequest = this.generateSampleRequest(inputs);

    const iconMap: { [key: string]: string } = {
      'GET': '📖',
      'POST': '➕',
      'PUT': '✏️',
      'DELETE': '🗑️',
      'PATCH': '🔧'
    };

    const keyName = operationId.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    const timestamp = Date.now();

    return {
      id: `${keyName}-${timestamp}`,
      key: keyName,
      name: summary,
      method: method,
      icon: iconMap[method] || '🔗',
      description: operation.description || '',
      category: 'Imported',
      baseUrl: baseUrl,
      endpoint: path,
      inputs: inputs,
      sampleRequest: sampleRequest,
      fields: fields
    };
  }

  private extractInputs(operation: any, isV3: boolean): any[] {
    const inputs: any[] = [];

    if (operation.parameters && Array.isArray(operation.parameters)) {
      operation.parameters.forEach((param: any) => {
        inputs.push({
          name: param.name,
          type: param.type || param.schema?.type || 'string',
          required: param.required || false,
          description: param.description || ''
        });
      });
    }

    if (isV3 && operation.requestBody && operation.requestBody.content) {
      const jsonContent = operation.requestBody.content['application/json'];
      if (jsonContent && jsonContent.schema && jsonContent.schema.properties) {
        Object.entries(jsonContent.schema.properties).forEach(([name, prop]: any) => {
          inputs.push({
            name: name,
            type: prop.type || 'string',
            required: (operation.requestBody.required || []).includes(name),
            description: prop.description || ''
          });
        });
      }
    }

    return inputs;
  }

  private generateSampleRequest(inputs: any[]): any {
    const sample: any = {};
    inputs.forEach((input) => {
      if (input.type === 'number' || input.type === 'integer') {
        sample[input.name] = 0;
      } else if (input.type === 'boolean') {
        sample[input.name] = true;
      } else if (input.type === 'array') {
        sample[input.name] = [];
      } else if (input.type === 'object') {
        sample[input.name] = {};
      } else {
        sample[input.name] = 'example';
      }
    });
    return sample;
  }

  formatApi(api: any): string {
    const lines: string[] = ['{'];
    lines.push(`  id: '${api.id}',`);
    lines.push(`  key: '${api.key}',`);
    lines.push(`  name: '${this.escapeString(api.name)}',`);
    lines.push(`  method: '${api.method}',`);
    lines.push(`  icon: '${api.icon}',`);
    lines.push(`  description: '${this.escapeString(api.description)}',`);
    lines.push(`  category: '${api.category}',`);
    lines.push(`  baseUrl: '${api.baseUrl}',`);
    lines.push(`  endpoint: '${api.endpoint}',`);
    lines.push(`  inputs: ${this.formatArray(api.inputs)},`);
    lines.push(`  sampleRequest: ${JSON.stringify(api.sampleRequest, null, 2).split('\n').map((l, i) => i === 0 ? l : '    ' + l).join('\n')},`);
    lines.push(`  fields: ${this.formatArray(api.fields)}`);
    lines.push('}');
    return lines.join('\n');
  }

  private escapeString(str: string): string {
    return (str || '').replace(/'/g, "\\'");
  }

  private formatArray(arr: any[]): string {
    if (!arr || arr.length === 0) return '[]';
    return '[\n    ' + arr.map((item) => JSON.stringify(item)).join(',\n    ') + '\n  ]';
  }

  toggleExpandedIndex(index: number): void {
    this.expandedIndex = this.expandedIndex === index ? null : index;
  }

  toggleSelectAll(event: any): void {
    const isChecked = event.target.checked;
    this.parsedApis.forEach((api) => {
      api.selected = isChecked;
    });
  }

  isAllSelected(): boolean {
    return this.parsedApis.length > 0 && this.parsedApis.every((api) => api.selected);
  }

  isPartiallySelected(): boolean {
    const selectedCount = this.parsedApis.filter((api) => api.selected).length;
    return selectedCount > 0 && selectedCount < this.parsedApis.length;
  }

  getSelectedCount(): number {
    return this.parsedApis.filter((api) => api.selected).length;
  }

  importSelected(): void {
    const selectedApis = this.parsedApis
      .filter((entry) => entry.selected)
      .map((entry) => {
        try {
          return (new Function('return (' + entry.jsonText + ')'))();
        } catch {
          return entry.parsed;
        }
      });

    if (selectedApis.length === 0) {
      this.errorMsg = 'Please select at least one API to import.';
      return;
    }

    this.stateService.importApis(selectedApis);
    this.importSuccess = true;
    this.errorMsg = '';

    setTimeout(() => {
      this.importSuccess = false;
      this.parsedApis = [];
      this.swaggerUrl = '';
    }, 3000);
  }

  openExtractionFlyout(apiIndex: number): void {
    const api = this.parsedApis[apiIndex];
    if (!api) return;

    this.extraction.isOpen = true;
    this.extraction.activeApiIndex = apiIndex;
    this.extraction.fullUrl = api.parsed.baseUrl + api.parsed.endpoint;
    this.extraction.sampleRequest = JSON.stringify(api.parsed.sampleRequest || {}, null, 2);
    this.extraction.apiResponse = '';
    this.extraction.responseError = '';
    this.extraction.responseLoading = false;
  }

  closeExtractionFlyout(): void {
    this.extraction.isOpen = false;
    this.extraction.activeApiIndex = null;
  }

  sendRequest(): void {
    this.extraction.responseLoading = true;
    this.extraction.responseError = '';
    this.extraction.apiResponse = '';

    try {
      const sampleData = JSON.parse(this.extraction.sampleRequest);
      const api = this.parsedApis[this.extraction.activeApiIndex!];
      const requestBody = api.parsed.method === 'GET' ? null : sampleData;

      this.http.request(api.parsed.method, this.extraction.fullUrl, { body: requestBody }).subscribe({
        next: (response: any) => {
          this.extraction.responseLoading = false;
          this.extraction.apiResponse = JSON.stringify(response, null, 2);
        },
        error: (err) => {
          this.extraction.responseLoading = false;
          this.extraction.responseError = this.getErrorMessage(err);
        }
      });
    } catch (e: any) {
      this.extraction.responseLoading = false;
      this.extraction.responseError = 'Invalid JSON in sample request: ' + e.message;
    }
  }

  private substitutePathParams(endpoint: string, data: any): string {
    let result = endpoint;
    const pathParamRegex = /\{([^}]+)\}/g;
    result = result.replace(pathParamRegex, (match, paramName) => {
      return data[paramName] !== undefined ? data[paramName] : match;
    });
    return result;
  }

  private getErrorMessage(err: any): string {
    if (err.status === 0) {
      return 'CORS error or network failure. Make sure the API has CORS enabled.';
    }
    if (err.error && typeof err.error === 'object' && err.error.message) {
      return err.error.message;
    }
    return err.statusText || 'Failed to call API. Check the endpoint and request.';
  }

  applyExtractionAndClose(): void {
    if (!this.extraction.apiResponse) return;

    const api = this.parsedApis[this.extraction.activeApiIndex!];
    if (!api) return;

    try {
      const response = JSON.parse(this.extraction.apiResponse);
      const fields = this.extractFieldsFromResponse(response);
      api.parsed.fields = fields;
      api.jsonText = this.formatApi(api.parsed);
    } catch (e) {
      this.extraction.responseError = 'Failed to extract fields from response.';
      return;
    }

    this.closeExtractionFlyout();
  }

  private extractFieldsFromResponse(response: any): string[] {
    const fields: string[] = [];

    if (!response || typeof response !== 'object') {
      return fields;
    }

    // If response is an array, extract fields from the first element
    const data = Array.isArray(response) ? response[0] : response;

    if (!data || typeof data !== 'object') {
      return fields;
    }

    // Extract just the field names
    Object.keys(data).forEach((key) => {
      fields.push(key);
    });

    return fields;
  }

  private inferType(value: any): string {
    if (Array.isArray(value)) return 'array';
    if (value === null) return 'object';
    if (typeof value === 'number') return 'number';
    if (typeof value === 'boolean') return 'boolean';
    if (typeof value === 'object') return 'object';
    return 'string';
  }
}
