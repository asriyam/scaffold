import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { from, of } from 'rxjs';
import { concatMap, catchError, map } from 'rxjs/operators';

interface SwaggerApiEntry {
  selected: boolean;
  method: string;
  name: string;
  endpoint: string;
  jsonText: string;
  parsed: any;
}

interface ExtractionParameter {
  name: string;
  in: 'path' | 'query' | 'header';
  type: string;
  required: boolean;
  description: string;
}

interface ExtractionFlyout {
  isOpen: boolean;
  activeApiIndex: number | null;
  name: string;
  fullUrl: string;
  parameters: ExtractionParameter[];
  paramValues: { [name: string]: any };
  hasBody: boolean;
  sampleRequest: string;
  category: string;
  apiResponse: string;
  responseLoading: boolean;
  responseError: string;
}

@Component({
  selector: 'app-swagger-import',
  templateUrl: './swagger-import.component.html',
  styleUrls: ['./swagger-import.component.scss']
})
export class SwaggerImportComponent implements OnInit {
  swaggerUrl: string = '';
  loading: boolean = false;
  errorMsg: string = '';
  parsedApis: SwaggerApiEntry[] = [];
  expandedIndex: number | null = null;
  importSuccess: boolean = false;
  saving: boolean = false;
  saveProgress: { current: number; total: number } = { current: 0, total: 0 };
  saveResults: { success: number; failed: number } = { success: 0, failed: 0 };
  recentUrls: { url: string; timestamp: number }[] = [];
  extraction: ExtractionFlyout = {
    isOpen: false,
    activeApiIndex: null,
    name: '',
    fullUrl: '',
    parameters: [],
    paramValues: {},
    hasBody: false,
    sampleRequest: '',
    category: '',
    apiResponse: '',
    responseLoading: false,
    responseError: ''
  };

  private readonly RECENT_URLS_KEY = 'swagger_recent_urls';
  private readonly MAX_RECENT_URLS = 10;

  constructor(
    private http: HttpClient,
    private stateService: StateService
  ) {}

  ngOnInit(): void {
    this.loadRecentUrls();
  }

  loadSwagger(): void {
    if (!this.swaggerUrl.trim()) {
      this.errorMsg = 'Please enter a Swagger URL.';
      return;
    }

    this.errorMsg = '';
    this.loading = true;
    this.parsedApis = [];

    this.http.get(this.swaggerUrl.trim()).subscribe({
      next: (spec: any) => {
        this.loading = false;
        this.parsedApis = this.parseSwagger(spec, this.swaggerUrl.trim());
        if (this.parsedApis.length === 0) {
          this.errorMsg = 'No API endpoints found in the Swagger spec.';
        } else {
          this.addRecentUrl(this.swaggerUrl.trim());
        }
      },
      error: (err) => {
        this.loading = false;
        this.errorMsg = 'Failed to fetch Swagger spec. CORS may be blocking this URL or the URL is invalid.';
      }
    });
  }

  private loadRecentUrls(): void {
    try {
      const stored = localStorage.getItem(this.RECENT_URLS_KEY);
      if (stored) {
        this.recentUrls = JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load recent URLs:', e);
      this.recentUrls = [];
    }
  }

  private addRecentUrl(url: string): void {
    const trimmedUrl = url.trim();

    // Remove if already exists (to avoid duplicates)
    this.recentUrls = this.recentUrls.filter(item => item.url !== trimmedUrl);

    // Add to front
    this.recentUrls.unshift({ url: trimmedUrl, timestamp: Date.now() });

    // Keep only the last MAX_RECENT_URLS
    if (this.recentUrls.length > this.MAX_RECENT_URLS) {
      this.recentUrls = this.recentUrls.slice(0, this.MAX_RECENT_URLS);
    }

    // Save to localStorage
    try {
      localStorage.setItem(this.RECENT_URLS_KEY, JSON.stringify(this.recentUrls));
    } catch (e) {
      console.error('Failed to save recent URLs:', e);
    }
  }

  useRecentUrl(url: string): void {
    this.swaggerUrl = url;
    this.loadSwagger();
  }

  clearRecentUrls(): void {
    this.recentUrls = [];
    try {
      localStorage.removeItem(this.RECENT_URLS_KEY);
    } catch (e) {
      console.error('Failed to clear recent URLs:', e);
    }
  }

  private parseSwagger(spec: any, swaggerUrl: string = ''): SwaggerApiEntry[] {
    const apis: SwaggerApiEntry[] = [];
    const isV3 = !!spec.openapi;

    let fallbackBaseUrl = '';
    try {
      const parsed = new URL(swaggerUrl);
      fallbackBaseUrl = parsed.origin;
    } catch {}

    let baseUrl = fallbackBaseUrl || 'https://api.example.com';
    if (isV3 && spec.servers && spec.servers.length > 0) {
      baseUrl = spec.servers[0].url;
    } else if (!isV3 && spec.schemes && spec.host) {
      baseUrl = `${spec.schemes[0]}://${spec.host}${spec.basePath || ''}`;
    }

    if (!spec.paths || typeof spec.paths !== 'object') {
      return apis;
    }

    Object.entries(spec.paths).forEach(([path, pathItem]: any) => {
      const methods = ['get', 'post', 'put', 'delete', 'patch'];
      methods.forEach((method) => {
        const operation = pathItem[method];
        if (!operation) return;

        const operationId = operation.operationId || `${method}_${path.replace(/[{}\/]/g, '_')}`;
        const api = this.buildApiObject(
          operationId,
          method.toUpperCase(),
          operation.summary || operationId,
          path,
          baseUrl,
          operation,
          isV3,
          spec
        );

        apis.push({
          selected: false,
          method: method.toUpperCase(),
          name: operation.summary || operationId,
          endpoint: path,
          jsonText: this.formatApi(api),
          parsed: api
        });
      });
    });

    return apis;
  }

  private buildApiObject(
    operationId: string,
    method: string,
    summary: string,
    path: string,
    baseUrl: string,
    operation: any,
    isV3: boolean,
    spec: any
  ): any {
    const inputs = this.extractInputMapping(operation, isV3, spec);
    const fields: any[] = [];
    const sampleRequest = this.generateBodySample(operation, isV3, spec);

    const iconMap: { [key: string]: string } = {
      'GET': '📖',
      'POST': '➕',
      'PUT': '✏️',
      'DELETE': '🗑️',
      'PATCH': '🔧'
    };

    const keyName = operationId.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    const timestamp = Date.now();

    return {
      id: `${keyName}-${timestamp}`,
      key: keyName,
      name: summary,
      method: method,
      icon: iconMap[method] || '🔗',
      description: operation.description || '',
      category: 'Imported',
      baseUrl: baseUrl,
      endpoint: path,
      inputs: inputs,
      inputMapping: { profile: '$request.profile' },
      sampleRequest: sampleRequest,
      fields: fields,
      outputs: []
    };
  }

  private extractInputMapping(operation: any, isV3: boolean, spec: any): any[] {
    const inputs: any[] = [];

    if (operation.parameters && Array.isArray(operation.parameters)) {
      operation.parameters.forEach((param: any) => {
        // v2 body parameters are expanded into individual properties below.
        if (!isV3 && param.in === 'body') return;
        inputs.push({
          name: param.name,
          in: param.in || 'query',
          type: param.type || param.schema?.type || 'string',
          required: param.required || false,
          description: param.description || ''
        });
      });
    }

    const bodySchema = this.getBodySchema(operation, isV3);
    if (bodySchema) {
      this.extractBodyProperties(bodySchema, spec, new Set())
        .forEach((bp) => inputs.push(bp));
    }

    return inputs;
  }

  private getBodySchema(operation: any, isV3: boolean): any {
    if (isV3) {
      const content = operation.requestBody?.content;
      if (!content) return null;
      const jsonContent = content['application/json'] || content[Object.keys(content)[0]];
      return jsonContent?.schema || null;
    }
    const bodyParam = operation.parameters?.find((p: any) => p.in === 'body');
    return bodyParam?.schema || null;
  }

  private extractBodyProperties(schema: any, spec: any, visited: Set<string>): any[] {
    if (!schema) return [];

    if (schema.$ref) {
      if (visited.has(schema.$ref)) return [];
      const next = new Set(visited);
      next.add(schema.$ref);
      const resolved = this.resolveRef(schema.$ref, spec);
      return this.extractBodyProperties(resolved, spec, next);
    }

    if (schema.allOf && Array.isArray(schema.allOf)) {
      const merged: any[] = [];
      schema.allOf.forEach((sub: any) => {
        merged.push(...this.extractBodyProperties(sub, spec, visited));
      });
      return merged;
    }

    // Array of objects: extract properties from the item schema.
    const target = schema.type === 'array' && schema.items ? schema.items : schema;
    if (target !== schema && target?.$ref) {
      return this.extractBodyProperties(target, spec, visited);
    }

    const properties = target?.properties;
    if (!properties || typeof properties !== 'object') return [];
    const requiredList: string[] = Array.isArray(target.required) ? target.required : [];

    return Object.entries(properties).map(([name, prop]: any) => ({
      name,
      in: 'body',
      type: prop.type || (prop.$ref ? 'object' : 'string'),
      required: requiredList.includes(name),
      description: prop.description || ''
    }));
  }

  private generateBodySample(operation: any, isV3: boolean, spec: any): any {
    if (isV3) {
      if (!operation.requestBody || !operation.requestBody.content) return null;
      const jsonContent = operation.requestBody.content['application/json']
        || operation.requestBody.content[Object.keys(operation.requestBody.content)[0]];
      if (!jsonContent) return null;
      if (jsonContent.example !== undefined) return jsonContent.example;
      if (jsonContent.examples) {
        const first: any = Object.values(jsonContent.examples)[0];
        if (first && first.value !== undefined) return first.value;
      }
      if (jsonContent.schema) return this.sampleFromSchema(jsonContent.schema, spec, new Set());
      return null;
    }

    // Swagger v2: body lives in parameters[] with in === 'body'
    if (operation.parameters && Array.isArray(operation.parameters)) {
      const bodyParam = operation.parameters.find((p: any) => p.in === 'body');
      if (bodyParam) {
        if (bodyParam.schema?.example !== undefined) return bodyParam.schema.example;
        if (bodyParam.example !== undefined) return bodyParam.example;
        if (bodyParam.schema) return this.sampleFromSchema(bodyParam.schema, spec, new Set());
        return {};
      }
    }
    return null;
  }

  private resolveRef(ref: string, spec: any): any {
    if (!ref || typeof ref !== 'string' || !ref.startsWith('#/')) return null;
    const parts = ref.substring(2).split('/');
    let node: any = spec;
    for (const part of parts) {
      if (node == null) return null;
      node = node[part];
    }
    return node || null;
  }

  private sampleFromSchema(schema: any, spec: any, visited: Set<string>, depth: number = 0): any {
    if (!schema || depth > 8) return null;

    if (schema.$ref) {
      if (visited.has(schema.$ref)) return null;
      const next = new Set(visited);
      next.add(schema.$ref);
      const resolved = this.resolveRef(schema.$ref, spec);
      return this.sampleFromSchema(resolved, spec, next, depth + 1);
    }

    if (schema.example !== undefined) return schema.example;
    if (schema.default !== undefined) return schema.default;

    if (schema.allOf && Array.isArray(schema.allOf)) {
      const merged: any = {};
      schema.allOf.forEach((sub: any) => {
        const part = this.sampleFromSchema(sub, spec, visited, depth + 1);
        if (part && typeof part === 'object' && !Array.isArray(part)) Object.assign(merged, part);
      });
      return merged;
    }

    if (schema.enum && Array.isArray(schema.enum) && schema.enum.length > 0) {
      return schema.enum[0];
    }

    const type = schema.type || (schema.properties ? 'object' : (schema.items ? 'array' : 'string'));

    if (type === 'object') {
      const obj: any = {};
      const props = schema.properties || {};
      Object.entries(props).forEach(([name, prop]: any) => {
        obj[name] = this.sampleFromSchema(prop, spec, visited, depth + 1);
      });
      return obj;
    }
    if (type === 'array') {
      return schema.items ? [this.sampleFromSchema(schema.items, spec, visited, depth + 1)] : [];
    }
    if (type === 'integer' || type === 'number') return 0;
    if (type === 'boolean') return true;
    return 'example';
  }

  private getSampleValueForType(type: string): any {
    if (type === 'number' || type === 'integer') return 0;
    if (type === 'boolean') return true;
    if (type === 'array') return [];
    if (type === 'object') return {};
    return '';
  }

  formatApi(api: any): string {
    return JSON.stringify(api, null, 2);
  }

  toggleExpandedIndex(index: number): void {
    this.expandedIndex = this.expandedIndex === index ? null : index;
  }

  toggleSelectAll(event: any): void {
    const isChecked = event.target.checked;
    this.parsedApis.forEach((api) => {
      api.selected = isChecked;
    });
  }

  isAllSelected(): boolean {
    return this.parsedApis.length > 0 && this.parsedApis.every((api) => api.selected);
  }

  isPartiallySelected(): boolean {
    const selectedCount = this.parsedApis.filter((api) => api.selected).length;
    return selectedCount > 0 && selectedCount < this.parsedApis.length;
  }

  getSelectedCount(): number {
    return this.parsedApis.filter((api) => api.selected).length;
  }

  importSelected(): void {
    const selectedApis = this.parsedApis.filter((entry) => entry.selected);

    if (selectedApis.length === 0) {
      this.errorMsg = 'Please select at least one API to import.';
      return;
    }

    this.errorMsg = '';
    this.importSuccess = false;
    this.saving = true;
    this.saveProgress = { current: 0, total: selectedApis.length };
    this.saveResults = { success: 0, failed: 0 };

    from(selectedApis).pipe(
      concatMap((entry) =>
        this.createApiItem(entry.parsed.key, JSON.stringify(entry.parsed), entry.parsed.name).pipe(
          map(() => ({ success: true, key: entry.parsed.key })),
          catchError((err) => {
            const errMsg = err?.error?.message || err?.message || 'Save failed';
            console.error(`Failed to save API "${entry.parsed.key}":`, err);
            return of({ success: false, key: entry.parsed.key, error: errMsg });
          })
        )
      )
    ).subscribe({
      next: (result: any) => {
        this.saveProgress.current++;
        if (result.success) {
          this.saveResults.success++;
        } else {
          this.saveResults.failed++;
        }
      },
      complete: () => {
        this.saving = false;
        if (this.saveResults.success > 0) {
          this.importSuccess = true;
        }
        if (this.saveResults.failed > 0) {
          this.errorMsg = `${this.saveResults.failed} API(s) failed to save. Please check the console for details.`;
        }
      }
    });
  }

  private createApiItem(apiMethod: string, apiJsonText: string, displayName?: string) {
    const collectionId = 'd10aabc6-3ccd-4bdf-94dd-5a0f7392284a';
    const payload = {
      key: apiMethod,
      documentMajorVersion: 0,
      documentMinorVersion: 0,
      scheduleStartDate: '1900-12-30T18:38:50.000Z',
      scheduleEndDate: '9999-12-30T18:30:00.000Z',
      checkedoutBy: '',
      container: ['root'],
      publishStatus: '',
      version: 0,
      collectionId,
      name: displayName || apiMethod,
      comments: '',
      groups: [],
      modifiedBy: 'asia-pacific\\swetha_selvaraj',
      createdBy: 'asia-pacific\\swetha_selvaraj',
      dynamicProperties: {
        APIMetadata: apiJsonText || ''
      }
    };
    const url = `https://csstudio-sitg3-authoringapi.pnp2.pcf.dell.com/api/${collectionId}/item/createandcheckin`;
    console.log('Saving API item:', url, payload);
    return this.http.post<any>(url, payload);
  }

  openExtractionFlyout(apiIndex: number): void {
    const api = this.parsedApis[apiIndex];
    if (!api) return;

    const allInputs: any[] = Array.isArray(api.parsed.inputs) ? api.parsed.inputs : [];
    const parameters: ExtractionParameter[] = allInputs
      .filter((i: any) => i.in && i.in !== 'body')
      .map((i: any) => ({
        name: i.name,
        in: i.in,
        type: i.type || 'string',
        required: !!i.required,
        description: i.description || ''
      }));

    const savedValues: { [k: string]: any } = api.parsed.sampleParams || {};
    const paramValues: { [k: string]: any } = {};
    parameters.forEach((p) => {
      paramValues[p.name] = savedValues[p.name] !== undefined
        ? savedValues[p.name]
        : this.getSampleValueForType(p.type);
    });

    const hasBody = api.parsed.sampleRequest !== null && api.parsed.sampleRequest !== undefined;

    this.extraction.isOpen = true;
    this.extraction.activeApiIndex = apiIndex;
    this.extraction.name = api.name || api.parsed.name || '';
    this.extraction.fullUrl = api.parsed.baseUrl + api.parsed.endpoint;
    this.extraction.parameters = parameters;
    this.extraction.paramValues = paramValues;
    this.extraction.hasBody = hasBody;
    this.extraction.sampleRequest = hasBody ? JSON.stringify(api.parsed.sampleRequest, null, 2) : '';
    this.extraction.category = api.parsed.category || '';
    this.extraction.apiResponse = '';
    this.extraction.responseError = '';
    this.extraction.responseLoading = false;
  }

  closeExtractionFlyout(): void {
    this.extraction.isOpen = false;
    this.extraction.activeApiIndex = null;
  }

  sendRequest(): void {
    this.extraction.responseLoading = true;
    this.extraction.responseError = '';
    this.extraction.apiResponse = '';

    const api = this.parsedApis[this.extraction.activeApiIndex!];
    const method = (api.parsed.method || 'GET').toUpperCase();
    const bodyless = method === 'GET' || method === 'HEAD' || method === 'DELETE';

    let url = this.substitutePathParams(this.extraction.fullUrl, this.extraction.paramValues);

    const queryParams = new URLSearchParams();
    this.extraction.parameters
      .filter((p) => p.in === 'query')
      .forEach((p) => {
        const v = this.extraction.paramValues[p.name];
        if (v !== undefined && v !== null && v !== '') {
          queryParams.append(p.name, String(v));
        }
      });
    const qs = queryParams.toString();
    if (qs) {
      url += (url.indexOf('?') >= 0 ? '&' : '?') + qs;
    }

    let headers = new HttpHeaders();
    this.extraction.parameters
      .filter((p) => p.in === 'header')
      .forEach((p) => {
        const v = this.extraction.paramValues[p.name];
        if (v !== undefined && v !== null && v !== '') {
          headers = headers.set(p.name, String(v));
        }
      });

    let requestBody: any = null;
    if (!bodyless && this.extraction.hasBody) {
      try {
        requestBody = JSON.parse(this.extraction.sampleRequest);
      } catch (e: any) {
        this.extraction.responseLoading = false;
        this.extraction.responseError = 'Invalid JSON in sample request: ' + e.message;
        return;
      }
    }

    this.http.request(method, url, { body: requestBody, headers }).subscribe({
      next: (response: any) => {
        this.extraction.responseLoading = false;
        this.extraction.apiResponse = JSON.stringify(response, null, 2);
      },
      error: (err) => {
        this.extraction.responseLoading = false;
        this.extraction.responseError = this.getErrorMessage(err);
      }
    });
  }

  private substitutePathParams(endpoint: string, data: any): string {
    let result = endpoint;
    const pathParamRegex = /\{([^}]+)\}/g;
    result = result.replace(pathParamRegex, (match, paramName) => {
      return data[paramName] !== undefined ? data[paramName] : match;
    });
    return result;
  }

  private getErrorMessage(err: any): string {
    if (err.status === 0) {
      return 'CORS error or network failure. Make sure the API has CORS enabled.';
    }
    if (err.error && typeof err.error === 'object' && err.error.message) {
      return err.error.message;
    }
    return err.statusText || 'Failed to call API. Check the endpoint and request.';
  }

  applyExtractionAndClose(): void {
    if (!this.extraction.apiResponse) return;

    const api = this.parsedApis[this.extraction.activeApiIndex!];
    if (!api) return;

    try {
      const response = JSON.parse(this.extraction.apiResponse);
      const sampleRequestData = this.extraction.hasBody
        ? JSON.parse(this.extraction.sampleRequest)
        : null;
      const fields = this.extractFieldsFromResponse(response);
      const trimmedName = this.extraction.name.trim() || api.parsed.name;
      const derivedKey = trimmedName.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
      api.name = trimmedName;
      api.parsed.name = trimmedName;
      api.parsed.key = derivedKey;
      api.parsed.id = `${derivedKey}-${api.parsed.id?.split('-').pop() || Date.now()}`;
      api.parsed.fields = fields;
      api.parsed.outputs = this.extractOutputsFromResponse(response);
      api.parsed.sampleRequest = sampleRequestData;
      api.parsed.sampleParams = { ...this.extraction.paramValues };
      api.parsed.category = this.extraction.category;
      api.jsonText = this.formatApi(api.parsed);
    } catch (e) {
      this.extraction.responseError = 'Failed to extract fields from response.';
      return;
    }

    this.closeExtractionFlyout();
  }

  private extractFieldsFromResponse(response: any): string[] {
    const fields: string[] = [];

    if (!response || typeof response !== 'object') {
      return fields;
    }

    // If response is an array, extract fields from the first element
    const data = Array.isArray(response) ? response[0] : response;

    if (!data || typeof data !== 'object') {
      return fields;
    }

    // Extract just the field names
    Object.keys(data).forEach((key) => {
      fields.push(key);
    });

    return fields;
  }

  private extractOutputsFromResponse(response: any): { name: string; type: string; description: string; path: string }[] {
    const outputs: { name: string; type: string; description: string; path: string }[] = [];

    if (!response || typeof response !== 'object') {
      return outputs;
    }

    const data = Array.isArray(response) ? response[0] : response;

    if (!data || typeof data !== 'object') {
      return outputs;
    }

    Object.entries(data).forEach(([key, value]) => {
      outputs.push({
        name: key,
        type: this.inferType(value),
        description: '',
        path: key
      });
    });

    return outputs;
  }

  private inferType(value: any): string {
    if (Array.isArray(value)) return 'array';
    if (value === null) return 'object';
    if (typeof value === 'number') return 'number';
    if (typeof value === 'boolean') return 'boolean';
    if (typeof value === 'object') return 'object';
    return 'string';
  }
}
