import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StateService } from '@core/services/state.service';
import { from, of } from 'rxjs';
import { concatMap, catchError, map } from 'rxjs/operators';

interface SwaggerApiEntry {
  selected: boolean;
  method: string;
  name: string;
  endpoint: string;
  jsonText: string;
  parsed: any;
}

interface ExtractionFlyout {
  isOpen: boolean;
  activeApiIndex: number | null;
  fullUrl: string;
  sampleRequest: string;
  category: string;
  apiResponse: string;
  responseLoading: boolean;
  responseError: string;
}

@Component({
  selector: 'app-swagger-import',
  templateUrl: './swagger-import.component.html',
  styleUrls: ['./swagger-import.component.scss']
})
export class SwaggerImportComponent implements OnInit {
  swaggerUrl: string = '';
  loading: boolean = false;
  errorMsg: string = '';
  parsedApis: SwaggerApiEntry[] = [];
  expandedIndex: number | null = null;
  importSuccess: boolean = false;
  saving: boolean = false;
  saveProgress: { current: number; total: number } = { current: 0, total: 0 };
  saveResults: { success: number; failed: number } = { success: 0, failed: 0 };
  recentUrls: { url: string; timestamp: number }[] = [];
  extraction: ExtractionFlyout = {
    isOpen: false,
    activeApiIndex: null,
    fullUrl: '',
    sampleRequest: '',
    category: '',
    apiResponse: '',
    responseLoading: false,
    responseError: ''
  };

  private readonly RECENT_URLS_KEY = 'swagger_recent_urls';
  private readonly MAX_RECENT_URLS = 10;

  constructor(
    private http: HttpClient,
    private stateService: StateService
  ) {}

  ngOnInit(): void {
    this.loadRecentUrls();
  }

  loadSwagger(): void {
    if (!this.swaggerUrl.trim()) {
      this.errorMsg = 'Please enter a Swagger URL.';
      return;
    }

    this.errorMsg = '';
    this.loading = true;
    this.parsedApis = [];

    this.http.get(this.swaggerUrl.trim()).subscribe({
      next: (spec: any) => {
        this.loading = false;
        this.parsedApis = this.parseSwagger(spec, this.swaggerUrl.trim());
        if (this.parsedApis.length === 0) {
          this.errorMsg = 'No API endpoints found in the Swagger spec.';
        } else {
          this.addRecentUrl(this.swaggerUrl.trim());
        }
      },
      error: (err) => {
        this.loading = false;
        this.errorMsg = 'Failed to fetch Swagger spec. CORS may be blocking this URL or the URL is invalid.';
      }
    });
  }

  private loadRecentUrls(): void {
    try {
      const stored = localStorage.getItem(this.RECENT_URLS_KEY);
      if (stored) {
        this.recentUrls = JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load recent URLs:', e);
      this.recentUrls = [];
    }
  }

  private addRecentUrl(url: string): void {
    const trimmedUrl = url.trim();

    // Remove if already exists (to avoid duplicates)
    this.recentUrls = this.recentUrls.filter(item => item.url !== trimmedUrl);

    // Add to front
    this.recentUrls.unshift({ url: trimmedUrl, timestamp: Date.now() });

    // Keep only the last MAX_RECENT_URLS
    if (this.recentUrls.length > this.MAX_RECENT_URLS) {
      this.recentUrls = this.recentUrls.slice(0, this.MAX_RECENT_URLS);
    }

    // Save to localStorage
    try {
      localStorage.setItem(this.RECENT_URLS_KEY, JSON.stringify(this.recentUrls));
    } catch (e) {
      console.error('Failed to save recent URLs:', e);
    }
  }

  useRecentUrl(url: string): void {
    this.swaggerUrl = url;
    this.loadSwagger();
  }

  clearRecentUrls(): void {
    this.recentUrls = [];
    try {
      localStorage.removeItem(this.RECENT_URLS_KEY);
    } catch (e) {
      console.error('Failed to clear recent URLs:', e);
    }
  }

  private parseSwagger(spec: any, swaggerUrl: string = ''): SwaggerApiEntry[] {
    const apis: SwaggerApiEntry[] = [];
    const isV3 = !!spec.openapi;

    let fallbackBaseUrl = '';
    try {
      const parsed = new URL(swaggerUrl);
      fallbackBaseUrl = parsed.origin;
    } catch {}

    let baseUrl = fallbackBaseUrl || 'https://api.example.com';
    if (isV3 && spec.servers && spec.servers.length > 0) {
      baseUrl = spec.servers[0].url;
    } else if (!isV3 && spec.schemes && spec.host) {
      baseUrl = `${spec.schemes[0]}://${spec.host}${spec.basePath || ''}`;
    }

    if (!spec.paths || typeof spec.paths !== 'object') {
      return apis;
    }

    Object.entries(spec.paths).forEach(([path, pathItem]: any) => {
      const methods = ['get', 'post', 'put', 'delete', 'patch'];
      methods.forEach((method) => {
        const operation = pathItem[method];
        if (!operation) return;

        const operationId = operation.operationId || `${method}_${path.replace(/[{}\/]/g, '_')}`;
        const api = this.buildApiObject(
          operationId,
          method.toUpperCase(),
          operation.summary || operationId,
          path,
          baseUrl,
          operation,
          isV3
        );

        apis.push({
          selected: false,
          method: method.toUpperCase(),
          name: operation.summary || operationId,
          endpoint: path,
          jsonText: this.formatApi(api),
          parsed: api
        });
      });
    });

    return apis;
  }

  private buildApiObject(
    operationId: string,
    method: string,
    summary: string,
    path: string,
    baseUrl: string,
    operation: any,
    isV3: boolean
  ): any {
    const inputs = this.extractInputMapping(operation, isV3);
    const fields: any[] = [];
    const sampleRequest = this.generateSampleRequest(inputs);

    const iconMap: { [key: string]: string } = {
      'GET': '📖',
      'POST': '➕',
      'PUT': '✏️',
      'DELETE': '🗑️',
      'PATCH': '🔧'
    };

    const keyName = operationId.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    const timestamp = Date.now();

    return {
      id: `${keyName}-${timestamp}`,
      key: keyName,
      name: summary,
      method: method,
      icon: iconMap[method] || '🔗',
      description: operation.description || '',
      category: 'Imported',
      baseUrl: baseUrl,
      endpoint: path,
      inputs: inputs,
      sampleRequest: sampleRequest,
      fields: fields,
      outputs: []
    };
  }

  private extractInputMapping(operation: any, isV3: boolean): any[] {
    const inputs: any[] = [];

    if (operation.parameters && Array.isArray(operation.parameters)) {
      operation.parameters.forEach((param: any) => {
        inputs.push({
          name: param.name,
          type: param.type || param.schema?.type || 'string',
          required: param.required || false,
          description: param.description || ''
        });
      });
    }

    if (isV3 && operation.requestBody && operation.requestBody.content) {
      const jsonContent = operation.requestBody.content['application/json'];
      if (jsonContent && jsonContent.schema && jsonContent.schema.properties) {
        Object.entries(jsonContent.schema.properties).forEach(([name, prop]: any) => {
          inputs.push({
            name: name,
            type: prop.type || 'string',
            required: (operation.requestBody.required || []).includes(name),
            description: prop.description || ''
          });
        });
      }
    }

    return inputs;
  }

  private generateSampleRequest(inputs: any[]): any {
    const sample: any = {};
    inputs.forEach((input) => {
      if (input.type === 'number' || input.type === 'integer') {
        sample[input.name] = 0;
      } else if (input.type === 'boolean') {
        sample[input.name] = true;
      } else if (input.type === 'array') {
        sample[input.name] = [];
      } else if (input.type === 'object') {
        sample[input.name] = {};
      } else {
        sample[input.name] = 'example';
      }
    });
    return sample;
  }

  formatApi(api: any): string {
    return JSON.stringify(api, null, 2);
  }

  toggleExpandedIndex(index: number): void {
    this.expandedIndex = this.expandedIndex === index ? null : index;
  }

  toggleSelectAll(event: any): void {
    const isChecked = event.target.checked;
    this.parsedApis.forEach((api) => {
      api.selected = isChecked;
    });
  }

  isAllSelected(): boolean {
    return this.parsedApis.length > 0 && this.parsedApis.every((api) => api.selected);
  }

  isPartiallySelected(): boolean {
    const selectedCount = this.parsedApis.filter((api) => api.selected).length;
    return selectedCount > 0 && selectedCount < this.parsedApis.length;
  }

  getSelectedCount(): number {
    return this.parsedApis.filter((api) => api.selected).length;
  }

  importSelected(): void {
    const selectedApis = this.parsedApis.filter((entry) => entry.selected);

    if (selectedApis.length === 0) {
      this.errorMsg = 'Please select at least one API to import.';
      return;
    }

    this.errorMsg = '';
    this.importSuccess = false;
    this.saving = true;
    this.saveProgress = { current: 0, total: selectedApis.length };
    this.saveResults = { success: 0, failed: 0 };

    from(selectedApis).pipe(
      concatMap((entry) =>
        this.createApiItem(entry.parsed.key, JSON.stringify(entry.parsed)).pipe(
          map(() => ({ success: true, key: entry.parsed.key })),
          catchError((err) => {
            const errMsg = err?.error?.message || err?.message || 'Save failed';
            console.error(`Failed to save API "${entry.parsed.key}":`, err);
            return of({ success: false, key: entry.parsed.key, error: errMsg });
          })
        )
      )
    ).subscribe({
      next: (result: any) => {
        this.saveProgress.current++;
        if (result.success) {
          this.saveResults.success++;
        } else {
          this.saveResults.failed++;
        }
      },
      complete: () => {
        this.saving = false;
        if (this.saveResults.success > 0) {
          this.importSuccess = true;
        }
        if (this.saveResults.failed > 0) {
          this.errorMsg = `${this.saveResults.failed} API(s) failed to save. Please check the console for details.`;
        }
      }
    });
  }

  private createApiItem(apiMethod: string, apiJsonText: string) {
    const collectionId = 'd10aabc6-3ccd-4bdf-94dd-5a0f7392284a';
    const payload = {
      key: apiMethod,
      documentMajorVersion: 0,
      documentMinorVersion: 0,
      scheduleStartDate: '1900-12-30T18:38:50.000Z',
      scheduleEndDate: '9999-12-30T18:30:00.000Z',
      checkedoutBy: '',
      container: ['root'],
      publishStatus: '',
      version: 0,
      collectionId,
      name: apiMethod,
      comments: '',
      groups: [],
      modifiedBy: 'asia-pacific\\swetha_selvaraj',
      createdBy: 'asia-pacific\\swetha_selvaraj',
      dynamicProperties: {
        APIMetadata: apiJsonText || ''
      }
    };
    const url = `https://csstudio-sitg3-authoringapi.pnp2.pcf.dell.com/api/${collectionId}/item/createandcheckin`;
    console.log('Saving API item:', url, payload);
    return this.http.post<any>(url, payload);
  }

  openExtractionFlyout(apiIndex: number): void {
    const api = this.parsedApis[apiIndex];
    if (!api) return;

    this.extraction.isOpen = true;
    this.extraction.activeApiIndex = apiIndex;
    this.extraction.fullUrl = api.parsed.baseUrl + api.parsed.endpoint;
    this.extraction.sampleRequest = JSON.stringify(api.parsed.sampleRequest || {}, null, 2);
    this.extraction.category = api.parsed.category || '';
    this.extraction.apiResponse = '';
    this.extraction.responseError = '';
    this.extraction.responseLoading = false;
  }

  closeExtractionFlyout(): void {
    this.extraction.isOpen = false;
    this.extraction.activeApiIndex = null;
  }

  sendRequest(): void {
    this.extraction.responseLoading = true;
    this.extraction.responseError = '';
    this.extraction.apiResponse = '';

    try {
      const sampleData = JSON.parse(this.extraction.sampleRequest);
      const api = this.parsedApis[this.extraction.activeApiIndex!];

      let url = this.extraction.fullUrl;
      let requestBody: any = sampleData;

      // For GET requests, substitute path parameters in the URL and don't send a body
      if (api.parsed.method === 'GET') {
        url = this.substitutePathParams(url, sampleData);
        requestBody = null;
      }

      this.http.request(api.parsed.method, url, { body: requestBody }).subscribe({
        next: (response: any) => {
          this.extraction.responseLoading = false;
          this.extraction.apiResponse = JSON.stringify(response, null, 2);
        },
        error: (err) => {
          this.extraction.responseLoading = false;
          this.extraction.responseError = this.getErrorMessage(err);
        }
      });
    } catch (e: any) {
      this.extraction.responseLoading = false;
      this.extraction.responseError = 'Invalid JSON in sample request: ' + e.message;
    }
  }

  private substitutePathParams(endpoint: string, data: any): string {
    let result = endpoint;
    const pathParamRegex = /\{([^}]+)\}/g;
    result = result.replace(pathParamRegex, (match, paramName) => {
      return data[paramName] !== undefined ? data[paramName] : match;
    });
    return result;
  }

  private getErrorMessage(err: any): string {
    if (err.status === 0) {
      return 'CORS error or network failure. Make sure the API has CORS enabled.';
    }
    if (err.error && typeof err.error === 'object' && err.error.message) {
      return err.error.message;
    }
    return err.statusText || 'Failed to call API. Check the endpoint and request.';
  }

  applyExtractionAndClose(): void {
    if (!this.extraction.apiResponse) return;

    const api = this.parsedApis[this.extraction.activeApiIndex!];
    if (!api) return;

    try {
      const response = JSON.parse(this.extraction.apiResponse);
      const sampleRequestData = JSON.parse(this.extraction.sampleRequest);
      const fields = this.extractFieldsFromResponse(response);
      api.parsed.fields = fields;
      api.parsed.outputs = this.extractOutputsFromResponse(response);
      api.parsed.sampleRequest = sampleRequestData;
      api.parsed.category = this.extraction.category;
      api.jsonText = this.formatApi(api.parsed);
    } catch (e) {
      this.extraction.responseError = 'Failed to extract fields from response.';
      return;
    }

    this.closeExtractionFlyout();
  }

  private extractFieldsFromResponse(response: any): string[] {
    const fields: string[] = [];

    if (!response || typeof response !== 'object') {
      return fields;
    }

    // If response is an array, extract fields from the first element
    const data = Array.isArray(response) ? response[0] : response;

    if (!data || typeof data !== 'object') {
      return fields;
    }

    // Extract just the field names
    Object.keys(data).forEach((key) => {
      fields.push(key);
    });

    return fields;
  }

  private extractOutputsFromResponse(response: any): { name: string; type: string; description: string; path: string }[] {
    const outputs: { name: string; type: string; description: string; path: string }[] = [];

    if (!response || typeof response !== 'object') {
      return outputs;
    }

    const data = Array.isArray(response) ? response[0] : response;

    if (!data || typeof data !== 'object') {
      return outputs;
    }

    Object.entries(data).forEach(([key, value]) => {
      outputs.push({
        name: key,
        type: this.inferType(value),
        description: '',
        path: key
      });
    });

    return outputs;
  }

  private inferType(value: any): string {
    if (Array.isArray(value)) return 'array';
    if (value === null) return 'object';
    if (typeof value === 'number') return 'number';
    if (typeof value === 'boolean') return 'boolean';
    if (typeof value === 'object') return 'object';
    return 'string';
  }
}
