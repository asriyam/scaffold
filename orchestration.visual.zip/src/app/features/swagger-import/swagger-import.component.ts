import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StateService } from '@core/services/state.service';

interface SwaggerApiEntry {
  selected: boolean;
  method: string;
  name: string;
  endpoint: string;
  jsonText: string;
  parsed: any;
}

@Component({
  selector: 'app-swagger-import',
  templateUrl: './swagger-import.component.html',
  styleUrls: ['./swagger-import.component.scss']
})
export class SwaggerImportComponent implements OnInit {
  swaggerUrl: string = '';
  loading: boolean = false;
  errorMsg: string = '';
  parsedApis: SwaggerApiEntry[] = [];
  expandedIndex: number | null = null;
  importSuccess: boolean = false;

  constructor(
    private http: HttpClient,
    private stateService: StateService
  ) {}

  ngOnInit(): void {}

  loadSwagger(): void {
    if (!this.swaggerUrl.trim()) {
      this.errorMsg = 'Please enter a Swagger URL.';
      return;
    }

    this.errorMsg = '';
    this.loading = true;
    this.parsedApis = [];

    this.http.get(this.swaggerUrl.trim()).subscribe({
      next: (spec: any) => {
        this.loading = false;
        this.parsedApis = this.parseSwagger(spec);
        if (this.parsedApis.length === 0) {
          this.errorMsg = 'No API endpoints found in the Swagger spec.';
        }
      },
      error: (err) => {
        this.loading = false;
        this.errorMsg = 'Failed to fetch Swagger spec. CORS may be blocking this URL or the URL is invalid.';
      }
    });
  }

  private parseSwagger(spec: any): SwaggerApiEntry[] {
    const apis: SwaggerApiEntry[] = [];
    const isV3 = !!spec.openapi;

    let baseUrl = 'https://api.example.com';
    if (isV3 && spec.servers && spec.servers.length > 0) {
      baseUrl = spec.servers[0].url;
    } else if (!isV3 && spec.schemes && spec.host) {
      baseUrl = `${spec.schemes[0]}://${spec.host}${spec.basePath || ''}`;
    }

    if (!spec.paths || typeof spec.paths !== 'object') {
      return apis;
    }

    Object.entries(spec.paths).forEach(([path, pathItem]: any) => {
      const methods = ['get', 'post', 'put', 'delete', 'patch'];
      methods.forEach((method) => {
        const operation = pathItem[method];
        if (!operation) return;

        const operationId = operation.operationId || `${method}_${path.replace(/[{}\/]/g, '_')}`;
        const api = this.buildApiObject(
          operationId,
          method.toUpperCase(),
          operation.summary || operationId,
          path,
          baseUrl,
          operation,
          isV3
        );

        apis.push({
          selected: false,
          method: method.toUpperCase(),
          name: operation.summary || operationId,
          endpoint: path,
          jsonText: this.formatApi(api),
          parsed: api
        });
      });
    });

    return apis;
  }

  private buildApiObject(
    operationId: string,
    method: string,
    summary: string,
    path: string,
    baseUrl: string,
    operation: any,
    isV3: boolean
  ): any {
    const inputs = this.extractInputs(operation, isV3);
    const fields = this.extractFields(operation, isV3);
    const sampleRequest = this.generateSampleRequest(inputs);

    const iconMap: { [key: string]: string } = {
      'GET': '📖',
      'POST': '➕',
      'PUT': '✏️',
      'DELETE': '🗑️',
      'PATCH': '🔧'
    };

    const keyName = operationId.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    const timestamp = Date.now();

    return {
      apiId: `${keyName}-${timestamp}`,
      key: keyName,
      callId: summary,
      method: method,
      icon: iconMap[method] || '🔗',
      description: operation.description || '',
      category: 'Imported',
      baseUrl: baseUrl,
      endpoint: path,
      inputs: inputs,
      sampleRequest: sampleRequest,
      fields: fields
    };
  }

  private extractInputs(operation: any, isV3: boolean): any[] {
    const inputs: any[] = [];

    if (operation.parameters && Array.isArray(operation.parameters)) {
      operation.parameters.forEach((param: any) => {
        inputs.push({
          name: param.name,
          type: param.type || param.schema?.type || 'string',
          required: param.required || false,
          description: param.description || ''
        });
      });
    }

    if (isV3 && operation.requestBody && operation.requestBody.content) {
      const jsonContent = operation.requestBody.content['application/json'];
      if (jsonContent && jsonContent.schema && jsonContent.schema.properties) {
        Object.entries(jsonContent.schema.properties).forEach(([name, prop]: any) => {
          inputs.push({
            name: name,
            type: prop.type || 'string',
            required: (operation.requestBody.required || []).includes(name),
            description: prop.description || ''
          });
        });
      }
    }

    return inputs;
  }

  private extractFields(operation: any, isV3: boolean): any[] {
    const fields: any[] = [];

    const response200 = operation.responses?.['200'];
    if (!response200) return fields;

    let schema: any = null;
    if (isV3) {
      schema = response200.content?.['application/json']?.schema;
    } else {
      schema = response200.schema;
    }

    if (!schema) return fields;

    const props = schema.properties || (schema.items?.properties);
    if (props && typeof props === 'object') {
      Object.entries(props).forEach(([name, prop]: any) => {
        fields.push({
          name: name,
          type: this.mapSchemaType(prop),
          description: prop.description || '',
          exampleValue: this.getExampleValue(prop)
        });
      });
    }

    return fields;
  }

  private mapSchemaType(prop: any): string {
    const type = prop.type || 'string';
    if (type === 'object') return 'object';
    if (type === 'array') return 'array';
    if (type === 'boolean') return 'boolean';
    if (type === 'integer' || type === 'number') return 'number';
    return 'string';
  }

  private getExampleValue(prop: any): any {
    if (prop.example !== undefined) return prop.example;
    if (prop.enum && prop.enum.length > 0) return prop.enum[0];

    const type = prop.type || 'string';
    if (type === 'number' || type === 'integer') return 0;
    if (type === 'boolean') return true;
    if (type === 'array') return [];
    if (type === 'object') return {};
    return 'example';
  }

  private generateSampleRequest(inputs: any[]): any {
    const sample: any = {};
    inputs.forEach((input) => {
      if (input.type === 'number' || input.type === 'integer') {
        sample[input.name] = 0;
      } else if (input.type === 'boolean') {
        sample[input.name] = true;
      } else if (input.type === 'array') {
        sample[input.name] = [];
      } else if (input.type === 'object') {
        sample[input.name] = {};
      } else {
        sample[input.name] = 'example';
      }
    });
    return sample;
  }

  formatApi(api: any): string {
    return JSON.stringify(api, null, 2);
  }

  toggleExpandedIndex(index: number): void {
    this.expandedIndex = this.expandedIndex === index ? null : index;
  }

  toggleSelectAll(event: any): void {
    const isChecked = event.target.checked;
    this.parsedApis.forEach((api) => {
      api.selected = isChecked;
    });
  }

  isAllSelected(): boolean {
    return this.parsedApis.length > 0 && this.parsedApis.every((api) => api.selected);
  }

  isPartiallySelected(): boolean {
    const selectedCount = this.parsedApis.filter((api) => api.selected).length;
    return selectedCount > 0 && selectedCount < this.parsedApis.length;
  }

  getSelectedCount(): number {
    return this.parsedApis.filter((api) => api.selected).length;
  }

  importSelected(): void {
    const selectedApis = this.parsedApis
      .filter((entry) => entry.selected)
      .map((entry) => {
        try {
          return JSON.parse(entry.jsonText);
        } catch {
          return entry.parsed;
        }
      });

    if (selectedApis.length === 0) {
      this.errorMsg = 'Please select at least one API to import.';
      return;
    }

    this.stateService.importApis(selectedApis);
    this.importSuccess = true;
    this.errorMsg = '';

    setTimeout(() => {
      this.importSuccess = false;
      this.parsedApis = [];
      this.swaggerUrl = '';
    }, 3000);
  }
}
