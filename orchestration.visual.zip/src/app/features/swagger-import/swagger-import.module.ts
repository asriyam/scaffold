import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { SwaggerImportRoutingModule } from './swagger-import-routing.module';
import { SwaggerImportComponent } from './swagger-import.component';

@NgModule({
  declarations: [SwaggerImportComponent],
  imports: [
    SharedModule,
    SwaggerImportRoutingModule
  ]
})
export class SwaggerImportModule { }
