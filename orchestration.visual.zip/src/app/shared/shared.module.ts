import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ButtonComponent } from './components/button/button.component';
import { ModalComponent } from './components/modal/modal.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { LoadingSpinnerComponent } from './components/loading-spinner/loading-spinner.component';
import { EmptyStateComponent } from './components/empty-state/empty-state.component';
import { FlyoutComponent } from './components/flyout/flyout.component';

@NgModule({
  declarations: [
    HeaderComponent,
    SidebarComponent,
    ButtonComponent,
    ModalComponent,
    TabsComponent,
    AccordionComponent,
    LoadingSpinnerComponent,
    EmptyStateComponent,
    FlyoutComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HeaderComponent,
    SidebarComponent,
    ButtonComponent,
    ModalComponent,
    TabsComponent,
    AccordionComponent,
    LoadingSpinnerComponent,
    EmptyStateComponent,
    FlyoutComponent
  ]
})
export class SharedModule { }
