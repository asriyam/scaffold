import { Component, Input } from '@angular/core';

export interface Tab {
  id: string;
  label: string;
  content?: string;
}

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent {
  @Input() tabs: Tab[] = [];
  activeTabId: string | null = null;

  ngOnInit(): void {
    if (this.tabs.length > 0) {
      this.activeTabId = this.tabs[0].id;
    }
  }

  selectTab(tabId: string): void {
    this.activeTabId = tabId;
  }

  isActive(tabId: string): boolean {
    return this.activeTabId === tabId;
  }
}
