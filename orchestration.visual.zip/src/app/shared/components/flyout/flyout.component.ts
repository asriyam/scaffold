import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FlyoutService, FlyoutPanel } from '@core/services/flyout.service';
import { StateService } from '@core/services/state.service';
import { AvailableDataService, AvailableSource } from '@core/services/available-data.service';
import { formatMappingExpr, formatSampleValueForDisplay } from '@core/services/mapping-expr';

@Component({
  selector: 'app-flyout',
  templateUrl: './flyout.component.html',
  styleUrls: ['./flyout.component.scss']
})
export class FlyoutComponent implements OnInit, OnDestroy {
  isOpen = false;
  currentPanel: FlyoutPanel | null = null;
  canGoBack = false;
  private destroy$ = new Subject<void>();

  // Panel-specific state
  apiSearchQuery = '';
  bucketApiIds: string[] = [];
  selectedApiId: string | null = null;
  draftConfig: any = {};
  expandedApis: Record<string, boolean> = {};

  // Builder-specific state
  builderSelectedApiId: string | null = null;
  builderSearchQuery = '';

  // New Orchestration panel state
  newOrcId = '';
  newOrcName = '';
  newOrcDescription = '';

  // Add Custom Input panel state
  customInputName = '';

  constructor(
    public flyoutService: FlyoutService,
    public stateService: StateService,
    private availableDataService: AvailableDataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.flyoutService.isOpen$.pipe(takeUntil(this.destroy$)).subscribe(open => {
      this.isOpen = open;
    });

    this.flyoutService.stack$.pipe(takeUntil(this.destroy$)).subscribe(stack => {
      this.currentPanel = stack.length > 0 ? stack[stack.length - 1] : null;
      this.canGoBack = stack.length > 1;

      if (this.currentPanel) {
        this.onPanelChanged(this.currentPanel);
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.isOpen) this.flyoutService.close();
  }

  onBackdropClick(): void {
    this.flyoutService.close();
  }

  onBack(): void {
    this.flyoutService.pop();
  }

  onClose(): void {
    this.flyoutService.close();
  }

  onPanelChanged(panel: FlyoutPanel): void {
    this.apiSearchQuery = '';
    this.builderSearchQuery = '';

    if (panel.panelId === 'browse-apis' || panel.panelId === 'configure') {
      const draft = this.stateService.getDraft();
      if (draft) {
        this.bucketApiIds = draft.bucket || [];
        this.draftConfig = { name: draft.name || '', description: draft.description || '' };
      }
    }
    if (panel.panelId === 'browse-apis-builder') {
      this.builderSelectedApiId = null;
    }
    if (panel.panelId === 'new-orchestration') {
      this.newOrcId = '';
      this.newOrcName = '';
      this.newOrcDescription = '';
    }
    if (panel.panelId === 'api-detail-builder') {
      this.onBuilderApiDetailOpen();
    }
    if (panel.panelId === 'step-configure') {
      this.onStepConfigureOpen();
    }
    if (panel.panelId === 'source-picker') {
      this.onSourcePickerOpen();
    }
    if (panel.panelId === 'source-picker-fields') {
      this.onSourcePickerFieldsOpen();
    }
    if (panel.panelId === 'step-response-mapping') {
      this.onResponseMappingOpen();
    }
    if (panel.panelId === 'orc-settings') {
      this.orcSettingsTab = 'execution';
      this.onOrcSettingsOpen();
    }
    if (panel.panelId === 'orc-output') {
      this.onOutputOpen();
    }
    if (panel.panelId === 'iteration-configure') {
      this.onIterConfigOpen();
    }
    if (panel.panelId === 'add-custom-input') {
      this.customInputName = '';
    }
    if (panel.panelId === 'field-selector') {
      const draft = this.stateService.getDraft();
      this.expandedApis = {};
      if (draft && draft.bucket) {
        draft.bucket.forEach((id: string, i: number) => { this.expandedApis[id] = i === 0; });
      }
    }
  }

  // ---- Browse APIs ----

  get filteredApis(): any[] {
    const q = this.apiSearchQuery.toLowerCase();
    return this.stateService.getAllApis().filter(api =>
      !q || api.name.toLowerCase().includes(q) || api.description.toLowerCase().includes(q)
    );
  }

  isInBucket(apiId: string): boolean {
    return this.bucketApiIds.includes(apiId);
  }

  toggleApi(apiId: string): void {
    const draft = this.stateService.getDraft();
    if (!draft) return;
    const idx = draft.bucket.indexOf(apiId);
    if (idx >= 0) {
      draft.bucket.splice(idx, 1);
      if (draft.fields) delete draft.fields[apiId];
    } else {
      draft.bucket.push(apiId);
      if (!draft.fields) draft.fields = {};
      draft.fields[apiId] = [];
    }
    this.stateService.setDraft(draft);
    this.bucketApiIds = [...draft.bucket];
  }

  viewApiDetail(apiId: string): void {
    this.flyoutService.push('api-detail', { apiId });
  }

  get browseApisBucketCount(): number {
    return this.bucketApiIds.length;
  }

  onNextFromBrowse(): void {
    const draft = this.stateService.getDraft();
    if (!draft || !draft.bucket.length) return;
    this.flyoutService.push('configure', {});
  }

  // ---- Configure ----

  saveConfigure(): void {
    const draft = this.stateService.getDraft();
    if (!draft) return;
    draft.name = this.draftConfig.name;
    draft.description = this.draftConfig.description;
    this.stateService.setDraft(draft);
    this.flyoutService.push('field-selector', {});
  }

  get configureBucketApis(): any[] {
    const draft = this.stateService.getDraft();
    if (!draft) return [];
    return draft.bucket.map((id: string) => this.stateService.getApiById(id)).filter(Boolean);
  }

  removeFromBucket(apiId: string): void {
    const draft = this.stateService.getDraft();
    if (!draft) return;
    draft.bucket = draft.bucket.filter((id: string) => id !== apiId);
    if (draft.fields) delete draft.fields[apiId];
    this.stateService.setDraft(draft);
    this.bucketApiIds = [...draft.bucket];
  }

  // ---- Field Selector ----

  get fieldSelectorApis(): any[] {
    const draft = this.stateService.getDraft();
    if (!draft) return [];
    return draft.bucket.map((id: string) => this.stateService.getApiById(id)).filter(Boolean);
  }

  isFieldSelected(apiId: string, fieldName: string): boolean {
    const draft = this.stateService.getDraft();
    if (!draft || !draft.fields) return false;
    return (draft.fields[apiId] || []).includes(fieldName);
  }

  toggleField(apiId: string, fieldName: string): void {
    const draft = this.stateService.getDraft();
    if (!draft) return;
    if (!draft.fields) draft.fields = {};
    if (!draft.fields[apiId]) draft.fields[apiId] = [];
    const idx = draft.fields[apiId].indexOf(fieldName);
    if (idx >= 0) draft.fields[apiId].splice(idx, 1);
    else draft.fields[apiId].push(fieldName);
    this.stateService.setDraft(draft);
  }

  toggleAccordion(apiId: string): void {
    this.expandedApis[apiId] = !this.expandedApis[apiId];
  }

  getSelectedFieldCount(apiId: string): number {
    const draft = this.stateService.getDraft();
    if (!draft || !draft.fields) return 0;
    return (draft.fields[apiId] || []).length;
  }

  onNextFromFields(): void {
    this.flyoutService.push('response-preview', {});
  }

  // ---- Response Preview ----

  get responsePreviewJson(): string {
    const draft = this.stateService.getDraft();
    if (!draft) return '{}';
    const mockOrc = { apis: draft.bucket, fields: draft.fields };
    const resp = this.stateService.generateResponse(mockOrc);
    return JSON.stringify(resp, null, 2);
  }

  saveAndClose(): void {
    const draft = this.stateService.getDraft();
    if (!draft) return;
    if (!draft.name || !draft.name.trim()) {
      alert('Please enter an orchestration name');
      return;
    }
    const orc = {
      id: draft.orchestrationId || 'orc_' + Date.now(),
      name: draft.name,
      description: draft.description,
      version: draft.version || '1.0.0',
      apis: draft.bucket,
      fields: draft.fields,
      steps: draft.steps || [],
      pageLayout: draft.pageLayout || [],
      createdAt: draft.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.stateService.saveOrchestration(orc);
    this.stateService.clearDraft();
    this.flyoutService.close();
  }

  // ---- Orchestration Detail ----

  get orcDetail(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'orchestration-detail') return null;
    return this.stateService.getOrchestrationById(panel.context.id);
  }

  get orcDetailApis(): any[] {
    const orc = this.orcDetail;
    if (!orc) return [];
    return (orc.apis || []).map((id: string) => this.stateService.getApiById(id)).filter(Boolean);
  }

  get orcDetailFieldCount(): number {
    const orc = this.orcDetail;
    if (!orc || !orc.fields) return 0;
    return Object.values(orc.fields).reduce((sum: number, arr: any) => sum + (arr as string[]).length, 0);
  }

  editOrcApis(orcId: string): void {
    const orc = this.stateService.getOrchestrationById(orcId);
    if (!orc) return;
    this.stateService.setDraft({
      mode: 'edit',
      orchestrationId: orc.id,
      bucket: [...orc.apis],
      name: orc.name,
      description: orc.description || '',
      version: orc.version || '1.0.0',
      fields: JSON.parse(JSON.stringify(orc.fields || {})),
      steps: orc.steps || [],
      pageLayout: orc.pageLayout || [],
      createdAt: orc.createdAt
    });
    this.flyoutService.push('browse-apis', { mode: 'edit', id: orcId });
  }

  editOrcFields(orcId: string): void {
    const orc = this.stateService.getOrchestrationById(orcId);
    if (!orc) return;
    this.stateService.setDraft({
      mode: 'edit',
      orchestrationId: orc.id,
      bucket: [...orc.apis],
      name: orc.name,
      description: orc.description || '',
      version: orc.version || '1.0.0',
      fields: JSON.parse(JSON.stringify(orc.fields || {})),
      steps: orc.steps || [],
      pageLayout: orc.pageLayout || [],
      createdAt: orc.createdAt
    });
    this.expandedApis = {};
    orc.apis.forEach((id: string, i: number) => { this.expandedApis[id] = i === 0; });
    this.flyoutService.push('field-selector', { mode: 'edit', id: orcId });
  }

  previewOrcResponse(orcId: string): void {
    this.flyoutService.push('response-preview', { id: orcId });
  }

  openPageBuilder(orcId: string): void {
    this.stateService.setCurrentId(orcId);
    this.flyoutService.close();
    this.router.navigate(['/page-builder'], { queryParams: { id: orcId } });
  }

  cloneOrc(orcId: string): void {
    this.stateService.cloneOrchestration(orcId);
    this.flyoutService.close();
    this.showToast('Orchestration cloned');
  }

  confirmDeleteOrc(orcId: string): void {
    const orc = this.stateService.getOrchestrationById(orcId);
    const name = orc ? orc.name : 'this orchestration';
    if (confirm(`Delete "${name}"? This cannot be undone.`)) {
      this.stateService.deleteOrchestration(orcId);
      this.flyoutService.close();
    }
  }

  // ---- API Detail Panel ----

  get apiDetail(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'api-detail') return null;
    return this.stateService.getApiById(panel.context.apiId);
  }

  addApiAndGoBack(apiId: string): void {
    const draft = this.stateService.getDraft();
    if (!draft) return;
    if (!draft.bucket.includes(apiId)) {
      draft.bucket.push(apiId);
      if (!draft.fields) draft.fields = {};
      draft.fields[apiId] = [];
    } else {
      draft.bucket = draft.bucket.filter((id: string) => id !== apiId);
      if (draft.fields) delete draft.fields[apiId];
    }
    this.stateService.setDraft(draft);
    this.bucketApiIds = [...draft.bucket];
    this.flyoutService.pop();
  }

  // ---- New Orchestration ----

  createOrchestration(): void {
    if (!this.newOrcName.trim()) return;
    const blank = this.stateService.createBlankOrchestration();
    const resolvedId = this.newOrcId.trim() || blank.id;
    const orc = {
      ...blank,
      id: resolvedId,
      orchestrationId: resolvedId,
      name: this.newOrcName.trim(),
      description: this.newOrcDescription.trim()
    };
    this.stateService.saveOrchestration(orc);
    this.stateService.setBuilderDraft(orc);
    this.flyoutService.close();
    this.router.navigate(['/builder', orc.id, 'edit']);
  }

  // ---- Browse APIs Builder ----

  get filteredBuilderApis(): any[] {
    const q = this.builderSearchQuery.toLowerCase();
    return this.stateService.getAllApis().filter(api =>
      !q || api.name.toLowerCase().includes(q) || api.description.toLowerCase().includes(q)
    );
  }

  selectBuilderApi(apiId: string): void {
    this.builderSelectedApiId = apiId;
  }

  viewBuilderApiDetail(): void {
    if (!this.builderSelectedApiId) return;
    const context = this.currentPanel?.context || {};
    this.flyoutService.push('api-detail-builder', {
      apiId: this.builderSelectedApiId,
      targetType: context.targetType || 'root',
      parentCallId: context.parentCallId || null
    });
  }

  // ---- API Detail Builder ----

  get builderApiDetail(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'api-detail-builder') return null;
    return this.stateService.getApiById(panel.context.apiId);
  }

  builderFieldsSelected: Record<string, boolean> = {};
  builderCallId = '';
  builderDefaultCallId = '';

  onBuilderApiDetailOpen(): void {
    const api = this.builderApiDetail;
    if (!api) return;
    this.builderDefaultCallId = api.key + '-' + Date.now().toString().slice(-4);
    this.builderCallId = this.builderDefaultCallId;
    this.builderFieldsSelected = {};
    api.fields.forEach((f: any) => { this.builderFieldsSelected[f.name] = true; });
  }

  addStepToOrchestration(): void {
    const panel = this.currentPanel;
    if (!panel) return;
    const api = this.stateService.getApiById(panel.context.apiId);
    if (!api) return;

    const draft = this.stateService.getBuilderDraft();
    if (!draft) { alert('Builder draft not initialized'); return; }

    const callId = this.builderCallId || this.builderDefaultCallId;
    if (this.stateService.getStepById(draft, callId)) {
      alert('Call ID must be unique within the orchestration');
      return;
    }

    const fields = Object.entries(this.builderFieldsSelected)
      .filter(([, v]) => v).map(([k]) => k);

    const targetType = panel.context.targetType || 'root';
    const parentCallId = panel.context.parentCallId || null;

    const stepNode: any = {
      callId,
      apiId: api.id,
      method: api.method || 'GET',
      endpoint: api.endpoint,
      fields,
      dependencies: [],
      inputMapping: {},
      responseMapping: {},
      timeout: null
    };

    if (targetType === 'dependent' && parentCallId) {
      stepNode.dependencies = [parentCallId];
      this.stateService.addRootStep(draft, stepNode);
    } else if (targetType === 'direct-child' && parentCallId) {
      this.stateService.addChildStep(draft, parentCallId, stepNode);
    } else if (targetType === 'iteration-child' && parentCallId) {
      this.stateService.addIterationStep(draft, parentCallId, stepNode);
    } else {
      this.stateService.addRootStep(draft, stepNode);
    }

    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Step Fields Panel ----

  get stepFieldsStep(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'step-fields') return null;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return null;
    return this.stateService.getStepById(draft, panel.context.callId);
  }

  get stepFieldsApi(): any {
    const step = this.stepFieldsStep;
    if (!step) return null;
    if (step.apiId) return this.stateService.getApiById(step.apiId);
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint) || null;
  }

  isStepFieldSelected(fieldName: string): boolean {
    const step = this.stepFieldsStep;
    if (!step) return false;
    return (step.fields || []).includes(fieldName);
  }

  toggleStepField(fieldName: string): void {
    const draft = this.stateService.getBuilderDraft();
    const panel = this.currentPanel;
    if (!draft || !panel) return;
    const step = this.stateService.getStepById(draft, panel.context.callId);
    if (!step) return;
    if (!step.fields) step.fields = [];
    const idx = step.fields.indexOf(fieldName);
    if (idx >= 0) step.fields.splice(idx, 1);
    else step.fields.push(fieldName);
    this.stateService.setBuilderDraft(draft);
  }

  // ---- Step Configure Panel ----

  get stepConfigureStep(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'step-configure') return null;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return null;
    return this.stateService.getStepById(draft, panel.context.callId);
  }

  get stepConfigureApi(): any {
    const step = this.stepConfigureStep;
    if (!step) return null;
    if (step.apiId) return this.stateService.getApiById(step.apiId);
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint) || null;
  }

  stepConfigDeps: string[] = [];
  stepConfigTimeoutReadMs: number | null = null;
  stepConfigCallId = '';

  onStepConfigureOpen(): void {
    const step = this.stepConfigureStep;
    if (!step) return;
    this.stepConfigDeps = [...(step.dependencies || [])];
    this.stepConfigTimeoutReadMs = step.timeout?.readMs ?? null;
    this.stepConfigCallId = step.callId;
  }

  get stepConfigAvailableDeps(): string[] {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return [];
    return this.stateService.getAllCallIds(draft)
      .filter(id => id !== this.stepConfigCallId && !this.stepConfigDeps.includes(id));
  }

  addStepDep(depCallId: string): void {
    if (!this.stepConfigDeps.includes(depCallId)) this.stepConfigDeps = [...this.stepConfigDeps, depCallId];
  }

  removeStepDep(depCallId: string): void {
    this.stepConfigDeps = this.stepConfigDeps.filter(d => d !== depCallId);
  }

  saveStepConfigure(): void {
    const draft = this.stateService.getBuilderDraft();
    const panel = this.currentPanel;
    if (!draft || !panel) return;
    const step = this.stateService.getStepById(draft, panel.context.callId);
    if (!step) return;
    step.dependencies = [...this.stepConfigDeps];
    step.timeout = this.stepConfigTimeoutReadMs != null ? { readMs: this.stepConfigTimeoutReadMs } : null;
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Source Picker (input-mapping replacement) ----

  sourcePickerSources: AvailableSource[] = [];
  sourcePickerSearch = '';
  sourcePickerFixedValue = '';
  sourcePickerFieldFilter = '';

  saveCustomInput(): void {
    const name = this.customInputName.trim();
    if (!name) return;
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'add-custom-input') return;
    const callId = panel.context?.callId;
    if (!callId) return;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const step = this.stateService.getStepById(draft, callId);
    if (!step) return;
    if (!step.inputMapping) step.inputMapping = {};
    if (!Object.prototype.hasOwnProperty.call(step.inputMapping, name)) {
      step.inputMapping[name] = '';
      this.stateService.setBuilderDraft(draft);
    }
    this.customInputName = '';
    this.flyoutService.open('source-picker', { callId, paramName: name, paramIn: 'body' });
  }

  onSourcePickerOpen(): void {
    this.sourcePickerSearch = '';
    this.sourcePickerFixedValue = '';
    const panel = this.currentPanel;
    const draft = this.stateService.getBuilderDraft();
    if (!panel || !draft) { this.sourcePickerSources = []; return; }
    this.sourcePickerSources = this.availableDataService.getAvailableSources(draft, panel.context.callId);
  }

  onSourcePickerFieldsOpen(): void {
    this.sourcePickerFieldFilter = '';
  }

  get sourcePickerParamName(): string {
    return this.currentPanel?.context?.paramName || '';
  }

  get sourcePickerInputType(): string {
    const panel = this.currentPanel;
    if (!panel) return '';
    const draft = this.stateService.getBuilderDraft();
    const step = draft ? this.stateService.getStepById(draft, panel.context.callId) : null;
    const api = step?.apiId ? this.stateService.getApiById(step.apiId) : null;
    const input = api?.inputs?.find((i: any) => i.name === panel.context.paramName);
    return input?.type || '';
  }

  get filteredSourcePickerSources(): AvailableSource[] {
    const q = this.sourcePickerSearch.trim().toLowerCase();
    if (!q) return this.sourcePickerSources;
    return this.sourcePickerSources.filter(s => {
      const text = (s as any).label + ' ' + ((s as any).description || '') + ' ' + ((s as any).endpoint || '');
      return text.toLowerCase().includes(q);
    });
  }

  sourcePickerSourceIcon(source: AvailableSource): string {
    if (source.kind === 'flowInput') return '⚡';
    if (source.kind === 'loopItem') return '🔄';
    return '📦';
  }

  sourcePickerSourceFieldCount(source: AvailableSource): number {
    if (source.kind === 'flowInput') return source.flowFields.length;
    return source.fields.length;
  }

  selectSourcePickerSource(source: AvailableSource): void {
    this.flyoutService.push('source-picker-fields', {
      callId: this.currentPanel?.context?.callId,
      paramName: this.currentPanel?.context?.paramName,
      source,
    });
  }

  get sourcePickerActiveSource(): AvailableSource | null {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'source-picker-fields') return null;
    return panel.context.source as AvailableSource;
  }

  get sourcePickerActiveFields(): { name: string; type?: string; exampleValue?: any }[] {
    const src = this.sourcePickerActiveSource;
    if (!src) return [];
    const fields: any[] = src.kind === 'flowInput' ? src.flowFields : src.fields;
    const q = this.sourcePickerFieldFilter.trim().toLowerCase();
    if (!q) return fields;
    return fields.filter((f: any) => f.name.toLowerCase().includes(q));
  }

  get sourcePickerSampleRequestJson(): string {
    const src = this.sourcePickerActiveSource;
    if (!src || src.kind !== 'step') return '';
    return JSON.stringify(src.sampleRequest || {}, null, 2);
  }

  formatFieldSample(value: any): string {
    return formatSampleValueForDisplay(value);
  }

  selectSourcePickerField(field: { name: string }): void {
    const src = this.sourcePickerActiveSource;
    const panel = this.currentPanel;
    if (!src || !panel) return;
    let expr: any;
    if (src.kind === 'flowInput') {
      expr = formatMappingExpr({ kind: 'flowInput', path: field.name });
    } else if (src.kind === 'loopItem') {
      expr = formatMappingExpr({ kind: 'loopItem', path: field.name });
    } else {
      expr = formatMappingExpr({ kind: 'stepOutput', callId: src.callId, path: field.name });
    }
    this.writeMappingValueAndClose(panel.context.callId, panel.context.paramName, expr);
  }

  applySourcePickerFixedValue(): void {
    const panel = this.currentPanel;
    if (!panel) return;
    const raw = this.sourcePickerFixedValue;
    let value: any = raw;
    const trimmed = raw.trim();
    if (trimmed !== '') {
      try {
        value = JSON.parse(trimmed);
      } catch {
        value = raw;
      }
    }
    this.writeMappingValueAndClose(panel.context.callId, panel.context.paramName, value);
  }

  private writeMappingValueAndClose(callId: string, paramName: string, value: any): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const step = this.stateService.getStepById(draft, callId);
    if (!step) return;
    if (!step.inputMapping) step.inputMapping = {};
    const paramIn = this.currentPanel?.context?.paramIn || 'body';
    step.inputMapping[paramName] = { $source: value, $in: paramIn };
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Response Mapping Panel ----

  responseMappingRows: { key: string; mode: 'simple' | 'map'; valueExpr: string; transformExpr: string; mapSource: string; mapFields: { output: string; expr: string }[] }[] = [];

  get responseMappingStep(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'step-response-mapping') return null;
    const draft = this.stateService.getBuilderDraft();
    return draft ? this.stateService.getStepById(draft, panel.context.callId) : null;
  }

  onResponseMappingOpen(): void {
    const step = this.responseMappingStep;
    if (!step) { this.responseMappingRows = []; return; }
    const map = step.responseMapping || {};
    this.responseMappingRows = Object.entries(map).map(([key, val]: [string, any]) => {
      if (val && typeof val === 'object' && '$map' in val) {
        const m = val.$map;
        const mapFields = Object.entries(m)
          .filter(([k]) => k !== '$source')
          .map(([k, v]) => ({ output: k, expr: String(v) }));
        return { key, mode: 'map' as const, valueExpr: '', transformExpr: '', mapSource: m.$source || '', mapFields };
      }
      if (val && typeof val === 'object' && '$source' in val) {
        return { key, mode: 'simple' as const, valueExpr: val.$source || '', transformExpr: val.$transform ? JSON.stringify(val.$transform) : '', mapSource: '', mapFields: [] };
      }
      return { key, mode: 'simple' as const, valueExpr: String(val), transformExpr: '', mapSource: '', mapFields: [] };
    });
  }

  addResponseMappingRow(): void {
    this.responseMappingRows = [...this.responseMappingRows, { key: '', mode: 'simple', valueExpr: '', transformExpr: '', mapSource: '', mapFields: [] }];
  }

  removeResponseMappingRow(i: number): void {
    this.responseMappingRows = this.responseMappingRows.filter((_, idx) => idx !== i);
  }

  addMapField(row: any): void {
    row.mapFields = [...(row.mapFields || []), { output: '', expr: '' }];
  }

  removeMapField(row: any, i: number): void {
    row.mapFields = row.mapFields.filter((_: any, idx: number) => idx !== i);
  }

  saveResponseMapping(): void {
    const draft = this.stateService.getBuilderDraft();
    const panel = this.currentPanel;
    if (!draft || !panel) return;
    const step = this.stateService.getStepById(draft, panel.context.callId);
    if (!step) return;
    const map: any = {};
    for (const row of this.responseMappingRows) {
      if (!row.key.trim()) continue;
      if (row.mode === 'map') {
        const mapObj: any = { $source: row.mapSource };
        (row.mapFields || []).forEach((f: any) => { if (f.output) mapObj[f.output] = f.expr; });
        map[row.key] = { $map: mapObj };
      } else {
        if (row.transformExpr) {
          let t: any = row.transformExpr;
          try { t = JSON.parse(row.transformExpr); } catch {}
          map[row.key] = { $source: row.valueExpr, $transform: t };
        } else {
          map[row.key] = row.valueExpr;
        }
      }
    }
    step.responseMapping = map;
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Orchestration Settings Panel ----

  orcSettingsTab = 'execution';
  orcExec: any = {};
  orcDefaults: any = {};
  orcErrorHandling: any = {};
  orcObservability: any = {};
  orcVariableRows: { key: string; value: string }[] = [];
  orcContextRows: { key: string; value: string }[] = [];
  orcRequestRows: { key: string; value: string }[] = [];
  orcRetryableCodes = '';
  orcMaskFields = '';

  onOrcSettingsOpen(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.orcExec = JSON.parse(JSON.stringify(draft.execution || { mode: 'parallel', maxParallel: 20, continueOnError: true }));
    this.orcDefaults = JSON.parse(JSON.stringify(draft.defaults || { cache: { enabled: true, ttlSeconds: 300 }, retryPolicy: { maxRetries: 0, backoff: 'exponential', retryableStatusCodes: [] }, timeout: { connectMs: 1000, readMs: 10000 } }));
    this.orcErrorHandling = JSON.parse(JSON.stringify(draft.errorHandling || { continueOnError: true, globalFallback: { status: 'PARTIAL_SUCCESS' } }));
    this.orcObservability = JSON.parse(JSON.stringify(draft.observability || { logging: { enabled: false, logRequest: false, logResponse: false, maskFields: [] }, metrics: { enabled: false }, tracing: { enabled: false } }));
    this.orcVariableRows = Object.entries(draft.variables || {}).map(([k, v]) => ({ key: k, value: String(v) }));
    this.orcContextRows = Object.entries(draft.context || {}).map(([k, v]) => ({ key: k, value: String(v) }));
    this.orcRequestRows = Object.entries(draft.requestData || {}).map(([k, v]) => ({ key: k, value: String(v) }));
    this.orcRetryableCodes = (this.orcDefaults.retryPolicy?.retryableStatusCodes || []).join(', ');
    this.orcMaskFields = (this.orcObservability.logging?.maskFields || []).join(', ');
  }

  addVariableRow(): void { this.orcVariableRows = [...this.orcVariableRows, { key: '', value: '' }]; }
  removeVariableRow(i: number): void { this.orcVariableRows = this.orcVariableRows.filter((_, idx) => idx !== i); }
  addContextRow(): void { this.orcContextRows = [...this.orcContextRows, { key: '', value: '' }]; }
  removeContextRow(i: number): void { this.orcContextRows = this.orcContextRows.filter((_, idx) => idx !== i); }
  addRequestRow(): void { this.orcRequestRows = [...this.orcRequestRows, { key: '', value: '' }]; }
  removeRequestRow(i: number): void { this.orcRequestRows = this.orcRequestRows.filter((_, idx) => idx !== i); }

  saveOrcSettings(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    this.orcDefaults.retryPolicy.retryableStatusCodes = this.orcRetryableCodes.split(',').map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n));
    this.orcObservability.logging.maskFields = this.orcMaskFields.split(',').map(s => s.trim()).filter(Boolean);
    const variables: any = {};
    this.orcVariableRows.filter(r => r.key.trim()).forEach(r => { variables[r.key] = isNaN(Number(r.value)) ? r.value : Number(r.value); });
    const context: any = {};
    this.orcContextRows.filter(r => r.key.trim()).forEach(r => { context[r.key] = r.value; });
    const requestData: any = {};
    this.orcRequestRows.filter(r => r.key.trim()).forEach(r => { requestData[r.key] = r.value; });
    this.stateService.updateOrcSettings(draft, {
      execution: this.orcExec,
      defaults: this.orcDefaults,
      errorHandling: this.orcErrorHandling,
      observability: this.orcObservability,
      variables,
      context,
      requestData
    });
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Output Mapping Panel ----

  outputRows: { key: string; valueExpr: string; isExpr: boolean }[] = [];

  onOutputOpen(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) { this.outputRows = []; return; }
    const out = draft.output || {};
    this.outputRows = Object.entries(out).map(([key, val]: [string, any]) => {
      if (val && typeof val === 'object' && '$expr' in val) {
        return { key, valueExpr: val.$expr || '', isExpr: true };
      }
      return { key, valueExpr: String(val), isExpr: false };
    });
  }

  addOutputRow(): void { this.outputRows = [...this.outputRows, { key: '', valueExpr: '', isExpr: false }]; }
  removeOutputRow(i: number): void { this.outputRows = this.outputRows.filter((_, idx) => idx !== i); }

  get outputAvailableSources(): string[] {
    const draft = this.stateService.getBuilderDraft();
    return draft ? this.stateService.getAllCallIds(draft) : [];
  }

  saveOutputMapping(): void {
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return;
    const out: any = {};
    for (const row of this.outputRows) {
      if (!row.key.trim()) continue;
      out[row.key] = row.isExpr ? { $expr: row.valueExpr } : row.valueExpr;
    }
    this.stateService.updateOutputMapping(draft, out);
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Iteration Configure Panel ----

  get iterConfigStep(): any {
    const panel = this.currentPanel;
    if (!panel || panel.panelId !== 'iteration-configure') return null;
    const draft = this.stateService.getBuilderDraft();
    if (!draft) return null;
    return this.stateService.getStepById(draft, panel.context.callId);
  }

  get iterConfigApi(): any {
    const step = this.iterConfigStep;
    if (!step) return null;
    if (step.apiId) return this.stateService.getApiById(step.apiId);
    return this.stateService.getAllApis().find((a: any) => a.endpoint === step.endpoint) || null;
  }

  iterSource = '';
  iterItemVar = 'item';
  iterMode = 'parallel';
  iterMax = 20;

  onIterConfigOpen(): void {
    const step = this.iterConfigStep;
    if (!step) return;
    const iter = step.iteration || {};
    this.iterSource = iter.source || '';
    this.iterItemVar = iter.itemVariable || 'item';
    this.iterMode = iter.execution?.mode || 'parallel';
    this.iterMax = iter.execution?.maxParallel || 20;
  }

  saveIterConfig(): void {
    const draft = this.stateService.getBuilderDraft();
    const panel = this.currentPanel;
    if (!draft || !panel) return;
    this.stateService.setIteration(draft, panel.context.callId, {
      source: this.iterSource,
      itemVariable: this.iterItemVar,
      execution: { mode: this.iterMode, maxParallel: this.iterMax }
    });
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  removeIterConfig(): void {
    const draft = this.stateService.getBuilderDraft();
    const panel = this.currentPanel;
    if (!draft || !panel) return;
    this.stateService.removeIteration(draft, panel.context.callId);
    this.stateService.setBuilderDraft(draft);
    this.flyoutService.close();
  }

  // ---- Toast ----

  showToast(message: string): void {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  // ---- Mini Wizard steps ----

  getMiniWizardSteps(panelId: string): { label: string; active: boolean }[] {
    const allSteps = [
      { id: 'browse-apis', label: 'Browse' },
      { id: 'configure', label: 'Configure' },
      { id: 'field-selector', label: 'Fields' },
      { id: 'response-preview', label: 'Preview' }
    ];
    const currentIndex = allSteps.findIndex(s => s.id === panelId);
    return allSteps.map((s, i) => ({ label: s.label, active: i === currentIndex }));
  }

  trackByApiId(_: number, api: any): string {
    return api.id;
  }
}
