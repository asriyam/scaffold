import { Component, OnInit } from '@angular/core';
import { MockDataService } from '@core/services/mock-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  apiCategories$ = this.mockDataService.getApiCategories();

  constructor(private mockDataService: MockDataService) {}

  ngOnInit(): void {}
}
