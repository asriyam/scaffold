import { Component, OnInit } from '@angular/core';
import { MockDataService } from '@core/services/mock-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  apiCategories$ = this.mockDataService.getApiCategories();
  isLanguageDropdownOpen = false;

  constructor(private mockDataService: MockDataService) {}

  ngOnInit(): void {}

  toggleLanguageDropdown(event: Event): void {
    event.stopPropagation();
    this.isLanguageDropdownOpen = !this.isLanguageDropdownOpen;
  }

  closeLanguageDropdown(): void {
    this.isLanguageDropdownOpen = false;
  }
}
