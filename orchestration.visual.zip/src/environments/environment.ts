export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000',
  useMockData: true,
  cmxStudioBaseUrl: 'https://cnsnwg4cmxux01.amer.dell.com'
};
