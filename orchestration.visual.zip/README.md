# UI Orchestration Builder

A production-grade Angular application for building API orchestration configurations through a visual interface. This tool enables semi-technical users and UX designers to browse API response schemas, select fields, and create orchestration configurations without writing code.

## Overview

The UI Orchestration Builder provides a user-friendly interface for:

- **API Marketplace**: Browse and explore available APIs with their schemas
- **Orchestration Builder**: Visually compose API calls with field selection and dependency management
- **Orchestration Management**: Create, edit, and manage orchestration configurations
- **Page Builder**: Compose pages using webparts with data binding to orchestrations

## Features

- **Visual API Browser**: Explore API schemas with field selection
- **Drag-and-Drop Composition**: Build orchestrations using intuitive drag-and-drop
- **Real-time JSON Preview**: See generated orchestration configuration in real-time
- **Field Dependency Tracking**: Automatically manage relationships between API fields
- **Mock Data Strategy**: Comprehensive mock data for development without backend
- **Modular Architecture**: Feature-based module structure for scalability
- **Type-Safe**: Full TypeScript support with strict type checking

## Technology Stack

- **Angular 17**: Modern Angular framework with standalone components
- **TypeScript 5.2**: Strict type checking and enhanced developer experience
- **RxJS**: Reactive programming for state management
- **SCSS**: Styling with design tokens
- **Angular CDK**: Drag-and-drop and other UI primitives

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- Angular CLI 17+

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

3. Navigate to `http://localhost:4200/`

### Build for Production

```bash
npm run build
```

The build artifacts will be stored in the `dist/` directory.

## Project Structure

```
src/
├── app/
│   ├── core/
│   │   ├── services/        # Core services (MockDataService, etc.)
│   │   ├── guards/          # Route guards
│   │   ├── interceptors/    # HTTP interceptors
│   │   └── mockdata/        # Mock data files
│   ├── shared/
│   │   ├── components/      # Reusable components
│   │   ├── pipes/           # Custom pipes
│   │   └── directives/      # Custom directives
│   ├── features/
│   │   ├── orchestration/   # Orchestration management
│   │   ├── builder/         # Orchestration builder
│   │   ├── api-marketplace/ # API marketplace
│   │   └── page-builder/    # Page builder
│   ├── models/              # Data models
│   ├── app.component.ts     # Root component
│   ├── app.module.ts        # Root module
│   └── app-routing.module.ts # Routing configuration
├── assets/
│   └── styles/              # Global styles
└── environments/            # Environment configurations
```

## Mock Data

The application includes comprehensive mock data for development:

- **6 APIs**: Category, Products, Ratings, Inventory, Shipping, Users
- **3 Orchestrations**: Laptop Catalog, Home Deals, Gaming Category
- **8 Webparts**: Hero Banner, Filter Navigation, Results Bar, Product Grid, Product Card, Rating Summary, Product Stack, Compare Bar

Mock data is provided through `MockDataService` with an Observable-based interface for easy migration to real APIs.

## Development Workflow

1. **Phase 1: Foundation** - Core structure, routing, mock data integration
2. **Phase 2: API Marketplace** - API browsing, filtering, detail views
3. **Phase 3: Builder** - Visual composition, field selection, JSON preview
4. **Phase 4: Orchestration Management** - CRUD operations, versioning
5. **Phase 5: Page Builder** - Webparts, data binding, page composition

## Testing

```bash
# Run unit tests
npm test

# Run e2e tests
npm run e2e
```

## Migration to Real API

When ready to connect to a real backend:

1. Create API services (e.g., `ApiCatalogService`, `OrchestrationService`)
2. Replace `MockDataService` injection with new services
3. Ensure new services return the same Observable-based interface
4. Update environment configurations to point to real API endpoints
5. Remove or disable mock data usage

## Contributing

This is an internal Dell project. Please follow the established development practices and coding standards.

## License

Internal use only.

## Support

For questions or issues, please contact the development team.
