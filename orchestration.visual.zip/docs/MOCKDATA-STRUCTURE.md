# Mock Data Structure for Angular Implementation

## Overview

This document describes the mock data structure created for the API Orchestration Builder Angular application. The mock data is based on the OrcStudio implementation plans and provides realistic, production-like data for development and testing.

## File Organization

```
src/app/
├── core/
│   ├── mockdata/
│   │   ├── apis.ts                 # 6 API configurations
│   │   ├── orchestrations.ts       # 3 sample orchestrations
│   │   ├── webparts.ts             # 8 webpart components
│   │   ├── index.ts                # Barrel export
│   │   └── README.md               # Detailed mockdata documentation
│   └── services/
│       └── mock-data.service.ts    # Service providing mock data access
├── models/
│   ├── api.model.ts                # Api, ApiInput, ApiField interfaces
│   ├── orchestration.model.ts      # Orchestration, ApiCall interfaces
│   ├── webpart.model.ts            # Webpart, Page interfaces
│   └── index.ts                    # Barrel export
```

## Data Models

### API Model (`api.model.ts`)

```typescript
interface Api {
  id: string;                        // Unique identifier
  name: string;                      // Display name
  endpoint: string;                  // REST endpoint
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  description: string;               // Human-readable description
  category: string;                  // Category for filtering
  inputs: ApiInput[];                // Required/optional inputs
  outputs: ApiField[];               // Response fields
  examples?: ApiExample[];           // Sample requests/responses
}

interface ApiInput {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  required: boolean;
  description?: string;
  example?: any;
}

interface ApiField {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  description?: string;
  path?: string;                     // JSON path in response
  required?: boolean;
}

interface ApiExample {
  name: string;
  inputs: Record<string, any>;
  output: Record<string, any>;
}
```

### Orchestration Model (`orchestration.model.ts`)

```typescript
interface Orchestration {
  id: string;
  name: string;
  description?: string;
  status: 'draft' | 'active' | 'published';
  version: string;
  createdAt: Date;
  updatedAt: Date;
  apiCalls: ApiCall[];               // Composition steps
  outputMapping: OutputMapping;      // Response transformation
}

interface ApiCall {
  callId: string;                    // Unique call identifier
  apiId: string;                     // Reference to API
  endpoint: string;
  fields: string[];                  // Selected fields
  inputs?: Record<string, any>;
  iteration?: IterationConfig;       // For array iteration
  parallelWith?: string[];           // Parallel execution
  dependsOn?: string[];              // Sequential dependencies
}

interface IterationConfig {
  arrayField: string;                // Field to iterate over
  childCalls: ApiCall[];             // Calls for each item
}
```

### Webpart Model (`webpart.model.ts`)

```typescript
interface Webpart {
  id: string;
  type: 'hero' | 'filter' | 'results' | 'grid' | 'card' | 'rating' | 'stack' | 'compare';
  name: string;
  description: string;
  icon?: string;
  properties: WebpartProperty[];
  dataBindings: DataBinding[];
}

interface WebpartProperty {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'select';
  value?: any;
  options?: any[];
}

interface DataBinding {
  propertyName: string;
  dataPath: string;                  // Path in orchestration response
}
```

## Mock Data Contents

### APIs (6 total)

#### 1. Category API
- **Endpoint**: `GET /api/v1/categories/{categoryId}/products`
- **Purpose**: Browse product categories
- **Fields**: id, name, slug, description, products, totalCount, metadata
- **Example**: Laptops category with product references

#### 2. Products API
- **Endpoint**: `GET /api/v1/products/{productId}`
- **Purpose**: Fetch product details
- **Fields**: id, name, price, salePrice, badge, images, specifications, availability, etc.
- **Example**: Dell XPS 15 with full specs

#### 3. Ratings API
- **Endpoint**: `GET /api/v1/products/{productId}/ratings`
- **Purpose**: Get customer ratings and reviews
- **Fields**: averageRating, reviewCount, ratingDistribution, topReviews
- **Example**: XPS 15 with 4.7 rating and 2841 reviews

#### 4. Inventory API
- **Endpoint**: `GET /api/v1/inventory/{productId}`
- **Purpose**: Real-time stock information
- **Fields**: stock, available, warehouseId
- **Example**: 1250 units in Austin warehouse

#### 5. Shipping API
- **Endpoint**: `POST /api/v1/shipping/calculate`
- **Purpose**: Shipping cost and delivery estimates
- **Fields**: cost, days, express, shippingType
- **Example**: $29.99 for 3-day standard shipping

#### 6. Users API
- **Endpoint**: `GET /api/v1/users/{userId}`
- **Purpose**: User profile and order history
- **Fields**: userId, email, firstName, lastName, tier, orders, savedAddresses, preferences
- **Example**: John Doe with Gold tier status

### Orchestrations (3 total)

#### 1. Laptop Catalog Page (Active)
- **Status**: Active
- **APIs**: Category, Products, Ratings
- **Pattern**: Parent call with parallel child calls
- **Use Case**: Product listing page with ratings
- **Composition**:
  1. Fetch category products
  2. For each product, fetch details and ratings in parallel

#### 2. Home Deals Rotator (Draft)
- **Status**: Draft
- **APIs**: Products, Shipping
- **Pattern**: Independent parallel calls
- **Use Case**: Featured deals carousel
- **Composition**:
  1. Fetch product details
  2. Calculate shipping costs (independent)

#### 3. Gaming Category Page (Active)
- **Status**: Active
- **APIs**: Category, Products, Inventory
- **Pattern**: Sequential dependent calls
- **Use Case**: Category page with inventory
- **Composition**:
  1. Fetch category
  2. Fetch products (depends on category)
  3. Fetch inventory (depends on products)

### Webparts (8 total)

| ID | Type | Name | Purpose |
|----|------|------|---------|
| hero-banner | hero | Hero Banner | Large banner with heading and CTA |
| filter-nav | filter | Filter Navigation | Sidebar with filters |
| results-bar | results | Results Bar | Result count and sorting |
| product-grid | grid | Product Grid | Responsive product grid |
| product-card | card | Product Card | Individual product card |
| rating-summary | rating | Rating Summary | Rating and reviews display |
| product-stack | stack | Product Stack | Vertical product details |
| compare-bar | compare | compare | Side-by-side comparison |

## MockDataService API

The `MockDataService` provides Observable-based access to all mock data:

```typescript
// Get all APIs
getApis(): Observable<Api[]>

// Get single API
getApiById(id: string): Observable<Api | undefined>

// Get APIs by category
getApisByCategory(category: string): Observable<Api[]>

// Get API categories
getApiCategories(): Observable<string[]>

// Search APIs
searchApis(query: string): Observable<Api[]>

// Get all orchestrations
getOrchestrations(): Observable<Orchestration[]>

// Get single orchestration
getOrchestrationById(id: string): Observable<Orchestration | undefined>

// Get orchestrations by status
getOrchestrationsByStatus(status: 'draft' | 'active' | 'published'): Observable<Orchestration[]>

// Get all webparts
getWebparts(): Observable<Webpart[]>

// Get single webpart
getWebpartById(id: string): Observable<Webpart | undefined>

// Get webparts by type
getWebpartsByType(type: string): Observable<Webpart[]>

// Get field types for API
getApiFieldTypes(apiId: string): Observable<Record<string, string>>

// Get sample response
getApiSampleResponse(apiId: string): Observable<Record<string, any> | null>
```

## Usage Examples

### In Components

```typescript
import { MockDataService } from '@core/services/mock-data.service';

@Component({
  selector: 'app-api-browser',
  templateUrl: './api-browser.component.html'
})
export class ApiBrowserComponent implements OnInit {
  apis$ = this.mockDataService.getApis();
  categories$ = this.mockDataService.getApiCategories();

  constructor(private mockDataService: MockDataService) {}

  ngOnInit() {
    // Data is automatically available via async pipe
  }

  searchApis(query: string) {
    return this.mockDataService.searchApis(query);
  }
}
```

### In Services

```typescript
import { MockDataService } from '@core/services/mock-data.service';

@Injectable({ providedIn: 'root' })
export class BuilderStateService {
  constructor(private mockDataService: MockDataService) {}

  loadOrchestration(id: string) {
    return this.mockDataService.getOrchestrationById(id);
  }
}
```

## Migration to Real API

When ready to connect to a real backend API:

### Step 1: Create Real API Service

```typescript
// api-catalog.service.ts
@Injectable({ providedIn: 'root' })
export class ApiCatalogService {
  constructor(private http: HttpClient) {}

  getApis(): Observable<Api[]> {
    return this.http.get<Api[]>('/api/v1/api-catalog/apis');
  }

  getApiById(id: string): Observable<Api | undefined> {
    return this.http.get<Api>(`/api/v1/api-catalog/apis/${id}`);
  }

  // ... other methods
}
```

### Step 2: Update Injection

```typescript
// Before (mock)
constructor(private dataService: MockDataService) {}

// After (real API)
constructor(private dataService: ApiCatalogService) {}
```

### Step 3: Update Environment Config

```typescript
// environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://api.example.com',
  useMockData: false
};
```

## Data Consistency

All mock data follows these principles:

1. **Realistic Values**: Uses actual Dell product names and specifications
2. **Consistent IDs**: IDs follow naming conventions (e.g., `xps15-001`, `cat-laptops-001`)
3. **Complete Examples**: Each API includes sample request/response pairs
4. **Nested Structures**: Reflects real API response nesting
5. **Type Safety**: All data matches TypeScript interfaces

## Testing with Mock Data

Mock data is ideal for:

- **Unit Tests**: Consistent, predictable test data
- **Component Tests**: Realistic UI testing without backend
- **Integration Tests**: Test data flow between components
- **E2E Tests**: Full user journey testing
- **Performance Tests**: Realistic data structures and sizes
- **Demos**: Show features to stakeholders

## Notes

- Mock data is stored in TypeScript files, not JSON
- All data is exported as constants for tree-shaking
- Service provides Observable interface for consistency
- Easy to extend with additional APIs or orchestrations
- No database or external dependencies required
