# Spec: .NET Core Test Service for Orchestration Builder

## Context

The orchestration builder supports 4 node kinds: **root** (parallel top-level), **dependent** (waits on other steps via `dependencies[]`), **child** (nested under a parent step in `children.steps[]`), and **iteration** (loops over an array in `iteration.steps[]`). The builder is tested by importing a real Swagger spec and wiring steps together in the UI.

This service provides a realistic e-commerce product catalog domain with endpoints designed to exercise all four node kinds and their combinations. All data is in-memory (no database) for portability.

---

## Project Setup

- **Framework**: .NET 8 Web API (minimal hosting model)
- **Package**: `Swashbuckle.AspNetCore` for OpenAPI/Swagger UI at `/swagger`
- **Data**: Static in-memory seed data (no EF, no DB)
- **Port**: `https://localhost:5001` (Swagger JSON at `/swagger/v1/swagger.json`)

### Project Structure
```
OrchestrationTestApi/
├── Program.cs
├── Controllers/
│   ├── CategoriesController.cs
│   ├── ProductsController.cs
│   ├── InventoryController.cs
│   ├── UsersController.cs
│   ├── OrdersController.cs
│   ├── CartController.cs
│   └── RecommendationsController.cs
├── Models/
│   ├── Category.cs
│   ├── Product.cs
│   ├── Pricing.cs
│   ├── Specification.cs
│   ├── Inventory.cs
│   ├── User.cs
│   ├── Order.cs
│   └── CartRequest.cs
└── Data/
    └── SeedData.cs
```

---

## Domain Models

```csharp
// Category.cs
record Category(int Id, string Name, string Description, int ProductCount);

// Product.cs
record Product(int Id, string Name, string Description, int CategoryId,
               decimal Price, double Rating, string[] Tags);

// Pricing.cs
record Pricing(int ProductId, decimal BasePrice, decimal DiscountedPrice,
               string Currency, DateOnly ValidUntil);

// Specification.cs
record SpecEntry(string Key, string Value);
record Specification(int ProductId, SpecEntry[] Specs);

// Inventory.cs
record Inventory(int ProductId, int Quantity, string WarehouseId,
                 bool Available, DateTime LastUpdated);

// User.cs
record UserPreferences(string Theme, string[] Interests);
record User(int Id, string Name, string Email, string Tier,
            UserPreferences Preferences);

// Order.cs
record OrderItem(int ProductId, int Quantity, decimal UnitPrice);
record Order(int Id, int UserId, string Status,
             OrderItem[] Items, decimal Total, DateTime CreatedAt);

// CartRequest.cs
record CartLineItem(int ProductId, int Quantity);
record CartRequest(CartLineItem[] Items);
record CartBreakdown(int ProductId, string Name, int Quantity,
                     decimal UnitPrice, decimal LineTotal);
record CartResponse(decimal Subtotal, decimal Tax, decimal Total,
                    CartBreakdown[] Breakdown);
```

---

## Seed Data

```
Categories: 3 records (Electronics #1, Apparel #2, Home & Garden #3)
Products:   9 records (3 per category, ids 101–109)
Inventory:  9 records (one per product, varying availability)
Users:      3 records (ids 1–3, tiers: gold, silver, bronze)
Orders:     4 records — User 1 has 2 orders, User 2 has 1, User 3 has 1
            Each order has 2–3 line items referencing product ids above
```

---

## Endpoints

### Categories

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/categories` | List all categories |
| GET | `/api/categories/{categoryId}` | Single category by id |

**GET /api/categories** response:
```json
{
  "items": [
    { "id": 1, "name": "Electronics", "description": "...", "productCount": 3 }
  ],
  "total": 3
}
```

**GET /api/categories/{categoryId}** response: single `Category` object

---

### Products

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/products` | List products; accepts `?categoryId=` and `?limit=` query params |
| GET | `/api/products/featured` | Returns a curated short list (array source for iteration) |
| GET | `/api/products/{productId}` | Single product by id |
| GET | `/api/products/{productId}/pricing` | Pricing detail (child step) |
| GET | `/api/products/{productId}/specifications` | Specs (child step, parallel with pricing) |

**GET /api/products?categoryId=1** response:
```json
{
  "items": [
    { "id": 101, "name": "Laptop Pro", "description": "...",
      "categoryId": 1, "price": 1299.99, "rating": 4.7, "tags": ["laptop","premium"] }
  ],
  "total": 3
}
```

**GET /api/products/featured** response:
```json
{
  "productIds": [101, 104, 107],
  "label": "Staff Picks"
}
```

**GET /api/products/{productId}/pricing** response:
```json
{
  "productId": 101,
  "basePrice": 1399.99,
  "discountedPrice": 1299.99,
  "currency": "USD",
  "validUntil": "2026-12-31"
}
```

**GET /api/products/{productId}/specifications** response:
```json
{
  "productId": 101,
  "specs": [
    { "key": "CPU", "value": "Intel Core i7" },
    { "key": "RAM", "value": "16GB" }
  ]
}
```

---

### Inventory

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/inventory/{productId}` | Stock status for a product (dependent step) |

Response:
```json
{
  "productId": 101,
  "quantity": 42,
  "warehouseId": "WH-EAST-01",
  "available": true,
  "lastUpdated": "2026-05-25T10:00:00Z"
}
```

---

### Users

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/users/{userId}` | User profile (root step) |
| GET | `/api/users/{userId}/orders` | Orders for a user (dependent step) |

**GET /api/users/{userId}** response:
```json
{
  "id": 1,
  "name": "Alice Chen",
  "email": "alice@example.com",
  "tier": "gold",
  "preferences": { "theme": "dark", "interests": ["electronics", "home"] }
}
```

**GET /api/users/{userId}/orders** response:
```json
{
  "items": [
    { "id": 10, "status": "delivered", "total": 1499.98, "createdAt": "2026-04-10T..." }
  ],
  "total": 2
}
```

---

### Orders

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/orders/{orderId}` | Full order with line items (dependent step; `items[]` drives iteration) |

Response:
```json
{
  "id": 10,
  "userId": 1,
  "status": "delivered",
  "items": [
    { "productId": 101, "quantity": 1, "unitPrice": 1299.99 },
    { "productId": 104, "quantity": 2, "unitPrice": 99.99 }
  ],
  "total": 1499.97,
  "createdAt": "2026-04-10T14:22:00Z"
}
```

---

### Cart

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/cart/calculate` | Calculate totals for a set of line items (tests POST body) |

Request body:
```json
{ "items": [{ "productId": 101, "quantity": 1 }, { "productId": 104, "quantity": 2 }] }
```

Response:
```json
{
  "subtotal": 1499.97,
  "tax": 134.99,
  "total": 1634.96,
  "breakdown": [
    { "productId": 101, "name": "Laptop Pro", "quantity": 1,
      "unitPrice": 1299.99, "lineTotal": 1299.99 }
  ]
}
```

---

### Recommendations

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/recommendations?userId={id}&limit={n}` | Recommended products (returns array for iteration) |

Response:
```json
{
  "userId": 1,
  "items": [
    { "productId": 102, "score": 0.95, "reason": "Based on past purchases" }
  ]
}
```

---

## Orchestration Test Scenarios

These scenarios map directly to each node kind. Build them in the UI after importing the Swagger spec.

### Scenario 1 — Pure Sequential (Root → Dependent → Dependent)
```
[root]   GET /api/categories
[dep]    GET /api/products?categoryId=$categories.items[0].id
[dep]    GET /api/inventory/$products.items[0].id
```
**Validates**: Linear dependency chain; each step uses output of the prior step.

---

### Scenario 2 — Parallel Roots + Merge
```
[root]   GET /api/categories
[root]   GET /api/users/1
[dep]    GET /api/products?categoryId=$categories.items[0].id  (depends on categories)
[dep]    GET /api/users/1/orders  (depends on user)
```
**Validates**: Two parallel roots, each with its own dependent; no cross-dependencies.

---

### Scenario 3 — Parent with Child Steps
```
[root]   GET /api/products/101
  [child] GET /api/products/101/pricing
  [child] GET /api/products/101/specifications
```
**Validates**: Children execute after parent; two children run in parallel; children use parent output (`$parent.id`) to build their path.

---

### Scenario 4 — Simple Iteration (Loop)
```
[root]   GET /api/products/featured
[iter]   GET /api/products/$item     (iterate over $response.productIds)
```
**Validates**: `iteration.source = "$response.productIds"`, `itemVariable = "item"`, `execution.mode = "parallel"`.

---

### Scenario 5 — Iteration with Child Steps (Nested)
```
[root]   GET /api/products?categoryId=1
[iter]   GET /api/products/$item.id      (iterate over $response.items, item.id)
  [child]  GET /api/products/$item.id/pricing
  [child]  GET /api/inventory/$item.id
```
**Validates**: Each iteration step has two child steps; children reference the loop item variable.

---

### Scenario 6 — User → Orders → Nested Order Iteration
```
[root]   GET /api/users/1
[dep]    GET /api/users/1/orders
[dep]    GET /api/orders/$orders.items[0].id
[iter]   GET /api/products/$item.productId   (iterate over order.items)
  [child]  GET /api/products/$item.productId/pricing
```
**Validates**: Full depth — root → dependent → dependent → iteration → iteration child.

---

### Scenario 7 — POST with Body (Cart Calculate)
```
[root]   GET /api/products?categoryId=1
[dep]    POST /api/cart/calculate
           body.items = $products.items.map(p => { productId: p.id, quantity: 1 })
```
**Validates**: POST step with dynamic body built from prior step's array output.

---

## Implementation Notes

- Return consistent envelope shapes: list endpoints use `{ items: [...], total: N }` so the builder can consistently reference `$step.items` as an iteration source.
- Every path parameter (`{productId}`, `{categoryId}`, etc.) must be declared in the OpenAPI spec as `in: path, required: true` so the swagger-import component picks them up as inputs.
- Use `[ProducesResponseType(typeof(T), 200)]` on each action so Swashbuckle generates typed response schemas — this is what the builder uses to populate the `fields[]` selector.
- The service needs CORS enabled for `http://localhost:4200` (or wherever the Angular app runs).

---

## Verification Steps

1. Run service: `dotnet run` → confirm Swagger UI loads at `https://localhost:5001/swagger`
2. In orchestration builder: Swagger Import → paste `https://localhost:5001/swagger/v1/swagger.json` → confirm all 13 endpoints appear
3. Build each scenario above and run it; confirm step outputs populate downstream inputs correctly
4. Iteration scenario: confirm `$item` binding resolves for each element in the source array
5. Child scenario: confirm children appear nested under parent in the step tree
