# Angular Implementation Plan - OrcStudio UI Alignment

## Analysis Summary

### Current State
- Angular app has basic placeholder components
- Components use custom styling that doesn't match orcstudio prototypes
- Missing key UI elements from prototypes (navbar, flyout panels, step indicators)
- Layout structure differs from prototype

### Target State
- Exact match to orcstudio HTML prototypes
- Proper navbar with branding and help button
- Flyout panels for detail views
- Step indicators for multi-step workflows
- Grid-based layouts for orchestration cards
- Proper styling using CSS variables from orcstudio

---

## Detailed Implementation Plan

### Phase 1: Layout & Navigation Infrastructure

#### 1.1 App Layout Component (NEW)
**File:** `src/app/shared/layout/app-layout.component.ts|html|scss`

**Changes:**
- Create wrapper component for navbar + content
- Navbar structure:
  - Left: Brand "OrcStudio — API Orchestration Builder"
  - Right: Help button (?)
  - Background: Dark navy (#1D2023)
  - Height: 56px
  - Sticky positioning
  - Box shadow: 0 1px 4px rgba(0,0,0,0.1)

**Template Structure:**
```html
<nav class="navbar">
  <div class="navbar-left">
    <span class="navbar-brand">OrcStudio — API Orchestration Builder</span>
  </div>
  <div class="navbar-right">
    <span class="help-icon" title="Help">?</span>
  </div>
</nav>
<router-outlet></router-outlet>
```

#### 1.2 Global CSS Variables (UPDATE)
**File:** `src/assets/styles/_variables.scss`

**Add CSS Variables:**
```scss
--nav-bg: #1D2023
--bg-page: #F8F8F8
--bg-panel: #FFFFFF
--border: #C8C9C9
--border-radius: 4px
--text-primary: #1D2023
--text-secondary: #666666
--dell-blue: #0076CE
--success: #16A34A
--warning: #D97706
--error: #DC2626
```

---

### Phase 2: Orchestration List Page

#### 2.1 OrchestrationListComponent (REBUILD)
**File:** `src/app/features/orchestration/orchestration-list/orchestration-list.component.ts|html|scss`

**Current Issues:**
- Card layout doesn't match prototype
- Missing orchestration card styling
- Filter/search UI differs

**Required Changes:**

**Template Structure:**
```html
<div class="page-container">
  <div class="page-content">
    <!-- Header Section -->
    <div class="page-header-row">
      <h1 class="page-title">Orchestrations</h1>
      <button class="btn btn-primary">+ New Orchestration</button>
    </div>

    <!-- Search & Filter Section -->
    <div class="filter-row">
      <div class="search-box">
        <span class="search-icon">🔍</span>
        <input type="search" placeholder="Search orchestrations...">
      </div>
      <select class="status-filter">
        <option value="">Status: All</option>
        <option value="draft">Draft</option>
        <option value="active">Active</option>
        <option value="published">Published</option>
      </select>
    </div>

    <!-- Orchestration Cards Grid -->
    <div class="grid grid-2">
      <div *ngFor="let orc of filteredOrchestrations" class="orc-card">
        <div class="orc-card-header">
          <div>
            <h3 class="orc-name">{{ orc.name }}</h3>
            <p class="orc-description">{{ orc.description }}</p>
          </div>
          <span class="orc-status" [class]="'status-' + orc.status">
            {{ orc.status }}
          </span>
        </div>
        <div class="orc-card-meta">
          <span class="meta-item">v{{ orc.version }}</span>
          <span class="meta-item">{{ orc.steps }} steps</span>
        </div>
        <div class="orc-card-actions">
          <button class="btn btn-secondary btn-sm">View</button>
          <button class="btn btn-secondary btn-sm">Edit</button>
        </div>
      </div>
    </div>
  </div>
</div>
```

**Styling Requirements:**
- Page container: max-width 1200px, centered
- Page title: 24px, font-weight 500
- Filter row: flex, gap 16px, margin-bottom 24px
- Search box: flex-grow 1, with icon
- Grid: 2-column, auto-fit minmax(300px, 1fr)
- Card: background white, border 1px solid #C8C9C9, padding 16px
- Card hover: border-color #0076CE, box-shadow 0 4px 12px rgba(0,118,206,0.1)
- Status badges: different colors for draft/active/published

---

### Phase 3: Orchestration Builder Page

#### 3.1 BuilderComponent (REBUILD)
**File:** `src/app/features/builder/builder.component.ts|html|scss`

**Required Changes:**

**Template Structure:**
```html
<div class="builder-page">
  <!-- Builder Inner Header -->
  <div class="builder-inner-header">
    <div class="builder-inner-header-left">
      <button class="btn btn-secondary">← Back to Manager</button>
    </div>
    
    <div class="builder-inner-header-center">
      <div class="builder-orc-name-row">
        <span class="builder-orc-name" contenteditable="true">
          {{ orchestrationName }}
        </span>
      </div>
      <div class="builder-orc-meta-row">
        <select class="builder-orc-status">
          <option value="draft">Draft</option>
          <option value="active">Active</option>
          <option value="published">Published</option>
        </select>
        <span class="builder-orc-version">v{{ version }}</span>
      </div>
    </div>

    <div class="builder-inner-header-right">
      <button class="btn btn-secondary">+ Add Root API</button>
      <button class="btn btn-primary">Save</button>
      <button class="btn btn-secondary">Save & Back</button>
      <button class="btn btn-secondary">Export JSON</button>
    </div>
  </div>

  <!-- Builder Tabs -->
  <div class="builder-view-tabs">
    <button class="builder-tab active" (click)="selectTab('visual')">Visual</button>
    <button class="builder-tab" (click)="selectTab('flow')">Flow</button>
    <button class="builder-tab" (click)="selectTab('json')">JSON</button>
  </div>

  <!-- Builder Canvas -->
  <div class="builder-canvas">
    <!-- Content based on selected tab -->
  </div>
</div>
```

**Styling Requirements:**
- Builder inner header: flex, space-between, padding 16px, background white
- Header sections: left/center/right with proper alignment
- Orchestration name: editable, large font
- Meta row: status select + version span
- Tabs: button-style, active state with underline
- Canvas: full-height, flex-grow

---

### Phase 4: API Marketplace Page

#### 4.1 ApiMarketplaceComponent (REBUILD)
**File:** `src/app/features/api-marketplace/api-marketplace.component.ts|html|scss`

**Required Changes:**

**Template Structure:**
```html
<div class="page-container">
  <div class="page-content">
    <div class="page-header">
      <h1 class="page-title">API Marketplace</h1>
      <p class="page-subtitle">Discover and integrate APIs</p>
    </div>

    <!-- API Cards Grid -->
    <div class="grid grid-3">
      <div *ngFor="let api of apis" class="api-card" (click)="selectApi(api)">
        <div class="api-card-header">
          <span class="api-icon">{{ api.icon }}</span>
          <div>
            <h3 class="api-name">{{ api.name }}</h3>
            <p class="api-provider">{{ api.provider }}</p>
          </div>
        </div>
        <p class="api-description">{{ api.description }}</p>
        <div class="api-tags">
          <span *ngFor="let tag of api.tags" class="tag">{{ tag }}</span>
        </div>
      </div>
    </div>
  </div>
</div>
```

**Styling Requirements:**
- Grid: 3-column, auto-fit minmax(280px, 1fr)
- API card: background white, border 1px, padding 16px
- Card hover: border-color blue, shadow
- Icon: 24px emoji
- Name: 16px, font-weight 500
- Provider: 12px, secondary color
- Description: 14px, secondary color
- Tags: small badges with background

---

### Phase 5: Flyout Panel System (NEW)

#### 5.1 FlyoutPanelComponent (NEW)
**File:** `src/app/shared/components/flyout-panel/flyout-panel.component.ts|html|scss`

**Purpose:** Reusable panel for detail views

**Template Structure:**
```html
<div class="flyout-backdrop" *ngIf="isOpen" (click)="close()"></div>
<div class="flyout-panel" *ngIf="isOpen">
  <div class="flyout-header">
    <button *ngIf="showBack" class="flyout-header-back" (click)="goBack()">
      ←
    </button>
    <h2 class="flyout-header-title">{{ title }}</h2>
    <button class="flyout-header-close" (click)="close()">✕</button>
  </div>
  <div class="flyout-body">
    <ng-content></ng-content>
  </div>
  <div class="flyout-footer" *ngIf="showFooter">
    <ng-content select="[flyout-footer]"></ng-content>
  </div>
</div>
```

**Styling Requirements:**
- Backdrop: fixed, full-screen, rgba(0,0,0,0.5)
- Panel: fixed, right side, width 400px, background white
- Header: padding 16px, border-bottom, flex space-between
- Close button: cursor pointer, hover effect
- Body: padding 16px, overflow-y auto
- Footer: padding 16px, border-top, background light

---

### Phase 6: Step Indicator Component (NEW)

#### 6.1 StepIndicatorComponent (NEW)
**File:** `src/app/shared/components/step-indicator/step-indicator.component.ts|html|scss`

**Purpose:** Show progress in multi-step workflows

**Template Structure:**
```html
<div class="step-indicator">
  <div *ngFor="let step of steps; let i = index" class="step-item" 
       [class.active]="i === currentStep"
       [class.completed]="i < currentStep">
    <div class="step-number">{{ i + 1 }}</div>
    <span class="step-label">{{ step.label }}</span>
    <div *ngIf="i < steps.length - 1" class="step-separator"></div>
  </div>
</div>
```

**Styling Requirements:**
- Container: flex, center, gap 8px, padding 16px
- Step item: flex, gap 8px, font-size 12px
- Step number: 24px circle, border 1px, center text
- Active: background blue, color white
- Completed: background green, checkmark
- Separator: 20px line between steps

---

### Phase 7: Page Builder Page

#### 7.1 PageBuilderComponent (REBUILD)
**File:** `src/app/features/page-builder/page-builder.component.ts|html|scss`

**Required Changes:**
- Minimal implementation
- Placeholder canvas area
- Similar navbar structure

---

## Implementation Order

1. **Phase 1** - Layout infrastructure (navbar, CSS variables)
2. **Phase 2** - Orchestration list page
3. **Phase 3** - Orchestration builder page
4. **Phase 4** - API marketplace page
5. **Phase 5** - Flyout panel system
6. **Phase 6** - Step indicator component
7. **Phase 7** - Page builder page

---

## Key Differences from Current Implementation

| Aspect | Current | Target |
|--------|---------|--------|
| Navbar | Missing | Dark navy, sticky, with brand |
| Layout | Custom | Matches orcstudio exactly |
| Cards | Grid with custom styling | Prototype-matching cards |
| Flyout | Not implemented | Full flyout panel system |
| Step indicator | Not implemented | Multi-step workflow support |
| CSS Variables | Partial | Complete Dell brand palette |
| Page structure | Varies | Consistent across all pages |
| Responsive | Basic | Mobile-first, matches prototype |

---

## Testing Checklist

- [ ] Navbar appears on all pages
- [ ] Orchestration list displays cards correctly
- [ ] Search and filter work
- [ ] Builder page layout matches prototype
- [ ] Tabs switch content
- [ ] Flyout panels open/close
- [ ] Step indicator shows progress
- [ ] API marketplace displays cards
- [ ] All buttons are functional
- [ ] Responsive design works on mobile
- [ ] Styling matches orcstudio exactly

