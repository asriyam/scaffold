# Mock Data Quick Start Guide

## TL;DR

The Angular application includes mock data for 6 APIs, 3 orchestrations, and 8 webparts. Access via `MockDataService`.

## Quick Setup

### 1. Inject MockDataService

```typescript
import { MockDataService } from '@core/services/mock-data.service';

constructor(private mockData: MockDataService) {}
```

### 2. Get Data

```typescript
// Get all APIs
this.mockData.getApis().subscribe(apis => {
  console.log(apis);
});

// Get orchestrations
this.mockData.getOrchestrations().subscribe(orcs => {
  console.log(orcs);
});

// Get webparts
this.mockData.getWebparts().subscribe(webparts => {
  console.log(webparts);
});
```

### 3. Use in Templates

```html
<div *ngFor="let api of mockData.getApis() | async">
  {{ api.name }}
</div>
```

## Available APIs

| ID | Name | Endpoint | Category |
|----|------|----------|----------|
| category | Category API | `/api/v1/categories/{categoryId}/products` | Products |
| products | Products API | `/api/v1/products/{productId}` | Products |
| ratings | Ratings API | `/api/v1/products/{productId}/ratings` | Products |
| inventory | Inventory API | `/api/v1/inventory/{productId}` | Inventory |
| shipping | Shipping API | `/api/v1/shipping/calculate` | Shipping |
| users | Users API | `/api/v1/users/{userId}` | Users |

## Sample Orchestrations

| ID | Name | Status | APIs |
|----|------|--------|------|
| orc-001 | Laptop Catalog Page | Active | Category, Products, Ratings |
| orc-002 | Home Deals Rotator | Draft | Products, Shipping |
| orc-003 | Gaming Category Page | Active | Category, Products, Inventory |

## Common Tasks

### Search APIs

```typescript
this.mockData.searchApis('product').subscribe(results => {
  // Returns APIs matching 'product' in name or description
});
```

### Get APIs by Category

```typescript
this.mockData.getApisByCategory('Products').subscribe(apis => {
  // Returns all APIs in Products category
});
```

### Get Single API

```typescript
this.mockData.getApiById('products').subscribe(api => {
  // Returns Products API
});
```

### Get API Sample Response

```typescript
this.mockData.getApiSampleResponse('products').subscribe(sample => {
  // Returns example response for Products API
});
```

### Get Orchestration by Status

```typescript
this.mockData.getOrchestrationsByStatus('active').subscribe(orcs => {
  // Returns all active orchestrations
});
```

### Get Webpart by Type

```typescript
this.mockData.getWebpartsByType('grid').subscribe(webparts => {
  // Returns all grid-type webparts
});
```

## File Locations

```
src/app/
├── core/
│   ├── mockdata/
│   │   ├── apis.ts                 # API definitions
│   │   ├── orchestrations.ts       # Orchestration samples
│   │   ├── webparts.ts             # Webpart definitions
│   │   └── README.md               # Detailed docs
│   └── services/
│       └── mock-data.service.ts    # Service
├── models/
│   ├── api.model.ts
│   ├── orchestration.model.ts
│   └── webpart.model.ts
```

## Data Structure Examples

### API

```typescript
{
  id: 'products',
  name: 'Products API',
  method: 'GET',
  endpoint: '/api/v1/products/{productId}',
  description: 'Fetch full product details...',
  category: 'Products',
  inputs: [
    { name: 'productId', type: 'string', required: true, ... }
  ],
  outputs: [
    { name: 'id', type: 'string', description: '...' },
    { name: 'name', type: 'string', description: '...' },
    // ... more fields
  ],
  examples: [
    { name: 'Dell XPS 15', inputs: {...}, output: {...} }
  ]
}
```

### Orchestration

```typescript
{
  id: 'orc-001',
  name: 'Laptop Catalog Page',
  status: 'active',
  apiCalls: [
    {
      callId: 'category-api',
      apiId: 'category',
      endpoint: '/api/v1/categories/{categoryId}/products',
      fields: ['id', 'name', 'products'],
      iteration: {
        arrayField: 'products',
        childCalls: [
          { callId: 'product-details', apiId: 'products', ... },
          { callId: 'product-ratings', apiId: 'ratings', ... }
        ]
      }
    }
  ]
}
```

### Webpart

```typescript
{
  id: 'product-grid',
  type: 'grid',
  name: 'Product Grid',
  description: 'Responsive grid layout for displaying products',
  properties: [
    { name: 'columns', type: 'select', value: '3', options: ['2', '3', '4', '5'] },
    { name: 'gap', type: 'select', value: 'medium', options: ['small', 'medium', 'large'] },
    // ... more properties
  ]
}
```

## Migration Checklist

When ready to use real API:

- [ ] Create `ApiCatalogService` with same interface as `MockDataService`
- [ ] Implement HTTP calls to real backend
- [ ] Update environment configuration
- [ ] Replace `MockDataService` injection with `ApiCatalogService`
- [ ] Test all components with real data
- [ ] Remove mock data files (optional)

## Troubleshooting

### Service not found?
```typescript
// Make sure it's provided in root
@Injectable({ providedIn: 'root' })
export class MockDataService { ... }
```

### Data not loading?
```typescript
// Use async pipe or subscribe
<div *ngFor="let api of mockData.getApis() | async">
  {{ api.name }}
</div>
```

### Type errors?
```typescript
// Import models
import { Api, Orchestration, Webpart } from '@models';
```

## Resources

- **Full Documentation**: `docs/MOCKDATA-STRUCTURE.md`
- **Mock Data README**: `src/app/core/mockdata/README.md`
- **Implementation Plan**: `docs/ui-orchestration-builder-impl-v1.md`

## Support

For questions or issues with mock data:
1. Check `MOCKDATA-STRUCTURE.md` for detailed information
2. Review `MockDataService` implementation
3. Check component examples in the codebase
