## CMX UI Builder – Specification (v2)

### Overview
A visual UI builder that lets users compose frontend components from a unified API response. The tool bridges API orchestration output (structured data fields) with drag-and-drop UI components, enabling non-developers to build data-bound interfaces without writing code.

---

### Layout: Three-Panel Design

All three panels are **moveable** and **closeable**. When a panel is closed, a button appears in the Top Bar to reopen it. Panels float/dock and can be repositioned by dragging their title bar.

**Left Panel – Field Explorer**
- Displays the unified API response schema as a collapsible tree
- Each field has a checkbox for selection
- Primitive fields (string, number) are leaf nodes
- Object/array fields are expandable with a `>` toggle (collapse with `v`)
- Selected fields drive the component suggestions in the Gallery Bar

**Center Panel – Canvas + Gallery Bar**
- *Gallery Bar* (top): Context-sensitive, changes based on field selection state:
  - **No fields selected** → Shows row layout options: 1-column, 2-column, 3-column, 4-column tiles
  - **1 text field** → Label, Heading, Badge, Tag
  - **Title + Description + Image** → Card, Hero Banner, Media Tile
  - **Title + Description + Price** → Pricing Card, Product Listing Row
  - *(etc. — see Component Types table)*
  - A **"Browse"** button is always present at the end of the Gallery Bar
- *Canvas* (main area): Drop zone where layouts and components are placed
  - Layouts dragged from the Gallery Bar land as **dotted-line placeholder rows** showing column divisions
  - Components can **only be dropped into layout placeholders** — not onto the bare canvas
  - Clicking a component on the Canvas selects it (highlighted border); Right Panel updates
  - Selected components can be **deleted** (via delete key or trash icon)
  - Component size is determined by its properties and the column width it occupies — no manual resize handles

**Right Panel – Properties & Binding**
- Appears/updates when a component is selected on the Canvas
- Divided into two sections:
  - *Style Properties*: Visual customization (color, background, alignment, font size, etc.) — fields vary by component type
  - *Data Binding*: Maps component slots (e.g. "Title", "Subtitle", "Image") to fields from the Left Panel schema
- Changes reflect live on the Canvas

**Browse Flyout** (triggered by "Browse" button in Gallery Bar)
- Slides in from the right side as an overlay panel (does not replace the Right Panel)
- Shows the full component gallery organized by category (Layout, Text, Media, Commerce, etc.)
- User can drag a component directly from the flyout onto a canvas placeholder
- Closeable via an X button; also closes automatically after a component is dropped

---

### Top Bar
- **App name**: CMX (left)
- **Panel toggle buttons**: Appear in the Top Bar when panels are closed, allowing the user to reopen them (e.g. "Fields", "Properties")
- **User menu**: Top right
- **Action buttons**: Preview, Save, Cancel

---

### Key Interactions

| Action | Behavior |
|---|---|
| No fields checked | Gallery Bar shows layout options (1–4 column) |
| Drag layout to Canvas | Drops a dotted-line row placeholder with column divisions |
| Check field(s) in Left Panel | Gallery Bar updates to show contextually relevant components |
| Uncheck all fields | Gallery Bar returns to layout options |
| Click Gallery component | Begins drag; can be dropped onto a canvas layout placeholder |
| Click "Browse" | Opens Browse Flyout from the right side |
| Drag component from Flyout | Drops into a canvas layout placeholder; flyout closes |
| Click component on Canvas | Selects it; Right Panel populates with its properties |
| Delete selected component | Removes it from its placeholder; placeholder remains empty |
| Edit Right Panel fields | Live-updates the component on Canvas |
| Close any panel | Panel hides; reopen button appears in Top Bar |
| Click Preview | Renders canvas as a live data-bound preview |
| Click Save | Persists the layout and bindings |

---

### Canvas Placement Rules
- A **layout row** must be placed before any component can be added
- Each layout row has 1–4 column slots (dotted placeholders)
- Each slot accepts **exactly one component**
- Dropping a component on an occupied slot prompts replacement confirmation
- Empty placeholders remain visible as dotted outlines in edit mode; hidden in Preview

---

### Component Types (Gallery)

| Fields Selected | Suggested Components |
|---|---|
| *(none)* | 1-col, 2-col, 3-col, 4-col layout rows |
| 1 text | Label, Heading, Badge, Tag |
| 1 image | Image, Avatar, Thumbnail |
| Text + Text | Key-Value, Subtitle Block |
| Text + Image | Media Row, Card |
| Title + Desc + Image | Product Card, Hero Banner, Media Tile |
| Title + Desc + Price | Pricing Card, Product Listing Row |
| Any list/array field | Table, List, Carousel |
| Date field | Timeline Item, Date Badge |
| Price/number | Stat Block, Price Tag |

---

### Data Binding Model
- Each component has named **slots** (e.g. Banner has: `title`, `subtitle`, `image`, `background`, `alignment`)
- Slots are auto-mapped when a component is dropped if field names match heuristically (e.g. `heroImage` → image slot)
- User can manually override binding in the Right Panel
- Unbound slots show a placeholder label in the Canvas (e.g. *"No title bound"*)

---