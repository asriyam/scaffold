Simplified API Endpoints:
https://orchestrationapi.pnp5.pcf.dell.com/swagger/v1/swagger.json

