/* =========================================================
   CMX Visual UI Builder – Mock Behavior
   Standalone HTML/JS/CSS prototype (no Angular)
   ========================================================= */

(() => {
  // ---------- State ----------
  const state = {
    selectedFields: new Set(),
    selectedSlot: null,
    dragData: null
  };

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  // =========================================================
  // Field tree
  // =========================================================
  const fieldTree = $('#fieldTree');

  fieldTree.addEventListener('click', (e) => {
    const toggle = e.target.closest('.toggle');
    if (toggle) {
      const group = toggle.closest('.field-node.group');
      if (group.classList.contains('expanded')) {
        group.classList.remove('expanded');
        group.classList.add('collapsed');
        toggle.textContent = '›';
      } else {
        group.classList.remove('collapsed');
        group.classList.add('expanded');
        toggle.textContent = '⌄';
      }
    }
  });

  fieldTree.addEventListener('change', (e) => {
    const cb = e.target.closest('input[type="checkbox"]');
    if (!cb) return;
    const field = cb.dataset.field;
    const kind = cb.dataset.kind || 'text';
    if (cb.checked) state.selectedFields.add(`${field}::${kind}`);
    else state.selectedFields.delete(`${field}::${kind}`);
    updateGalleryBar();
  });

  // =========================================================
  // Gallery bar – context-sensitive
  // =========================================================
  const galleryItems = $('#galleryItems');

  function selectedKinds() {
    return Array.from(state.selectedFields).map(s => s.split('::')[1]);
  }

  function updateGalleryBar() {
    const kinds = selectedKinds();
    galleryItems.innerHTML = '';

    if (kinds.length === 0) {
      // Layout mode
      renderChips([
        { type: 'layout', cols: 1, label: '1-col' },
        { type: 'layout', cols: 2, label: '2-col' },
        { type: 'layout', cols: 3, label: '3-col' },
        { type: 'layout', cols: 4, label: '4-col' }
      ]);
      return;
    }

    const has = (k) => kinds.includes(k);
    const count = (k) => kinds.filter(x => x === k).length;
    let suggestions = [];

    if (has('title') && (has('desc') || count('desc') >= 1) && has('image') && has('price')) {
      suggestions = ['Pricing Card', 'Product Listing Row'];
    } else if (has('title') && has('desc') && has('image')) {
      suggestions = ['Card', 'Banner', 'Media Tile', 'Product Card'];
    } else if (has('title') && has('image')) {
      suggestions = ['Media Row', 'Card'];
    } else if (count('text') + count('title') + count('desc') >= 2) {
      suggestions = ['Key-Value', 'Subtitle Block'];
    } else if (kinds.length === 1 && (has('text') || has('title') || has('desc'))) {
      suggestions = ['Label', 'Heading', 'Badge', 'Tag'];
    } else if (kinds.length === 1 && has('image')) {
      suggestions = ['Image', 'Avatar', 'Thumbnail'];
    } else if (has('price')) {
      suggestions = ['Stat Block', 'Price Tag'];
    } else if (has('date')) {
      suggestions = ['Timeline Item', 'Date Badge'];
    } else if (has('array')) {
      suggestions = ['Table', 'List', 'Carousel'];
    } else {
      suggestions = ['Label', 'Card', 'Banner'];
    }

    renderChips(suggestions.map(name => ({ type: 'component', name, label: name })));
  }

  function renderChips(items) {
    galleryItems.innerHTML = '';
    items.forEach(item => {
      const chip = document.createElement('div');
      chip.className = 'gallery-chip';
      chip.draggable = true;
      chip.textContent = item.label;
      chip.dataset.type = item.type;
      if (item.cols) chip.dataset.cols = item.cols;
      if (item.name) chip.dataset.name = item.name;
      attachDragSource(chip);
      galleryItems.appendChild(chip);
    });
  }

  // =========================================================
  // Drag & drop
  // =========================================================
  function attachDragSource(el) {
    el.addEventListener('dragstart', (e) => {
      state.dragData = { ...el.dataset };
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('text/plain', JSON.stringify(state.dragData));
    });
    el.addEventListener('dragend', () => { state.dragData = null; });
  }

  // Initial chips and flyout cards
  $$('.gallery-chip').forEach(attachDragSource);
  $$('.flyout-card').forEach(attachDragSource);

  const canvas = $('#canvas');

  canvas.addEventListener('dragover', (e) => {
    // Only accept LAYOUT drops on the bare canvas
    if (!state.dragData) return;
    if (state.dragData.type === 'layout') {
      e.preventDefault();
      canvas.classList.add('drag-over');
    }
  });
  canvas.addEventListener('dragleave', () => canvas.classList.remove('drag-over'));
  canvas.addEventListener('drop', (e) => {
    canvas.classList.remove('drag-over');
    if (!state.dragData) return;
    if (state.dragData.type === 'layout') {
      e.preventDefault();
      addLayoutRow(parseInt(state.dragData.cols, 10));
    }
  });

  function addLayoutRow(cols) {
    // Remove empty hint
    const hint = canvas.querySelector('.canvas-empty-hint');
    if (hint) hint.remove();

    const row = document.createElement('div');
    row.className = `layout-row cols-${cols}`;
    for (let i = 0; i < cols; i++) {
      const slot = document.createElement('div');
      slot.className = 'slot';
      slot.innerHTML = `<span class="placeholder-text">Drop component here</span>`;
      attachSlotDropHandlers(slot);
      row.appendChild(slot);
    }
    canvas.appendChild(row);
  }

  function attachSlotDropHandlers(slot) {
    slot.addEventListener('dragover', (e) => {
      if (!state.dragData) return;
      if (state.dragData.type === 'component') {
        e.preventDefault();
        slot.classList.add('drag-over');
      }
    });
    slot.addEventListener('dragleave', () => slot.classList.remove('drag-over'));
    slot.addEventListener('drop', (e) => {
      slot.classList.remove('drag-over');
      if (!state.dragData) return;
      if (state.dragData.type === 'component') {
        e.preventDefault();
        const name = state.dragData.name;
        if (slot.classList.contains('has-component')) {
          if (!confirm(`Replace existing component with "${name}"?`)) return;
        }
        renderComponentInSlot(slot, name);
        // Auto-close flyout
        closeFlyout();
      }
    });
    slot.addEventListener('click', () => selectSlot(slot));
  }

  function renderComponentInSlot(slot, name) {
    slot.classList.add('has-component');
    slot.dataset.component = name;
    slot.innerHTML = '';

    if (name === 'Banner' || name === 'Hero Banner') {
      slot.innerHTML = `
        <div class="component-banner">
          <div class="banner-img">image</div>
          <div class="banner-text">
            <span class="banner-title">Product Title</span>
            <span class="banner-subtitle">Short description goes here…</span>
          </div>
        </div>
        <button class="slot-delete" title="Delete">🗑</button>`;
    } else {
      slot.innerHTML = `
        <div class="component-generic"><strong>${name}</strong><br/><span style="color:#6b7280;font-size:12px">(mock component)</span></div>
        <button class="slot-delete" title="Delete">🗑</button>`;
    }

    const del = slot.querySelector('.slot-delete');
    del.addEventListener('click', (ev) => {
      ev.stopPropagation();
      slot.classList.remove('has-component', 'selected');
      slot.dataset.component = '';
      slot.innerHTML = `<span class="placeholder-text">Drop component here</span>`;
      if (state.selectedSlot === slot) {
        state.selectedSlot = null;
        renderProperties(null);
      }
    });

    selectSlot(slot);
  }

  // =========================================================
  // Selection + properties
  // =========================================================
  function selectSlot(slot) {
    if (!slot.classList.contains('has-component')) return;
    $$('.slot.selected').forEach(s => s.classList.remove('selected'));
    slot.classList.add('selected');
    state.selectedSlot = slot;
    renderProperties(slot.dataset.component);
  }

  function renderProperties(componentName) {
    const body = $('#propertiesBody');
    body.innerHTML = '';
    const titleEl = $('#rightPanel .panel-title');

    if (!componentName) {
      titleEl.textContent = 'Properties';
      body.innerHTML = '<div class="prop-empty">Select a component on the canvas to edit its properties.</div>';
      return;
    }

    titleEl.textContent = `Customize ${componentName}`;

    if (componentName === 'Banner' || componentName === 'Hero Banner') {
      const tpl = $('#bannerPropsTpl');
      body.appendChild(tpl.content.cloneNode(true));
    } else {
      body.innerHTML = `
        <div class="props-section">
          <h4 class="props-section-title">Style</h4>
          <div class="prop-field"><label>Color</label><input type="text" value="#1f2937"/></div>
          <div class="prop-field"><label>Background</label><input type="text" value="#ffffff"/></div>
          <div class="prop-field"><label>Alignment</label>
            <select><option>Left</option><option>Center</option><option>Right</option></select>
          </div>
        </div>
        <div class="props-section">
          <h4 class="props-section-title">Data Binding</h4>
          <div class="prop-field"><label>Text</label>
            <select><option>productTitle</option><option>shortDesc</option><option>(unbound)</option></select>
          </div>
        </div>`;
    }
  }

  // Canvas: click empty area deselects
  canvas.addEventListener('click', (e) => {
    if (e.target === canvas) {
      $$('.slot.selected').forEach(s => s.classList.remove('selected'));
      state.selectedSlot = null;
      renderProperties(null);
    }
  });

  // Delete key removes selected slot's component
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Delete' && e.key !== 'Backspace') return;
    if (document.activeElement && /input|select|textarea/i.test(document.activeElement.tagName)) return;
    if (state.selectedSlot && state.selectedSlot.classList.contains('has-component')) {
      state.selectedSlot.querySelector('.slot-delete')?.click();
    }
  });

  // =========================================================
  // Panel close / reopen
  // =========================================================
  const workspace = $('.workspace');
  $$('.close-panel').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.target;
      $(`#${target}Panel`).classList.add('closed');
      workspace.classList.add(`${target}-closed`);
      $(`.panel-toggle-btn[data-target="${target}"]`).classList.remove('hidden');
      updateWorkspaceModifier();
    });
  });

  $$('.panel-toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.target;
      $(`#${target}Panel`).classList.remove('closed');
      workspace.classList.remove(`${target}-closed`);
      btn.classList.add('hidden');
      updateWorkspaceModifier();
    });
  });

  function updateWorkspaceModifier() {
    const lc = $('#leftPanel').classList.contains('closed');
    const rc = $('#rightPanel').classList.contains('closed');
    workspace.classList.toggle('both-closed', lc && rc);
  }

  // =========================================================
  // Browse flyout
  // =========================================================
  const flyout = $('#browseFlyout');
  $('#browseBtn').addEventListener('click', () => flyout.classList.add('open'));
  $('#closeFlyout').addEventListener('click', closeFlyout);
  function closeFlyout() { flyout.classList.remove('open'); }

  // =========================================================
  // Action buttons (mock)
  // =========================================================
  $('.preview-btn').addEventListener('click', () => alert('Preview (mock): renders Canvas as live data-bound preview.'));
  $('.save-btn').addEventListener('click', () => alert('Save (mock): persists layout and bindings.'));
  $('.cancel-btn').addEventListener('click', () => alert('Cancel (mock): exits Visual Builder.'));

  // Initial render
  updateGalleryBar();
})();
